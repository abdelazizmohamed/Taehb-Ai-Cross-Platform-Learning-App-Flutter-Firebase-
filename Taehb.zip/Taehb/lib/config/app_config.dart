class AppConfig {
  // Backend API Configuration
  static const String backendUrl = 'http://localhost:5000';
  // For Android emulator use: http://10.0.2.2:5000
  
  // Quiz Configuration
  static const int defaultQuestionsPerSession = 15;
  static const int maxUnitsPerSession = 3;
  static const int pointsPerQuestion = 10;
  
  // Level Configuration
  static const int level1Threshold = 100;
  static const int level2Threshold = 250;
  static const int advancedTestUnlockThreshold = 5; // distinct units
  
  // Feature Flags
  static const bool useAIGeneratedQuestions = true;
  static const bool cacheGeneratedQuestions = true;
  static const bool enableOfflineMode = false;
  
  // API Timeouts
  static const int apiTimeoutSeconds = 30;
  static const int questionGenerationTimeoutSeconds = 90;
}
