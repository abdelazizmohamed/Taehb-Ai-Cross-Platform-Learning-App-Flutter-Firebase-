import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:taehb/services/points_progress_service.dart';
import 'package:firebase_auth/firebase_auth.dart';


class UserStatsWidget extends StatefulWidget {
  const UserStatsWidget({Key? key}) : super(key: key);

  @override
  State<UserStatsWidget> createState() => _UserStatsWidgetState();
}

class _UserStatsWidgetState extends State<UserStatsWidget> {
  final PointsProgressService _pointsService = PointsProgressService();
  Map<String, dynamic>? _stats;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (userId != null) {
        final stats = await _pointsService.getUserStats(userId);
        setState(() {
          _stats = stats;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('❌ Error loading stats: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (_stats == null) {
      return const SizedBox.shrink();
    }

    return Column(
      children: [
        _buildStatsCard(),
        const SizedBox(height: 16),
        _buildLevelProgressCard(),
      ],
    );
  }

  /// بطاقة الإحصائيات الرئيسية
  Widget _buildStatsCard() {
    final totalPoints = _stats!['totalPoints'] ?? 0;
    final currentLevel = _stats!['currentLevel'] ?? 0;
    final rank = _stats!['rank'] ?? 0;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Colors.deepPurple, Colors.purpleAccent],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.deepPurple.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem(
                icon: Icons.emoji_events,
                label: 'النقاط',
                value: totalPoints.toString(),
              ),
              _buildStatDivider(),
              _buildStatItem(
                icon: Icons.trending_up,
                label: 'المستوى',
                value: currentLevel.toString(),
              ),
              _buildStatDivider(),
              _buildStatItem(
                icon: Icons.stars,
                label: 'الترتيب',
                value: '#$rank',
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// بطاقة التقدم في المستوى
  Widget _buildLevelProgressCard() {
    final currentLevel = _stats!['currentLevel'] ?? 0;
    final pointsToNext = _stats!['pointsToNextLevel'] ?? 0;
    final progressPercentage = _stats!['progressPercentage'] ?? 0.0;
    final nextLevelThreshold = _stats!['nextLevelThreshold'] ?? 0;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'المستوى $currentLevel',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepPurple,
                  ),
                ),
                Text(
                  'المستوى ${currentLevel + 1}',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // شريط التقدم
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: progressPercentage / 100,
                backgroundColor: Colors.grey[200],
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.deepPurple),
                minHeight: 12,
              ),
            ),

            const SizedBox(height: 8),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${progressPercentage.toStringAsFixed(1)}% مكتمل',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                Text(
                  'تحتاج $pointsToNext نقطة',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 24),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.8),
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildStatDivider() {
    return Container(
      width: 1,
      height: 40,
      color: Colors.white.withOpacity(0.3),
    );
  }
}

/// Widget لعرض تاريخ النقاط
class PointsHistoryWidget extends StatefulWidget {
  const PointsHistoryWidget({Key? key}) : super(key: key);

  @override
  State<PointsHistoryWidget> createState() => _PointsHistoryWidgetState();
}

class _PointsHistoryWidgetState extends State<PointsHistoryWidget> {
  final PointsProgressService _pointsService = PointsProgressService();
  List<Map<String, dynamic>> _history = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (userId != null) {
        final history = await _pointsService.getPointsHistory(userId, limit: 10);
        setState(() {
          _history = history;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('❌ Error loading history: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_history.isEmpty) {
      return const Center(
        child: Text('لا يوجد سجل نقاط بعد'),
      );
    }

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _history.length,
      itemBuilder: (context, index) {
        final item = _history[index];
        return _buildHistoryItem(item);
      },
    );
  }

  Widget _buildHistoryItem(Map<String, dynamic> item) {
    final pointsEarned = item['pointsEarned'] ?? 0;
    final source = item['source'] ?? '';
    final timestamp = item['timestamp'] as Timestamp?;

    IconData icon;
    String title;
    Color color;

    switch (source) {
      case 'quiz_completion':
        icon = Icons.quiz;
        title = 'إكمال اختبار';
        color = Colors.blue;
        break;
      case 'daily_login':
        icon = Icons.login;
        title = 'تسجيل دخول يومي';
        color = Colors.green;
        break;
      default:
        icon = Icons.star;
        title = 'نقاط';
        color = Colors.amber;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color),
        ),
        title: Text(title),
        subtitle: timestamp != null
            ? Text(_formatTimestamp(timestamp.toDate()))
            : null,
        trailing: Text(
          '+$pointsEarned',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ),
    );
  }

  String _formatTimestamp(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 60) {
      return 'منذ ${difference.inMinutes} دقيقة';
    } else if (difference.inHours < 24) {
      return 'منذ ${difference.inHours} ساعة';
    } else {
      return 'منذ ${difference.inDays} يوم';
    }
  }
}

/// Widget للتحفيز بناءً على التقدم
class MotivationalWidget extends StatelessWidget {
  final Map<String, dynamic> stats;

  const MotivationalWidget({
    Key? key,
    required this.stats,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final currentLevel = stats['currentLevel'] ?? 0;
    final pointsToNext = stats['pointsToNext'] ?? 0;
    final distinctUnitsCount = stats['distinctUnitsCount'] ?? 0;

    String message;
    IconData icon;
    Color color;

    if (pointsToNext < 50) {
      message = 'أنت على وشك الوصول للمستوى التالي! فقط $pointsToNext نقطة';
      icon = Icons.celebration;
      color = Colors.amber;
    } else if (distinctUnitsCount >= 5) {
      message = 'رائع! لقد أكملت $distinctUnitsCount وحدات دراسية';
      icon = Icons.emoji_events;
      color = Colors.green;
    } else if (currentLevel >= 2) {
      message = 'أنت في المستوى $currentLevel! استمر في التقدم';
      icon = Icons.trending_up;
      color = Colors.blue;
    } else {
      message = 'ابدأ رحلتك التعليمية واكسب المزيد من النقاط!';
      icon = Icons.rocket_launch;
      color = Colors.purple;
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.1), color.withOpacity(0.05)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: color.withOpacity(0.9),
              ),
            ),
          ),
        ],
      ),
    );
  }
}