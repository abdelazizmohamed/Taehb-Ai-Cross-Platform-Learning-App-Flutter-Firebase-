import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:taehb/core/themes/theme_cubit.dart';
import 'package:taehb/firebase_options.dart';
import 'auth/bloc/auth_bloc.dart';
import 'auth/bloc/auth_event.dart';
import 'auth/language/language_bloc.dart';
import 'auth/language/language_event.dart';
import 'auth/language/language_state.dart';
import 'data/datasources/local_data_source.dart';
import 'data/datasources/remote_datasource.dart';
import 'data/repositories/auth_repository.dart';
import 'core/themes/theme.dart';
import 'l10n/app_localizations.dart';
import 'screens/splash_screen.dart';
import 'core/utils/navigation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint('Firebase init error: $e');
  }
  await SharedPreferences.getInstance();
  runApp(
    ProviderScope(
      child: const TaehbApp(),
    ),
  );
}

class TaehbApp extends StatefulWidget {
  const TaehbApp({Key? key}) : super(key: key);

  @override
  State<TaehbApp> createState() => _TaehbAppState();
}

class _TaehbAppState extends State<TaehbApp> {
  late AuthRepository authRepository;
  late AuthBloc authBloc;
  late LocalDataSource localDataSource;

  @override
  void initState() {
    super.initState();

    // Initialize dependencies
    final remoteDataSource = RemoteDataSource();
    localDataSource = LocalDataSource();
    authRepository = AuthRepository(remoteDataSource, localDataSource);
    authBloc = AuthBloc(authRepository);
  }

  @override
  void dispose() {
    authBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        // Auth Bloc
        BlocProvider<AuthBloc>(
          create: (context) => AuthBloc(authRepository)
            ..add(const CheckAuthStatus()),
        ),
        // Language Bloc
        BlocProvider<LanguageBloc>(
          create: (context) => LanguageBloc()
            ..add(const LoadSavedLanguage()),
        ),
        // Theme Cubit
        BlocProvider<ThemeCubit>(
          create: (context) => ThemeCubit(localDataSource),
        ),
      ],
      child: BlocBuilder<LanguageBloc, LanguageState>(
        builder: (context, languageState) {
          return BlocBuilder<ThemeCubit, AppThemeMode>(
            builder: (context, themeMode) {
              return MaterialApp(
                title: 'Taehb',
                debugShowCheckedModeBanner: false,

                // Localization
                locale: languageState.locale,
                supportedLocales: const [
                  Locale('en', ''), // English
                  Locale('ar', ''), // Arabic
                ],
                localizationsDelegates: const [
                  AppLocalizations.delegate,
                  GlobalMaterialLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate,
                ],

                // Theme
                theme: AppTheme.lightTheme,
                darkTheme: AppTheme.darkTheme,
                themeMode: context.read<ThemeCubit>().themeMode,

                // Navigation
                navigatorKey: NavigationHelper.navigatorKey,
                home: const SplashScreen(),
                onGenerateRoute: NavigationHelper.generateRoute,
              );
            },
          );
        },
      ),
    );
  }
}