// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'Taehb';

  @override
  String get slogan => 'Prepare today, be ready tomorrow';

  @override
  String get splashLoading => 'Loading...';

  @override
  String get email => 'Email';

  @override
  String get password => 'Password';

  @override
  String get login => 'Login';

  @override
  String get forgotPassword => 'Forgot Password?';

  @override
  String get signUp => 'Sign Up';

  @override
  String get homeTitle => 'Home';

  @override
  String get rememberMe => 'Remember me';

  @override
  String get or => 'OR';

  @override
  String get continueWithGoogle => 'Continue with Google';

  @override
  String get continueWithApple => 'Continue with Apple';

  @override
  String get resetPassword => 'Reset Password';

  @override
  String get enterEmailToReset => 'Enter your email to receive a password reset link.';

  @override
  String get cancel => 'Cancel';

  @override
  String get sendResetLink => 'Send Reset Link';

  @override
  String get welcomeBack => 'Welcome Back';

  @override
  String get loginSubtitle => 'Sign in to continue your learning journey';

  @override
  String get enterYourEmail => 'Enter your email';

  @override
  String get enterYourPassword => 'Enter your password';

  @override
  String get signIn => 'Sign In';

  @override
  String get dontHaveAnAccount => 'Don\'t have an account?';

  @override
  String get confirmLogout => 'Confirm Logout';

  @override
  String get logoutQuestion => 'Are you sure you want to logout?';

  @override
  String get logout => 'Logout';

  @override
  String get comingSoonNewFeature => 'Coming Soon - New Feature!';

  @override
  String get addNew => 'Add New';

  @override
  String get student => 'Student';

  @override
  String get quickStats => 'Quick Stats';

  @override
  String get tests => 'Tests';

  @override
  String get success => 'Success';

  @override
  String get rank => 'Rank';

  @override
  String get availableFeatures => 'Available Features';

  @override
  String get practiceTests => 'Practice Tests';

  @override
  String get practiceVariousTests => 'Practice various test types';

  @override
  String get aiAssistance => 'AI Assistance';

  @override
  String get aiAssistanceSubtitle => 'Smart assistant to improve performance';

  @override
  String get detailedReports => 'Detailed Reports';

  @override
  String get detailedReportsSubtitle => 'Comprehensive analysis of your results';

  @override
  String get recentActivity => 'Recent Activity';

  @override
  String get welcomeToApp => 'Welcome to Taehb!';

  @override
  String get startJourney => 'Start your learning journey and prepare for tests with confidence';

  @override
  String get getStarted => 'Get Started';

  @override
  String get comingSoon => 'Coming Soon!';

  @override
  String get emailRequired => 'Email is required';

  @override
  String get invalidEmail => 'Please enter a valid email address';

  @override
  String get passwordRequired => 'Password is required';

  @override
  String passwordMinLength(int min) {
    return 'Password must be at least $min characters';
  }

  @override
  String get selectKUs => 'Select Knowledge Units';

  @override
  String selectedCount(int count) {
    return '$count selected';
  }

  @override
  String get generatingQuestions => 'Generating Questions...';

  @override
  String processingKUs(int count) {
    return 'Processing $count knowledge units';
  }

  @override
  String questionProgress(int current, int total) {
    return 'Question $current of $total';
  }

  @override
  String get finishExam => 'Finish Exam';

  @override
  String get warning => 'Warning';

  @override
  String notAllAnswered(int answered, int total) {
    return 'You haven\'t answered all questions!\nAnswered $answered out of $total';
  }

  @override
  String get continueAnswering => 'Continue Answering';

  @override
  String get correct => 'Correct';

  @override
  String get wrong => 'Wrong';

  @override
  String get unanswered => 'Unanswered';

  @override
  String get previous => 'Previous';

  @override
  String get next => 'Next';

  @override
  String get finish => 'Finish';

  @override
  String get failedToSaveResults => 'Failed to save results';

  @override
  String get retry => 'Retry';

  @override
  String get resultsSavedSuccessfully => 'Results saved successfully';

  @override
  String get examResults => 'Exam Results';

  @override
  String get excellent => 'Excellent!';

  @override
  String get good => 'Good';

  @override
  String get quickAccess => 'Quick Access';

  @override
  String get tryAgain => 'Try Again';

  @override
  String get correctAnswers => 'Correct';

  @override
  String get wrongAnswers => 'Wrong';

  @override
  String get questionsDetails => 'Questions Details';

  @override
  String questionNumber(int number) {
    return 'Question $number';
  }

  @override
  String get confirmExamStart => 'Confirm Exam Start';

  @override
  String get examInfo => 'Exam Information';

  @override
  String get numberOfQuestions => 'Number of Questions';

  @override
  String questionsCount(int count) {
    return '$count questions';
  }

  @override
  String get selectedUnits => 'Selected Units';

  @override
  String unitsCount(int count) {
    return '$count units';
  }

  @override
  String get expectedTime => 'Expected Time';

  @override
  String estimatedMinutes(int minutes) {
    return '~$minutes minutes';
  }

  @override
  String get importantNotices => 'Important Notices';

  @override
  String get multipleChoiceOnly => 'The exam contains multiple choice questions only';

  @override
  String get answerAllQuestions => 'You must answer all questions before finishing';

  @override
  String get canNavigateQuestions => 'You can navigate between questions and modify answers';

  @override
  String get resultsShownImmediately => 'Results will be shown immediately after finishing';

  @override
  String get agreeMultipleChoice => 'I agree that the exam contains multiple choice questions only';

  @override
  String get readyToStart => 'I am ready to start the exam';

  @override
  String get agreeAndConfirm => 'Please agree to terms and confirm readiness';

  @override
  String get questionsReady => '✓ Questions Ready!';

  @override
  String get preparingQuestions => 'Preparing Questions...';

  @override
  String errorOccurred(String error) {
    return 'Error: $error';
  }

  @override
  String get goBack => 'Go Back';

  @override
  String get retryAgain => 'Retry';

  @override
  String get error => 'Error';

  @override
  String get pleaseWait => 'Please wait a few seconds';

  @override
  String get backToHome => 'Back to Home';

  @override
  String get startExam => 'Start Exam';

  @override
  String get pleaseSelectKU => 'Please select at least one knowledge unit';

  @override
  String get questionsNotRecognized => 'Questions not recognized';

  @override
  String get serverConnectionFailed => 'Server connection failed';

  @override
  String get unableToConnectServer => 'Unable to connect to server';

  @override
  String get kuUserResearch => 'User Research';

  @override
  String get kuInteractionDesign => 'Interaction Design and User Testing';

  @override
  String get kuProjectManagement => 'Project Management Principles';

  @override
  String get kuEthicalIssues => 'Ethical, Legal, and Privacy Issues';

  @override
  String get kuInformationSystems => 'Information Systems Principles';

  @override
  String get kuCyberAttacks => 'Cyber-attacks and Detection';

  @override
  String get kuVulnerabilities => 'Vulnerabilities, Threats, and Risk';

  @override
  String get kuCryptography => 'Cryptography Overview';

  @override
  String get kuSecurityServices => 'Security Services, Mechanisms, and Countermeasures';

  @override
  String get kuNetworkingFoundations => 'Foundations of Networking';

  @override
  String get kuNetworkManagement => 'Network Management';

  @override
  String get kuOperatingSystems => 'Operating Systems';

  @override
  String get kuDataConcepts => 'Data-information Concepts';

  @override
  String get kuDataModeling => 'Data Modeling';

  @override
  String get exitExamWarning => 'Are you sure you want to exit the exam? Your progress will be lost.';

  @override
  String get exit => 'Exit';

  @override
  String get seconds => 'seconds';

  @override
  String get timeUp => 'Time Up';

  @override
  String get kuDatabaseEnvironment => 'Managing the Database Environment';

  @override
  String get kuQueryLanguages => 'Database Query Languages';

  @override
  String get kuRequirementsEngineering => 'Requirements Engineering and Testing';

  @override
  String get kuProblemSolving => 'Problem Solving and Program Development';

  @override
  String get kuDataStructures => 'Fundamentals of Data Structures and Algorithms';

  @override
  String get kuWebMobileSystems => 'Web and Mobile Systems Concepts and Technologies';

  @override
  String versionLabel(Object version) {
    return 'Version $version';
  }

  @override
  String copyright(int year) {
    return '© $year Taehb Educational Solutions';
  }

  @override
  String get pointsEarned => 'Points Earned';

  @override
  String get totalPoints => 'Total Points';

  @override
  String get level => 'Level';

  @override
  String needPoints(int points) {
    return 'Need $points more points';
  }

  @override
  String get score => 'Score';

  @override
  String get passable => 'Passable';

  @override
  String get needsImprovement => 'Needs Improvement';

  @override
  String get questionsReview => 'Questions Review';

  @override
  String get viewHistory => 'View History';

  @override
  String get savingResults => 'Saving results...';

  @override
  String get errorSavingResults => 'Error saving results';

  @override
  String get dailyLoginReward => 'Daily Login Reward';

  @override
  String get youEarned => 'You earned';

  @override
  String get points => 'points';

  @override
  String get loginDaily => 'Login daily to earn more points!';

  @override
  String get awesome => 'Awesome!';

  @override
  String get currentStreak => 'Current Streak';

  @override
  String get longestStreak => 'Longest Streak';

  @override
  String get days => 'days';

  @override
  String get loggedInToday => 'You logged in today! Come back tomorrow to continue the streak';

  @override
  String get loginStreakTitle => 'Login Streak';

  @override
  String get progressToNextLevel => 'Progress to Next Level';

  @override
  String get completed => 'Completed';

  @override
  String get motivationalMessage => 'Keep going!';

  @override
  String get examHistory => 'Exam History';

  @override
  String get noExamHistory => 'No exam history yet';

  @override
  String get takeFirstExam => 'Take your first exam to see results here';

  @override
  String get yourStatistics => 'Your Statistics';

  @override
  String get attempts => 'Attempts';

  @override
  String get avgScore => 'Avg Score';

  @override
  String get best => 'Best';

  @override
  String get examDetails => 'Exam Details';

  @override
  String get date => 'Date';

  @override
  String get selectedKUs => 'Selected KUs';

  @override
  String get questionResults => 'Question Results';

  @override
  String get yourAnswer => 'Your answer';

  @override
  String get correctAnswer => 'Correct answer';

  @override
  String get notAnswered => 'Not answered';

  @override
  String get close => 'Close';

  @override
  String get leaderboard => 'Leaderboard';

  @override
  String get topPerformers => 'Top Performers';

  @override
  String get refresh => 'Refresh';

  @override
  String get errorLoadingLeaderboard => 'Error loading leaderboard';

  @override
  String get noLeaderboardData => 'No leaderboard data';

  @override
  String get beFirstToCompete => 'Be the first to compete!';

  @override
  String get you => 'You';

  @override
  String get pts => 'pts';

  @override
  String get units => 'units';

  @override
  String get changePassword => 'Change Password';

  @override
  String get currentPassword => 'Current Password';

  @override
  String get newPassword => 'New Password';

  @override
  String get confirmPassword => 'Confirm Password';

  @override
  String get changePasswordSuccess => 'Password changed successfully';

  @override
  String get pleaseEnterCurrentPassword => 'Please enter your current password';

  @override
  String get pleaseEnterNewPassword => 'Please enter a new password';

  @override
  String get pleaseConfirmNewPassword => 'Please confirm your new password';

  @override
  String get passwordsDoNotMatch => 'Passwords do not match';

  @override
  String get passwordRequirements => 'Password must be at least 6 characters long';

  @override
  String get newPasswordSameAsOld => 'New password must be different from current password';

  @override
  String get notifications => 'Notifications';

  @override
  String get noNotifications => 'No notifications';

  @override
  String get settings => 'Settings';

  @override
  String get language => 'Language';

  @override
  String get darkMode => 'Dark Mode';

  @override
  String get helpAndSupport => 'Help & Support';

  @override
  String get about => 'About';

  @override
  String get logoutSuccess => 'Logout successful';

  @override
  String get errorLoggingOut => 'Error logging out';

  @override
  String get logoutConfirmation => 'Are you sure you want to logout?';

  @override
  String get errorLoggingIn => 'Error logging in';

  @override
  String get editProfile => 'Edit Profile';

  @override
  String get profile => 'Profile';

  @override
  String get chooseTheme => 'Choose your preferred theme';

  @override
  String get systemDefault => 'System Default';

  @override
  String get lightMode => 'Light Theme';

  @override
  String get lightModeDescription => 'Bright and clear appearance';

  @override
  String get darkModeDescription => 'Easy on the eyes in low light';

  @override
  String get systemDefaultDescription => 'Follow system settings';

  @override
  String get pointsHistory => 'Points History';

  @override
  String get pointsBreakdown => 'Points Breakdown';

  @override
  String get noPointsHistory => 'No points history';

  @override
  String get earnPointsByTakingQuizzes => 'Earn points by taking quizzes and daily activities';

  @override
  String get toNextLevel => 'To Next Level';

  @override
  String get quizCompleted => 'Quiz Completed';

  @override
  String get dailyLoginBonus => 'Daily login bonus';

  @override
  String get firstExamBonus => 'First Exam Bonus';

  @override
  String get congratsFirstExam => 'Congrats on completing your first exam!';

  @override
  String get levelUpBonus => 'Level Up Bonus';

  @override
  String get reachedNewLevel => 'You reached a new level!';

  @override
  String get justNow => 'Just now';

  @override
  String get aiAssistant => 'AI Assistant';

  @override
  String get onlineNow => 'Online now';

  @override
  String get clearChat => 'Clear Chat';

  @override
  String get clearChatConfirm => 'Do you want to delete all messages?';

  @override
  String get clear => 'Clear';

  @override
  String get typeMessage => 'Type your message...';

  @override
  String get topicSummary => 'Topic Summary';

  @override
  String get howToNavigate => 'How to Navigate';

  @override
  String get generalQuestion => 'General Question';

  @override
  String get studyTopicSummary => 'Study Topic Summary';

  @override
  String get exampleTopic => 'Example: User Research';

  @override
  String get create => 'Create';

  @override
  String get chooseFeature => 'Choose Feature';

  @override
  String iWantSummaryAbout(String topic) {
    return 'I want a summary about: $topic';
  }

  @override
  String howDoIAccess(String feature) {
    return 'How do I access $feature?';
  }

  @override
  String get welcomeMessage => 'Hello! 👋 I\'m your smart assistant in the Taehb app.\n\nI can help you with:\n• App navigation\n• Feature explanations\n• Study summaries\n• Answering your questions\n\nHow can I help you today? 😊';

  @override
  String get helloAgain => 'Hello again! How can I help you? 😊';

  @override
  String get errorOccurre => 'Sorry, an error occurred. Please try again.';

  @override
  String get couldntProcess => 'Sorry, I couldn\'t process your request. Please check your internet connection.';

  @override
  String get couldntCreateSummary => 'Sorry, I couldn\'t create the summary.';

  @override
  String get couldntHelp => 'Sorry, I couldn\'t help.';

  @override
  String get now => 'Now';

  @override
  String minutesAgo(int count) {
    return '${count}m ago';
  }

  @override
  String hoursAgo(int count) {
    return '${count}h ago';
  }

  @override
  String get featureTests => 'Tests';

  @override
  String get featureProfile => 'Profile';

  @override
  String get featureLeaderboard => 'Leaderboard';

  @override
  String get featurePointsHistory => 'Points History';

  @override
  String get featureDailyReward => 'Daily Reward';

  @override
  String get knowledgeUnits => 'Knowledge Units';

  @override
  String get chooseKnowledgeUnit => 'Choose Knowledge Unit';

  @override
  String get errorLoadingKU => 'Error loading knowledge units';

  @override
  String generateQuestionsFor(Object topic) {
    return 'I want questions about: $topic';
  }

  @override
  String get errorGeneratingQuestions => 'Sorry, an error occurred while generating questions';

  @override
  String get courseMaterials => 'Course Materials';

  @override
  String get selectKnowledgeUnits => 'Select Knowledge Units to Study';

  @override
  String get selectUnitsHint => 'Select one or more units, then tap \"Generate Summary\" for a detailed overview';

  @override
  String get selected => 'Selected';

  @override
  String get generateSummary => 'Generate Summary';

  @override
  String get detailedSummary => 'Detailed Summary';

  @override
  String get dismiss => 'Dismiss';

  @override
  String get topics => 'topics';

  @override
  String get knowledgeUnit => 'Knowledge Unit';

  @override
  String get userResearch => 'User Research';

  @override
  String get interactionDesign => 'Interaction Design and User Testing';

  @override
  String get projectManagement => 'Project Management Principles';

  @override
  String get cryptography => 'Cryptography Overview';

  @override
  String get operatingSystems => 'Operating Systems';

  @override
  String get databaseQuery => 'Database Query Languages';

  @override
  String get webMobile => 'Web and Mobile Systems';

  @override
  String get noUnitsSelected => 'Please select at least one Knowledge Unit';

  @override
  String get generatingSummary => 'Generating Summary...';

  @override
  String get summaryGenerated => 'Summary Generated Successfully';

  @override
  String get howCanWeHelp => 'How Can We Help You?';

  @override
  String get contactUs => 'Contact Us';

  @override
  String get phone => 'Phone';

  @override
  String get whatsapp => 'WhatsApp';

  @override
  String get frequentlyAskedQuestions => 'Frequently Asked Questions';

  @override
  String get quickLinks => 'Quick Links';

  @override
  String get userGuide => 'User Guide';

  @override
  String get privacyPolicy => 'Privacy Policy';

  @override
  String get termsOfService => 'Terms of Service';

  @override
  String get appVersion => 'App Version';

  @override
  String get faqQuestion1 => 'How do I start a new exam?';

  @override
  String get faqAnswer1 => 'Go to the home screen, select \'Exam\', choose your knowledge unit, and click \'Start Exam\'.';

  @override
  String get faqQuestion2 => 'How is my score calculated?';

  @override
  String get faqAnswer2 => 'You earn 5 points for each correct answer, with bonus points for difficult questions and fast responses.';

  @override
  String get faqQuestion3 => 'Can I review my previous exams?';

  @override
  String get faqAnswer3 => 'Yes! Go to your Profile, then select \'Exam History\' to view all your past exam results and details.';

  @override
  String get faqQuestion4 => 'How do I earn points and level up?';

  @override
  String get faqAnswer4 => 'Complete exams, answer correctly, login daily, and complete study sessions to earn points and advance through levels.';
}
