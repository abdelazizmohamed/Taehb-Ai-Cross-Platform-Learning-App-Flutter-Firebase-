import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @appName.
  ///
  /// In en, this message translates to:
  /// **'Taehb'**
  String get appName;

  /// No description provided for @slogan.
  ///
  /// In en, this message translates to:
  /// **'Prepare today, be ready tomorrow'**
  String get slogan;

  /// No description provided for @splashLoading.
  ///
  /// In en, this message translates to:
  /// **'Loading...'**
  String get splashLoading;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login;

  /// No description provided for @forgotPassword.
  ///
  /// In en, this message translates to:
  /// **'Forgot Password?'**
  String get forgotPassword;

  /// No description provided for @signUp.
  ///
  /// In en, this message translates to:
  /// **'Sign Up'**
  String get signUp;

  /// No description provided for @homeTitle.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get homeTitle;

  /// No description provided for @rememberMe.
  ///
  /// In en, this message translates to:
  /// **'Remember me'**
  String get rememberMe;

  /// No description provided for @or.
  ///
  /// In en, this message translates to:
  /// **'OR'**
  String get or;

  /// No description provided for @continueWithGoogle.
  ///
  /// In en, this message translates to:
  /// **'Continue with Google'**
  String get continueWithGoogle;

  /// No description provided for @continueWithApple.
  ///
  /// In en, this message translates to:
  /// **'Continue with Apple'**
  String get continueWithApple;

  /// No description provided for @resetPassword.
  ///
  /// In en, this message translates to:
  /// **'Reset Password'**
  String get resetPassword;

  /// No description provided for @enterEmailToReset.
  ///
  /// In en, this message translates to:
  /// **'Enter your email to receive a password reset link.'**
  String get enterEmailToReset;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @sendResetLink.
  ///
  /// In en, this message translates to:
  /// **'Send Reset Link'**
  String get sendResetLink;

  /// No description provided for @welcomeBack.
  ///
  /// In en, this message translates to:
  /// **'Welcome Back'**
  String get welcomeBack;

  /// No description provided for @loginSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Sign in to continue your learning journey'**
  String get loginSubtitle;

  /// No description provided for @enterYourEmail.
  ///
  /// In en, this message translates to:
  /// **'Enter your email'**
  String get enterYourEmail;

  /// No description provided for @enterYourPassword.
  ///
  /// In en, this message translates to:
  /// **'Enter your password'**
  String get enterYourPassword;

  /// No description provided for @signIn.
  ///
  /// In en, this message translates to:
  /// **'Sign In'**
  String get signIn;

  /// No description provided for @dontHaveAnAccount.
  ///
  /// In en, this message translates to:
  /// **'Don\'t have an account?'**
  String get dontHaveAnAccount;

  /// No description provided for @confirmLogout.
  ///
  /// In en, this message translates to:
  /// **'Confirm Logout'**
  String get confirmLogout;

  /// No description provided for @logoutQuestion.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to logout?'**
  String get logoutQuestion;

  /// No description provided for @logout.
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout;

  /// No description provided for @comingSoonNewFeature.
  ///
  /// In en, this message translates to:
  /// **'Coming Soon - New Feature!'**
  String get comingSoonNewFeature;

  /// No description provided for @addNew.
  ///
  /// In en, this message translates to:
  /// **'Add New'**
  String get addNew;

  /// No description provided for @student.
  ///
  /// In en, this message translates to:
  /// **'Student'**
  String get student;

  /// No description provided for @quickStats.
  ///
  /// In en, this message translates to:
  /// **'Quick Stats'**
  String get quickStats;

  /// No description provided for @tests.
  ///
  /// In en, this message translates to:
  /// **'Tests'**
  String get tests;

  /// No description provided for @success.
  ///
  /// In en, this message translates to:
  /// **'Success'**
  String get success;

  /// No description provided for @rank.
  ///
  /// In en, this message translates to:
  /// **'Rank'**
  String get rank;

  /// No description provided for @availableFeatures.
  ///
  /// In en, this message translates to:
  /// **'Available Features'**
  String get availableFeatures;

  /// No description provided for @practiceTests.
  ///
  /// In en, this message translates to:
  /// **'Practice Tests'**
  String get practiceTests;

  /// No description provided for @practiceVariousTests.
  ///
  /// In en, this message translates to:
  /// **'Practice various test types'**
  String get practiceVariousTests;

  /// No description provided for @aiAssistance.
  ///
  /// In en, this message translates to:
  /// **'AI Assistance'**
  String get aiAssistance;

  /// No description provided for @aiAssistanceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Smart assistant to improve performance'**
  String get aiAssistanceSubtitle;

  /// No description provided for @detailedReports.
  ///
  /// In en, this message translates to:
  /// **'Detailed Reports'**
  String get detailedReports;

  /// No description provided for @detailedReportsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Comprehensive analysis of your results'**
  String get detailedReportsSubtitle;

  /// No description provided for @recentActivity.
  ///
  /// In en, this message translates to:
  /// **'Recent Activity'**
  String get recentActivity;

  /// No description provided for @welcomeToApp.
  ///
  /// In en, this message translates to:
  /// **'Welcome to Taehb!'**
  String get welcomeToApp;

  /// No description provided for @startJourney.
  ///
  /// In en, this message translates to:
  /// **'Start your learning journey and prepare for tests with confidence'**
  String get startJourney;

  /// No description provided for @getStarted.
  ///
  /// In en, this message translates to:
  /// **'Get Started'**
  String get getStarted;

  /// No description provided for @comingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming Soon!'**
  String get comingSoon;

  /// No description provided for @emailRequired.
  ///
  /// In en, this message translates to:
  /// **'Email is required'**
  String get emailRequired;

  /// No description provided for @invalidEmail.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid email address'**
  String get invalidEmail;

  /// No description provided for @passwordRequired.
  ///
  /// In en, this message translates to:
  /// **'Password is required'**
  String get passwordRequired;

  /// No description provided for @passwordMinLength.
  ///
  /// In en, this message translates to:
  /// **'Password must be at least {min} characters'**
  String passwordMinLength(int min);

  /// No description provided for @selectKUs.
  ///
  /// In en, this message translates to:
  /// **'Select Knowledge Units'**
  String get selectKUs;

  /// No description provided for @selectedCount.
  ///
  /// In en, this message translates to:
  /// **'{count} selected'**
  String selectedCount(int count);

  /// No description provided for @generatingQuestions.
  ///
  /// In en, this message translates to:
  /// **'Generating Questions...'**
  String get generatingQuestions;

  /// No description provided for @processingKUs.
  ///
  /// In en, this message translates to:
  /// **'Processing {count} knowledge units'**
  String processingKUs(int count);

  /// No description provided for @questionProgress.
  ///
  /// In en, this message translates to:
  /// **'Question {current} of {total}'**
  String questionProgress(int current, int total);

  /// No description provided for @finishExam.
  ///
  /// In en, this message translates to:
  /// **'Finish Exam'**
  String get finishExam;

  /// No description provided for @warning.
  ///
  /// In en, this message translates to:
  /// **'Warning'**
  String get warning;

  /// No description provided for @notAllAnswered.
  ///
  /// In en, this message translates to:
  /// **'You haven\'t answered all questions!\nAnswered {answered} out of {total}'**
  String notAllAnswered(int answered, int total);

  /// No description provided for @continueAnswering.
  ///
  /// In en, this message translates to:
  /// **'Continue Answering'**
  String get continueAnswering;

  /// No description provided for @correct.
  ///
  /// In en, this message translates to:
  /// **'Correct'**
  String get correct;

  /// No description provided for @wrong.
  ///
  /// In en, this message translates to:
  /// **'Wrong'**
  String get wrong;

  /// No description provided for @unanswered.
  ///
  /// In en, this message translates to:
  /// **'Unanswered'**
  String get unanswered;

  /// No description provided for @previous.
  ///
  /// In en, this message translates to:
  /// **'Previous'**
  String get previous;

  /// No description provided for @next.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get next;

  /// No description provided for @finish.
  ///
  /// In en, this message translates to:
  /// **'Finish'**
  String get finish;

  /// No description provided for @failedToSaveResults.
  ///
  /// In en, this message translates to:
  /// **'Failed to save results'**
  String get failedToSaveResults;

  /// No description provided for @retry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get retry;

  /// No description provided for @resultsSavedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Results saved successfully'**
  String get resultsSavedSuccessfully;

  /// No description provided for @examResults.
  ///
  /// In en, this message translates to:
  /// **'Exam Results'**
  String get examResults;

  /// No description provided for @excellent.
  ///
  /// In en, this message translates to:
  /// **'Excellent!'**
  String get excellent;

  /// No description provided for @good.
  ///
  /// In en, this message translates to:
  /// **'Good'**
  String get good;

  /// No description provided for @quickAccess.
  ///
  /// In en, this message translates to:
  /// **'Quick Access'**
  String get quickAccess;

  /// No description provided for @tryAgain.
  ///
  /// In en, this message translates to:
  /// **'Try Again'**
  String get tryAgain;

  /// No description provided for @correctAnswers.
  ///
  /// In en, this message translates to:
  /// **'Correct'**
  String get correctAnswers;

  /// No description provided for @wrongAnswers.
  ///
  /// In en, this message translates to:
  /// **'Wrong'**
  String get wrongAnswers;

  /// No description provided for @questionsDetails.
  ///
  /// In en, this message translates to:
  /// **'Questions Details'**
  String get questionsDetails;

  /// No description provided for @questionNumber.
  ///
  /// In en, this message translates to:
  /// **'Question {number}'**
  String questionNumber(int number);

  /// No description provided for @confirmExamStart.
  ///
  /// In en, this message translates to:
  /// **'Confirm Exam Start'**
  String get confirmExamStart;

  /// No description provided for @examInfo.
  ///
  /// In en, this message translates to:
  /// **'Exam Information'**
  String get examInfo;

  /// No description provided for @numberOfQuestions.
  ///
  /// In en, this message translates to:
  /// **'Number of Questions'**
  String get numberOfQuestions;

  /// No description provided for @questionsCount.
  ///
  /// In en, this message translates to:
  /// **'{count} questions'**
  String questionsCount(int count);

  /// No description provided for @selectedUnits.
  ///
  /// In en, this message translates to:
  /// **'Selected Units'**
  String get selectedUnits;

  /// No description provided for @unitsCount.
  ///
  /// In en, this message translates to:
  /// **'{count} units'**
  String unitsCount(int count);

  /// No description provided for @expectedTime.
  ///
  /// In en, this message translates to:
  /// **'Expected Time'**
  String get expectedTime;

  /// No description provided for @estimatedMinutes.
  ///
  /// In en, this message translates to:
  /// **'~{minutes} minutes'**
  String estimatedMinutes(int minutes);

  /// No description provided for @importantNotices.
  ///
  /// In en, this message translates to:
  /// **'Important Notices'**
  String get importantNotices;

  /// No description provided for @multipleChoiceOnly.
  ///
  /// In en, this message translates to:
  /// **'The exam contains multiple choice questions only'**
  String get multipleChoiceOnly;

  /// No description provided for @answerAllQuestions.
  ///
  /// In en, this message translates to:
  /// **'You must answer all questions before finishing'**
  String get answerAllQuestions;

  /// No description provided for @canNavigateQuestions.
  ///
  /// In en, this message translates to:
  /// **'You can navigate between questions and modify answers'**
  String get canNavigateQuestions;

  /// No description provided for @resultsShownImmediately.
  ///
  /// In en, this message translates to:
  /// **'Results will be shown immediately after finishing'**
  String get resultsShownImmediately;

  /// No description provided for @agreeMultipleChoice.
  ///
  /// In en, this message translates to:
  /// **'I agree that the exam contains multiple choice questions only'**
  String get agreeMultipleChoice;

  /// No description provided for @readyToStart.
  ///
  /// In en, this message translates to:
  /// **'I am ready to start the exam'**
  String get readyToStart;

  /// No description provided for @agreeAndConfirm.
  ///
  /// In en, this message translates to:
  /// **'Please agree to terms and confirm readiness'**
  String get agreeAndConfirm;

  /// No description provided for @questionsReady.
  ///
  /// In en, this message translates to:
  /// **'✓ Questions Ready!'**
  String get questionsReady;

  /// No description provided for @preparingQuestions.
  ///
  /// In en, this message translates to:
  /// **'Preparing Questions...'**
  String get preparingQuestions;

  /// No description provided for @errorOccurred.
  ///
  /// In en, this message translates to:
  /// **'Error: {error}'**
  String errorOccurred(String error);

  /// No description provided for @goBack.
  ///
  /// In en, this message translates to:
  /// **'Go Back'**
  String get goBack;

  /// No description provided for @retryAgain.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get retryAgain;

  /// No description provided for @error.
  ///
  /// In en, this message translates to:
  /// **'Error'**
  String get error;

  /// No description provided for @pleaseWait.
  ///
  /// In en, this message translates to:
  /// **'Please wait a few seconds'**
  String get pleaseWait;

  /// No description provided for @backToHome.
  ///
  /// In en, this message translates to:
  /// **'Back to Home'**
  String get backToHome;

  /// No description provided for @startExam.
  ///
  /// In en, this message translates to:
  /// **'Start Exam'**
  String get startExam;

  /// No description provided for @pleaseSelectKU.
  ///
  /// In en, this message translates to:
  /// **'Please select at least one knowledge unit'**
  String get pleaseSelectKU;

  /// No description provided for @questionsNotRecognized.
  ///
  /// In en, this message translates to:
  /// **'Questions not recognized'**
  String get questionsNotRecognized;

  /// No description provided for @serverConnectionFailed.
  ///
  /// In en, this message translates to:
  /// **'Server connection failed'**
  String get serverConnectionFailed;

  /// No description provided for @unableToConnectServer.
  ///
  /// In en, this message translates to:
  /// **'Unable to connect to server'**
  String get unableToConnectServer;

  /// No description provided for @kuUserResearch.
  ///
  /// In en, this message translates to:
  /// **'User Research'**
  String get kuUserResearch;

  /// No description provided for @kuInteractionDesign.
  ///
  /// In en, this message translates to:
  /// **'Interaction Design and User Testing'**
  String get kuInteractionDesign;

  /// No description provided for @kuProjectManagement.
  ///
  /// In en, this message translates to:
  /// **'Project Management Principles'**
  String get kuProjectManagement;

  /// No description provided for @kuEthicalIssues.
  ///
  /// In en, this message translates to:
  /// **'Ethical, Legal, and Privacy Issues'**
  String get kuEthicalIssues;

  /// No description provided for @kuInformationSystems.
  ///
  /// In en, this message translates to:
  /// **'Information Systems Principles'**
  String get kuInformationSystems;

  /// No description provided for @kuCyberAttacks.
  ///
  /// In en, this message translates to:
  /// **'Cyber-attacks and Detection'**
  String get kuCyberAttacks;

  /// No description provided for @kuVulnerabilities.
  ///
  /// In en, this message translates to:
  /// **'Vulnerabilities, Threats, and Risk'**
  String get kuVulnerabilities;

  /// No description provided for @kuCryptography.
  ///
  /// In en, this message translates to:
  /// **'Cryptography Overview'**
  String get kuCryptography;

  /// No description provided for @kuSecurityServices.
  ///
  /// In en, this message translates to:
  /// **'Security Services, Mechanisms, and Countermeasures'**
  String get kuSecurityServices;

  /// No description provided for @kuNetworkingFoundations.
  ///
  /// In en, this message translates to:
  /// **'Foundations of Networking'**
  String get kuNetworkingFoundations;

  /// No description provided for @kuNetworkManagement.
  ///
  /// In en, this message translates to:
  /// **'Network Management'**
  String get kuNetworkManagement;

  /// No description provided for @kuOperatingSystems.
  ///
  /// In en, this message translates to:
  /// **'Operating Systems'**
  String get kuOperatingSystems;

  /// No description provided for @kuDataConcepts.
  ///
  /// In en, this message translates to:
  /// **'Data-information Concepts'**
  String get kuDataConcepts;

  /// No description provided for @kuDataModeling.
  ///
  /// In en, this message translates to:
  /// **'Data Modeling'**
  String get kuDataModeling;

  /// Warning message when user tries to exit the exam
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to exit the exam? Your progress will be lost.'**
  String get exitExamWarning;

  /// Exit button text
  ///
  /// In en, this message translates to:
  /// **'Exit'**
  String get exit;

  /// Time unit for seconds
  ///
  /// In en, this message translates to:
  /// **'seconds'**
  String get seconds;

  /// Message shown when time expires for a question
  ///
  /// In en, this message translates to:
  /// **'Time Up'**
  String get timeUp;

  /// No description provided for @kuDatabaseEnvironment.
  ///
  /// In en, this message translates to:
  /// **'Managing the Database Environment'**
  String get kuDatabaseEnvironment;

  /// No description provided for @kuQueryLanguages.
  ///
  /// In en, this message translates to:
  /// **'Database Query Languages'**
  String get kuQueryLanguages;

  /// No description provided for @kuRequirementsEngineering.
  ///
  /// In en, this message translates to:
  /// **'Requirements Engineering and Testing'**
  String get kuRequirementsEngineering;

  /// No description provided for @kuProblemSolving.
  ///
  /// In en, this message translates to:
  /// **'Problem Solving and Program Development'**
  String get kuProblemSolving;

  /// No description provided for @kuDataStructures.
  ///
  /// In en, this message translates to:
  /// **'Fundamentals of Data Structures and Algorithms'**
  String get kuDataStructures;

  /// No description provided for @kuWebMobileSystems.
  ///
  /// In en, this message translates to:
  /// **'Web and Mobile Systems Concepts and Technologies'**
  String get kuWebMobileSystems;

  /// No description provided for @versionLabel.
  ///
  /// In en, this message translates to:
  /// **'Version {version}'**
  String versionLabel(Object version);

  /// No description provided for @copyright.
  ///
  /// In en, this message translates to:
  /// **'© {year} Taehb Educational Solutions'**
  String copyright(int year);

  /// No description provided for @pointsEarned.
  ///
  /// In en, this message translates to:
  /// **'Points Earned'**
  String get pointsEarned;

  /// No description provided for @totalPoints.
  ///
  /// In en, this message translates to:
  /// **'Total Points'**
  String get totalPoints;

  /// No description provided for @level.
  ///
  /// In en, this message translates to:
  /// **'Level'**
  String get level;

  /// No description provided for @needPoints.
  ///
  /// In en, this message translates to:
  /// **'Need {points} more points'**
  String needPoints(int points);

  /// No description provided for @score.
  ///
  /// In en, this message translates to:
  /// **'Score'**
  String get score;

  /// No description provided for @passable.
  ///
  /// In en, this message translates to:
  /// **'Passable'**
  String get passable;

  /// No description provided for @needsImprovement.
  ///
  /// In en, this message translates to:
  /// **'Needs Improvement'**
  String get needsImprovement;

  /// No description provided for @questionsReview.
  ///
  /// In en, this message translates to:
  /// **'Questions Review'**
  String get questionsReview;

  /// No description provided for @viewHistory.
  ///
  /// In en, this message translates to:
  /// **'View History'**
  String get viewHistory;

  /// No description provided for @savingResults.
  ///
  /// In en, this message translates to:
  /// **'Saving results...'**
  String get savingResults;

  /// No description provided for @errorSavingResults.
  ///
  /// In en, this message translates to:
  /// **'Error saving results'**
  String get errorSavingResults;

  /// No description provided for @dailyLoginReward.
  ///
  /// In en, this message translates to:
  /// **'Daily Login Reward'**
  String get dailyLoginReward;

  /// No description provided for @youEarned.
  ///
  /// In en, this message translates to:
  /// **'You earned'**
  String get youEarned;

  /// No description provided for @points.
  ///
  /// In en, this message translates to:
  /// **'points'**
  String get points;

  /// No description provided for @loginDaily.
  ///
  /// In en, this message translates to:
  /// **'Login daily to earn more points!'**
  String get loginDaily;

  /// No description provided for @awesome.
  ///
  /// In en, this message translates to:
  /// **'Awesome!'**
  String get awesome;

  /// No description provided for @currentStreak.
  ///
  /// In en, this message translates to:
  /// **'Current Streak'**
  String get currentStreak;

  /// No description provided for @longestStreak.
  ///
  /// In en, this message translates to:
  /// **'Longest Streak'**
  String get longestStreak;

  /// No description provided for @days.
  ///
  /// In en, this message translates to:
  /// **'days'**
  String get days;

  /// No description provided for @loggedInToday.
  ///
  /// In en, this message translates to:
  /// **'You logged in today! Come back tomorrow to continue the streak'**
  String get loggedInToday;

  /// No description provided for @loginStreakTitle.
  ///
  /// In en, this message translates to:
  /// **'Login Streak'**
  String get loginStreakTitle;

  /// No description provided for @progressToNextLevel.
  ///
  /// In en, this message translates to:
  /// **'Progress to Next Level'**
  String get progressToNextLevel;

  /// No description provided for @completed.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get completed;

  /// No description provided for @motivationalMessage.
  ///
  /// In en, this message translates to:
  /// **'Keep going!'**
  String get motivationalMessage;

  /// No description provided for @examHistory.
  ///
  /// In en, this message translates to:
  /// **'Exam History'**
  String get examHistory;

  /// No description provided for @noExamHistory.
  ///
  /// In en, this message translates to:
  /// **'No exam history yet'**
  String get noExamHistory;

  /// No description provided for @takeFirstExam.
  ///
  /// In en, this message translates to:
  /// **'Take your first exam to see results here'**
  String get takeFirstExam;

  /// No description provided for @yourStatistics.
  ///
  /// In en, this message translates to:
  /// **'Your Statistics'**
  String get yourStatistics;

  /// No description provided for @attempts.
  ///
  /// In en, this message translates to:
  /// **'Attempts'**
  String get attempts;

  /// No description provided for @avgScore.
  ///
  /// In en, this message translates to:
  /// **'Avg Score'**
  String get avgScore;

  /// No description provided for @best.
  ///
  /// In en, this message translates to:
  /// **'Best'**
  String get best;

  /// No description provided for @examDetails.
  ///
  /// In en, this message translates to:
  /// **'Exam Details'**
  String get examDetails;

  /// No description provided for @date.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get date;

  /// No description provided for @selectedKUs.
  ///
  /// In en, this message translates to:
  /// **'Selected KUs'**
  String get selectedKUs;

  /// No description provided for @questionResults.
  ///
  /// In en, this message translates to:
  /// **'Question Results'**
  String get questionResults;

  /// No description provided for @yourAnswer.
  ///
  /// In en, this message translates to:
  /// **'Your answer'**
  String get yourAnswer;

  /// No description provided for @correctAnswer.
  ///
  /// In en, this message translates to:
  /// **'Correct answer'**
  String get correctAnswer;

  /// No description provided for @notAnswered.
  ///
  /// In en, this message translates to:
  /// **'Not answered'**
  String get notAnswered;

  /// No description provided for @close.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get close;

  /// No description provided for @leaderboard.
  ///
  /// In en, this message translates to:
  /// **'Leaderboard'**
  String get leaderboard;

  /// No description provided for @topPerformers.
  ///
  /// In en, this message translates to:
  /// **'Top Performers'**
  String get topPerformers;

  /// No description provided for @refresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get refresh;

  /// No description provided for @errorLoadingLeaderboard.
  ///
  /// In en, this message translates to:
  /// **'Error loading leaderboard'**
  String get errorLoadingLeaderboard;

  /// No description provided for @noLeaderboardData.
  ///
  /// In en, this message translates to:
  /// **'No leaderboard data'**
  String get noLeaderboardData;

  /// No description provided for @beFirstToCompete.
  ///
  /// In en, this message translates to:
  /// **'Be the first to compete!'**
  String get beFirstToCompete;

  /// No description provided for @you.
  ///
  /// In en, this message translates to:
  /// **'You'**
  String get you;

  /// No description provided for @pts.
  ///
  /// In en, this message translates to:
  /// **'pts'**
  String get pts;

  /// No description provided for @units.
  ///
  /// In en, this message translates to:
  /// **'units'**
  String get units;

  /// No description provided for @changePassword.
  ///
  /// In en, this message translates to:
  /// **'Change Password'**
  String get changePassword;

  /// No description provided for @currentPassword.
  ///
  /// In en, this message translates to:
  /// **'Current Password'**
  String get currentPassword;

  /// No description provided for @newPassword.
  ///
  /// In en, this message translates to:
  /// **'New Password'**
  String get newPassword;

  /// No description provided for @confirmPassword.
  ///
  /// In en, this message translates to:
  /// **'Confirm Password'**
  String get confirmPassword;

  /// No description provided for @changePasswordSuccess.
  ///
  /// In en, this message translates to:
  /// **'Password changed successfully'**
  String get changePasswordSuccess;

  /// No description provided for @pleaseEnterCurrentPassword.
  ///
  /// In en, this message translates to:
  /// **'Please enter your current password'**
  String get pleaseEnterCurrentPassword;

  /// No description provided for @pleaseEnterNewPassword.
  ///
  /// In en, this message translates to:
  /// **'Please enter a new password'**
  String get pleaseEnterNewPassword;

  /// No description provided for @pleaseConfirmNewPassword.
  ///
  /// In en, this message translates to:
  /// **'Please confirm your new password'**
  String get pleaseConfirmNewPassword;

  /// No description provided for @passwordsDoNotMatch.
  ///
  /// In en, this message translates to:
  /// **'Passwords do not match'**
  String get passwordsDoNotMatch;

  /// No description provided for @passwordRequirements.
  ///
  /// In en, this message translates to:
  /// **'Password must be at least 6 characters long'**
  String get passwordRequirements;

  /// No description provided for @newPasswordSameAsOld.
  ///
  /// In en, this message translates to:
  /// **'New password must be different from current password'**
  String get newPasswordSameAsOld;

  /// No description provided for @notifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notifications;

  /// No description provided for @noNotifications.
  ///
  /// In en, this message translates to:
  /// **'No notifications'**
  String get noNotifications;

  /// No description provided for @settings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings;

  /// No description provided for @language.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get language;

  /// No description provided for @darkMode.
  ///
  /// In en, this message translates to:
  /// **'Dark Mode'**
  String get darkMode;

  /// No description provided for @helpAndSupport.
  ///
  /// In en, this message translates to:
  /// **'Help & Support'**
  String get helpAndSupport;

  /// No description provided for @about.
  ///
  /// In en, this message translates to:
  /// **'About'**
  String get about;

  /// No description provided for @logoutSuccess.
  ///
  /// In en, this message translates to:
  /// **'Logout successful'**
  String get logoutSuccess;

  /// No description provided for @errorLoggingOut.
  ///
  /// In en, this message translates to:
  /// **'Error logging out'**
  String get errorLoggingOut;

  /// No description provided for @logoutConfirmation.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to logout?'**
  String get logoutConfirmation;

  /// No description provided for @errorLoggingIn.
  ///
  /// In en, this message translates to:
  /// **'Error logging in'**
  String get errorLoggingIn;

  /// No description provided for @editProfile.
  ///
  /// In en, this message translates to:
  /// **'Edit Profile'**
  String get editProfile;

  /// No description provided for @profile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get profile;

  /// No description provided for @chooseTheme.
  ///
  /// In en, this message translates to:
  /// **'Choose your preferred theme'**
  String get chooseTheme;

  /// No description provided for @systemDefault.
  ///
  /// In en, this message translates to:
  /// **'System Default'**
  String get systemDefault;

  /// No description provided for @lightMode.
  ///
  /// In en, this message translates to:
  /// **'Light Theme'**
  String get lightMode;

  /// No description provided for @lightModeDescription.
  ///
  /// In en, this message translates to:
  /// **'Bright and clear appearance'**
  String get lightModeDescription;

  /// No description provided for @darkModeDescription.
  ///
  /// In en, this message translates to:
  /// **'Easy on the eyes in low light'**
  String get darkModeDescription;

  /// No description provided for @systemDefaultDescription.
  ///
  /// In en, this message translates to:
  /// **'Follow system settings'**
  String get systemDefaultDescription;

  /// No description provided for @pointsHistory.
  ///
  /// In en, this message translates to:
  /// **'Points History'**
  String get pointsHistory;

  /// No description provided for @pointsBreakdown.
  ///
  /// In en, this message translates to:
  /// **'Points Breakdown'**
  String get pointsBreakdown;

  /// No description provided for @noPointsHistory.
  ///
  /// In en, this message translates to:
  /// **'No points history'**
  String get noPointsHistory;

  /// No description provided for @earnPointsByTakingQuizzes.
  ///
  /// In en, this message translates to:
  /// **'Earn points by taking quizzes and daily activities'**
  String get earnPointsByTakingQuizzes;

  /// No description provided for @toNextLevel.
  ///
  /// In en, this message translates to:
  /// **'To Next Level'**
  String get toNextLevel;

  /// No description provided for @quizCompleted.
  ///
  /// In en, this message translates to:
  /// **'Quiz Completed'**
  String get quizCompleted;

  /// No description provided for @dailyLoginBonus.
  ///
  /// In en, this message translates to:
  /// **'Daily login bonus'**
  String get dailyLoginBonus;

  /// No description provided for @firstExamBonus.
  ///
  /// In en, this message translates to:
  /// **'First Exam Bonus'**
  String get firstExamBonus;

  /// No description provided for @congratsFirstExam.
  ///
  /// In en, this message translates to:
  /// **'Congrats on completing your first exam!'**
  String get congratsFirstExam;

  /// No description provided for @levelUpBonus.
  ///
  /// In en, this message translates to:
  /// **'Level Up Bonus'**
  String get levelUpBonus;

  /// No description provided for @reachedNewLevel.
  ///
  /// In en, this message translates to:
  /// **'You reached a new level!'**
  String get reachedNewLevel;

  /// No description provided for @justNow.
  ///
  /// In en, this message translates to:
  /// **'Just now'**
  String get justNow;

  /// No description provided for @aiAssistant.
  ///
  /// In en, this message translates to:
  /// **'AI Assistant'**
  String get aiAssistant;

  /// No description provided for @onlineNow.
  ///
  /// In en, this message translates to:
  /// **'Online now'**
  String get onlineNow;

  /// No description provided for @clearChat.
  ///
  /// In en, this message translates to:
  /// **'Clear Chat'**
  String get clearChat;

  /// No description provided for @clearChatConfirm.
  ///
  /// In en, this message translates to:
  /// **'Do you want to delete all messages?'**
  String get clearChatConfirm;

  /// No description provided for @clear.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get clear;

  /// No description provided for @typeMessage.
  ///
  /// In en, this message translates to:
  /// **'Type your message...'**
  String get typeMessage;

  /// No description provided for @topicSummary.
  ///
  /// In en, this message translates to:
  /// **'Topic Summary'**
  String get topicSummary;

  /// No description provided for @howToNavigate.
  ///
  /// In en, this message translates to:
  /// **'How to Navigate'**
  String get howToNavigate;

  /// No description provided for @generalQuestion.
  ///
  /// In en, this message translates to:
  /// **'General Question'**
  String get generalQuestion;

  /// No description provided for @studyTopicSummary.
  ///
  /// In en, this message translates to:
  /// **'Study Topic Summary'**
  String get studyTopicSummary;

  /// No description provided for @exampleTopic.
  ///
  /// In en, this message translates to:
  /// **'Example: User Research'**
  String get exampleTopic;

  /// No description provided for @create.
  ///
  /// In en, this message translates to:
  /// **'Create'**
  String get create;

  /// No description provided for @chooseFeature.
  ///
  /// In en, this message translates to:
  /// **'Choose Feature'**
  String get chooseFeature;

  /// No description provided for @iWantSummaryAbout.
  ///
  /// In en, this message translates to:
  /// **'I want a summary about: {topic}'**
  String iWantSummaryAbout(String topic);

  /// No description provided for @howDoIAccess.
  ///
  /// In en, this message translates to:
  /// **'How do I access {feature}?'**
  String howDoIAccess(String feature);

  /// No description provided for @welcomeMessage.
  ///
  /// In en, this message translates to:
  /// **'Hello! 👋 I\'m your smart assistant in the Taehb app.\n\nI can help you with:\n• App navigation\n• Feature explanations\n• Study summaries\n• Answering your questions\n\nHow can I help you today? 😊'**
  String get welcomeMessage;

  /// No description provided for @helloAgain.
  ///
  /// In en, this message translates to:
  /// **'Hello again! How can I help you? 😊'**
  String get helloAgain;

  /// No description provided for @errorOccurre.
  ///
  /// In en, this message translates to:
  /// **'Sorry, an error occurred. Please try again.'**
  String get errorOccurre;

  /// No description provided for @couldntProcess.
  ///
  /// In en, this message translates to:
  /// **'Sorry, I couldn\'t process your request. Please check your internet connection.'**
  String get couldntProcess;

  /// No description provided for @couldntCreateSummary.
  ///
  /// In en, this message translates to:
  /// **'Sorry, I couldn\'t create the summary.'**
  String get couldntCreateSummary;

  /// No description provided for @couldntHelp.
  ///
  /// In en, this message translates to:
  /// **'Sorry, I couldn\'t help.'**
  String get couldntHelp;

  /// No description provided for @now.
  ///
  /// In en, this message translates to:
  /// **'Now'**
  String get now;

  /// No description provided for @minutesAgo.
  ///
  /// In en, this message translates to:
  /// **'{count}m ago'**
  String minutesAgo(int count);

  /// No description provided for @hoursAgo.
  ///
  /// In en, this message translates to:
  /// **'{count}h ago'**
  String hoursAgo(int count);

  /// No description provided for @featureTests.
  ///
  /// In en, this message translates to:
  /// **'Tests'**
  String get featureTests;

  /// No description provided for @featureProfile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get featureProfile;

  /// No description provided for @featureLeaderboard.
  ///
  /// In en, this message translates to:
  /// **'Leaderboard'**
  String get featureLeaderboard;

  /// No description provided for @featurePointsHistory.
  ///
  /// In en, this message translates to:
  /// **'Points History'**
  String get featurePointsHistory;

  /// No description provided for @featureDailyReward.
  ///
  /// In en, this message translates to:
  /// **'Daily Reward'**
  String get featureDailyReward;

  /// No description provided for @knowledgeUnits.
  ///
  /// In en, this message translates to:
  /// **'Knowledge Units'**
  String get knowledgeUnits;

  /// No description provided for @chooseKnowledgeUnit.
  ///
  /// In en, this message translates to:
  /// **'Choose Knowledge Unit'**
  String get chooseKnowledgeUnit;

  /// No description provided for @errorLoadingKU.
  ///
  /// In en, this message translates to:
  /// **'Error loading knowledge units'**
  String get errorLoadingKU;

  /// No description provided for @generateQuestionsFor.
  ///
  /// In en, this message translates to:
  /// **'I want questions about: {topic}'**
  String generateQuestionsFor(Object topic);

  /// No description provided for @errorGeneratingQuestions.
  ///
  /// In en, this message translates to:
  /// **'Sorry, an error occurred while generating questions'**
  String get errorGeneratingQuestions;

  /// No description provided for @courseMaterials.
  ///
  /// In en, this message translates to:
  /// **'Course Materials'**
  String get courseMaterials;

  /// No description provided for @selectKnowledgeUnits.
  ///
  /// In en, this message translates to:
  /// **'Select Knowledge Units to Study'**
  String get selectKnowledgeUnits;

  /// No description provided for @selectUnitsHint.
  ///
  /// In en, this message translates to:
  /// **'Select one or more units, then tap \"Generate Summary\" for a detailed overview'**
  String get selectUnitsHint;

  /// No description provided for @selected.
  ///
  /// In en, this message translates to:
  /// **'Selected'**
  String get selected;

  /// No description provided for @generateSummary.
  ///
  /// In en, this message translates to:
  /// **'Generate Summary'**
  String get generateSummary;

  /// No description provided for @detailedSummary.
  ///
  /// In en, this message translates to:
  /// **'Detailed Summary'**
  String get detailedSummary;

  /// No description provided for @dismiss.
  ///
  /// In en, this message translates to:
  /// **'Dismiss'**
  String get dismiss;

  /// No description provided for @topics.
  ///
  /// In en, this message translates to:
  /// **'topics'**
  String get topics;

  /// No description provided for @knowledgeUnit.
  ///
  /// In en, this message translates to:
  /// **'Knowledge Unit'**
  String get knowledgeUnit;

  /// No description provided for @userResearch.
  ///
  /// In en, this message translates to:
  /// **'User Research'**
  String get userResearch;

  /// No description provided for @interactionDesign.
  ///
  /// In en, this message translates to:
  /// **'Interaction Design and User Testing'**
  String get interactionDesign;

  /// No description provided for @projectManagement.
  ///
  /// In en, this message translates to:
  /// **'Project Management Principles'**
  String get projectManagement;

  /// No description provided for @cryptography.
  ///
  /// In en, this message translates to:
  /// **'Cryptography Overview'**
  String get cryptography;

  /// No description provided for @operatingSystems.
  ///
  /// In en, this message translates to:
  /// **'Operating Systems'**
  String get operatingSystems;

  /// No description provided for @databaseQuery.
  ///
  /// In en, this message translates to:
  /// **'Database Query Languages'**
  String get databaseQuery;

  /// No description provided for @webMobile.
  ///
  /// In en, this message translates to:
  /// **'Web and Mobile Systems'**
  String get webMobile;

  /// No description provided for @noUnitsSelected.
  ///
  /// In en, this message translates to:
  /// **'Please select at least one Knowledge Unit'**
  String get noUnitsSelected;

  /// No description provided for @generatingSummary.
  ///
  /// In en, this message translates to:
  /// **'Generating Summary...'**
  String get generatingSummary;

  /// No description provided for @summaryGenerated.
  ///
  /// In en, this message translates to:
  /// **'Summary Generated Successfully'**
  String get summaryGenerated;

  /// No description provided for @howCanWeHelp.
  ///
  /// In en, this message translates to:
  /// **'How Can We Help You?'**
  String get howCanWeHelp;

  /// No description provided for @contactUs.
  ///
  /// In en, this message translates to:
  /// **'Contact Us'**
  String get contactUs;

  /// No description provided for @phone.
  ///
  /// In en, this message translates to:
  /// **'Phone'**
  String get phone;

  /// No description provided for @whatsapp.
  ///
  /// In en, this message translates to:
  /// **'WhatsApp'**
  String get whatsapp;

  /// No description provided for @frequentlyAskedQuestions.
  ///
  /// In en, this message translates to:
  /// **'Frequently Asked Questions'**
  String get frequentlyAskedQuestions;

  /// No description provided for @quickLinks.
  ///
  /// In en, this message translates to:
  /// **'Quick Links'**
  String get quickLinks;

  /// No description provided for @userGuide.
  ///
  /// In en, this message translates to:
  /// **'User Guide'**
  String get userGuide;

  /// No description provided for @privacyPolicy.
  ///
  /// In en, this message translates to:
  /// **'Privacy Policy'**
  String get privacyPolicy;

  /// No description provided for @termsOfService.
  ///
  /// In en, this message translates to:
  /// **'Terms of Service'**
  String get termsOfService;

  /// No description provided for @appVersion.
  ///
  /// In en, this message translates to:
  /// **'App Version'**
  String get appVersion;

  /// No description provided for @faqQuestion1.
  ///
  /// In en, this message translates to:
  /// **'How do I start a new exam?'**
  String get faqQuestion1;

  /// No description provided for @faqAnswer1.
  ///
  /// In en, this message translates to:
  /// **'Go to the home screen, select \'Exam\', choose your knowledge unit, and click \'Start Exam\'.'**
  String get faqAnswer1;

  /// No description provided for @faqQuestion2.
  ///
  /// In en, this message translates to:
  /// **'How is my score calculated?'**
  String get faqQuestion2;

  /// No description provided for @faqAnswer2.
  ///
  /// In en, this message translates to:
  /// **'You earn 5 points for each correct answer, with bonus points for difficult questions and fast responses.'**
  String get faqAnswer2;

  /// No description provided for @faqQuestion3.
  ///
  /// In en, this message translates to:
  /// **'Can I review my previous exams?'**
  String get faqQuestion3;

  /// No description provided for @faqAnswer3.
  ///
  /// In en, this message translates to:
  /// **'Yes! Go to your Profile, then select \'Exam History\' to view all your past exam results and details.'**
  String get faqAnswer3;

  /// No description provided for @faqQuestion4.
  ///
  /// In en, this message translates to:
  /// **'How do I earn points and level up?'**
  String get faqQuestion4;

  /// No description provided for @faqAnswer4.
  ///
  /// In en, this message translates to:
  /// **'Complete exams, answer correctly, login daily, and complete study sessions to earn points and advance through levels.'**
  String get faqAnswer4;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return AppLocalizationsAr();
    case 'en': return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
