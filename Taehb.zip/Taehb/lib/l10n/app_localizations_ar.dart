// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appName => 'تأهّب';

  @override
  String get slogan => 'تأهبك اليوم يضمن جاهزيتك غدًا';

  @override
  String get splashLoading => 'جاري التحميل...';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get password => 'كلمة المرور';

  @override
  String get login => 'تسجيل الدخول';

  @override
  String get forgotPassword => 'نسيت كلمة المرور؟';

  @override
  String get signUp => 'إنشاء حساب';

  @override
  String get homeTitle => 'الرئيسية';

  @override
  String get rememberMe => 'تذكرني';

  @override
  String get or => 'أو';

  @override
  String get continueWithGoogle => 'متابعة مع Google';

  @override
  String get continueWithApple => 'متابعة مع Apple';

  @override
  String get resetPassword => 'إعادة تعيين كلمة المرور';

  @override
  String get enterEmailToReset => 'أدخل بريدك الإلكتروني لاستلام رابط إعادة تعيين كلمة المرور.';

  @override
  String get cancel => 'إلغاء';

  @override
  String get sendResetLink => 'إرسال رابط إعادة التعيين';

  @override
  String get welcomeBack => 'أهلاً بك مرة أخرى';

  @override
  String get loginSubtitle => 'سجل دخولك لمواصلة رحلة التعلم';

  @override
  String get enterYourEmail => 'أدخل بريدك الإلكتروني';

  @override
  String get enterYourPassword => 'أدخل كلمة المرور';

  @override
  String get signIn => 'تسجيل الدخول';

  @override
  String get dontHaveAnAccount => 'لا تملك حساباً؟';

  @override
  String get confirmLogout => 'تأكيد تسجيل الخروج';

  @override
  String get logoutQuestion => 'هل أنت متأكد من رغبتك في تسجيل الخروج؟';

  @override
  String get logout => 'تسجيل الخروج';

  @override
  String get comingSoonNewFeature => 'قريباً - ميزة جديدة!';

  @override
  String get addNew => 'إضافة جديد';

  @override
  String get student => 'طالب';

  @override
  String get quickStats => 'إحصائياتك السريعة';

  @override
  String get tests => 'الاختبارات';

  @override
  String get success => 'النجاح';

  @override
  String get rank => 'الترتيب';

  @override
  String get availableFeatures => 'الميزات المتاحة';

  @override
  String get practiceTests => 'اختبارات تجريبية';

  @override
  String get practiceVariousTests => 'تدرب على اختبارات متنوعة';

  @override
  String get aiAssistance => 'الذكاء الاصطناعي';

  @override
  String get aiAssistanceSubtitle => 'مساعد ذكي لتحسين أدائك';

  @override
  String get detailedReports => 'تقارير مفصلة';

  @override
  String get detailedReportsSubtitle => 'تحليل شامل لنتائجك';

  @override
  String get recentActivity => 'النشاط الأخير';

  @override
  String get welcomeToApp => 'مرحباً بك في تأهّب!';

  @override
  String get startJourney => 'ابدأ رحلتك التعليمية واستعد للاختبارات بثقة';

  @override
  String get getStarted => 'ابدأ الآن';

  @override
  String get comingSoon => 'قريباً!';

  @override
  String get emailRequired => 'البريد الإلكتروني مطلوب';

  @override
  String get invalidEmail => 'يرجى إدخال بريد إلكتروني صالح';

  @override
  String get passwordRequired => 'كلمة المرور مطلوبة';

  @override
  String passwordMinLength(int min) {
    return 'يجب أن تكون كلمة المرور $min أحرف على الأقل';
  }

  @override
  String get selectKUs => 'اختيار الوحدات المعرفية';

  @override
  String selectedCount(int count) {
    return '$count محددة';
  }

  @override
  String get generatingQuestions => 'جارٍ توليد الأسئلة...';

  @override
  String processingKUs(int count) {
    return 'يتم معالجة $count وحدة معرفية';
  }

  @override
  String questionProgress(int current, int total) {
    return 'السؤال $current من $total';
  }

  @override
  String get finishExam => 'إنهاء الاختبار';

  @override
  String get warning => 'تنبيه';

  @override
  String notAllAnswered(int answered, int total) {
    return 'لم تجب على جميع الأسئلة!\nأجبت على $answered من $total';
  }

  @override
  String get continueAnswering => 'متابعة الإجابة';

  @override
  String get correct => 'صحيح';

  @override
  String get wrong => 'خطأ';

  @override
  String get unanswered => 'لم يُجب';

  @override
  String get previous => 'السابق';

  @override
  String get next => 'التالي';

  @override
  String get finish => 'إنهاء';

  @override
  String get failedToSaveResults => 'خطاء في حفظ النتيجة';

  @override
  String get retry => 'اعادة المحاولة';

  @override
  String get resultsSavedSuccessfully => 'تم حفظ النتيجة بنجاح';

  @override
  String get examResults => 'نتائج الاختبار';

  @override
  String get excellent => 'ممتاز!';

  @override
  String get good => 'جيد!';

  @override
  String get quickAccess => 'الوصول السريع';

  @override
  String get tryAgain => 'حاول مرة أخرى';

  @override
  String get correctAnswers => 'صحيح';

  @override
  String get wrongAnswers => 'خطأ';

  @override
  String get questionsDetails => 'تفاصيل الأسئلة';

  @override
  String questionNumber(int number) {
    return 'السؤال $number';
  }

  @override
  String get confirmExamStart => 'تأكيد بدء الاختبار';

  @override
  String get examInfo => 'معلومات الاختبار';

  @override
  String get numberOfQuestions => 'عدد الأسئلة';

  @override
  String questionsCount(int count) {
    return '$count سؤال';
  }

  @override
  String get selectedUnits => 'الوحدات المختارة';

  @override
  String unitsCount(int count) {
    return '$count وحدة';
  }

  @override
  String get expectedTime => 'الوقت المتوقع';

  @override
  String estimatedMinutes(int minutes) {
    return '~$minutes دقيقة';
  }

  @override
  String get importantNotices => 'تنبيهات مهمة';

  @override
  String get multipleChoiceOnly => 'الاختبار يحتوي على أسئلة اختيار من متعدد فقط';

  @override
  String get answerAllQuestions => 'يجب الإجابة على جميع الأسئلة قبل إنهاء الاختبار';

  @override
  String get canNavigateQuestions => 'يمكنك التنقل بين الأسئلة وتعديل إجاباتك';

  @override
  String get resultsShownImmediately => 'ستظهر النتيجة مباشرة بعد إنهاء الاختبار';

  @override
  String get agreeMultipleChoice => 'أوافق على أن الاختبار يحتوي على أسئلة اختيارية فقط';

  @override
  String get readyToStart => 'أنا مستعد للبدء في الاختبار';

  @override
  String get agreeAndConfirm => 'يرجى الموافقة على الشروط والتأكيد على الاستعداد';

  @override
  String get questionsReady => '✓ الأسئلة جاهزة!';

  @override
  String get preparingQuestions => 'جاري تحضير الأسئلة...';

  @override
  String errorOccurred(String error) {
    return 'خطأ: $error';
  }

  @override
  String get goBack => 'العودة';

  @override
  String get retryAgain => 'إعادة المحاولة';

  @override
  String get error => 'خطأ';

  @override
  String get pleaseWait => 'يرجى الانتظار بضع ثوانٍ';

  @override
  String get backToHome => 'العودة للرئيسية';

  @override
  String get startExam => 'بدء الاختبار';

  @override
  String get pleaseSelectKU => 'الرجاء اختيار وحدة معرفية واحدة على الأقل';

  @override
  String get questionsNotRecognized => 'لم يتم التعرف على الأسئلة';

  @override
  String get serverConnectionFailed => 'فشل الاتصال بالخادم';

  @override
  String get unableToConnectServer => 'تعذر الاتصال بالخادم';

  @override
  String get kuUserResearch => 'بحوث المستخدم';

  @override
  String get kuInteractionDesign => 'تصميم التفاعل واختبار المستخدم';

  @override
  String get kuProjectManagement => 'مبادئ إدارة المشاريع';

  @override
  String get kuEthicalIssues => 'القضايا الأخلاقية والقانونية والخصوصية';

  @override
  String get kuInformationSystems => 'مبادئ نظم المعلومات';

  @override
  String get kuCyberAttacks => 'الهجمات السيبرانية والكشف عنها';

  @override
  String get kuVulnerabilities => 'نقاط الضعف والتهديدات والمخاطر';

  @override
  String get kuCryptography => 'نظرة عامة على التشفير';

  @override
  String get kuSecurityServices => 'خدمات وآليات وتدابير الأمن';

  @override
  String get kuNetworkingFoundations => 'أساسيات الشبكات';

  @override
  String get kuNetworkManagement => 'إدارة الشبكات';

  @override
  String get kuOperatingSystems => 'أنظمة التشغيل';

  @override
  String get kuDataConcepts => 'مفاهيم البيانات والمعلومات';

  @override
  String get kuDataModeling => 'نمذجة البيانات';

  @override
  String get exitExamWarning => 'هل أنت متأكد من الخروج من الاختبار؟ سيتم فقدان تقدمك.';

  @override
  String get exit => 'خروج';

  @override
  String get seconds => 'ثانية';

  @override
  String get timeUp => 'انتهى الوقت';

  @override
  String get kuDatabaseEnvironment => 'إدارة بيئة قواعد البيانات';

  @override
  String get kuQueryLanguages => 'لغات الاستعلام عن قواعد البيانات';

  @override
  String get kuRequirementsEngineering => 'هندسة المتطلبات والاختبار';

  @override
  String get kuProblemSolving => 'حل المشكلات وتطوير البرامج';

  @override
  String get kuDataStructures => 'أساسيات هياكل البيانات والخوارزميات';

  @override
  String get kuWebMobileSystems => 'مفاهيم وتقنيات أنظمة الويب والجوال';

  @override
  String versionLabel(Object version) {
    return 'الإصدار $version';
  }

  @override
  String copyright(int year) {
    return '© $year تأهّب للحلول التعليمية';
  }

  @override
  String get pointsEarned => 'النقاط المكتسبة';

  @override
  String get totalPoints => 'إجمالي النقاط';

  @override
  String get level => 'المستوى';

  @override
  String needPoints(int points) {
    return 'تحتاج $points نقطة للمستوى التالي';
  }

  @override
  String get score => 'النتيجة';

  @override
  String get passable => 'مقبول';

  @override
  String get needsImprovement => 'بحاجة للتحسين';

  @override
  String get questionsReview => 'مراجعة الأسئلة';

  @override
  String get viewHistory => 'عرض السجل';

  @override
  String get savingResults => 'جاري حفظ النتائج...';

  @override
  String get errorSavingResults => 'حدث خطأ أثناء حفظ النتائج';

  @override
  String get dailyLoginReward => 'مكافأة تسجيل الدخول اليومي';

  @override
  String get youEarned => 'لقد حصلت على';

  @override
  String get points => 'نقاط';

  @override
  String get loginDaily => 'سجل دخولك يومياً لكسب المزيد من النقاط!';

  @override
  String get awesome => 'رائع!';

  @override
  String get currentStreak => 'السلسلة الحالية';

  @override
  String get longestStreak => 'أطول سلسلة';

  @override
  String get days => 'أيام';

  @override
  String get loggedInToday => 'لقد سجلت دخولك اليوم! عد غداً لمواصلة السلسلة';

  @override
  String get loginStreakTitle => 'سلسلة تسجيل الدخول';

  @override
  String get progressToNextLevel => 'التقدم للمستوى التالي';

  @override
  String get completed => 'مكتمل';

  @override
  String get motivationalMessage => 'استمر في التقدم!';

  @override
  String get examHistory => 'سجل الاختبارات';

  @override
  String get noExamHistory => 'لا يوجد سجل اختبارات بعد';

  @override
  String get takeFirstExam => 'قم بإجراء أول اختبار لرؤية النتائج هنا';

  @override
  String get yourStatistics => 'إحصائياتك';

  @override
  String get attempts => 'المحاولات';

  @override
  String get avgScore => 'متوسط النتيجة';

  @override
  String get best => 'الأفضل';

  @override
  String get examDetails => 'تفاصيل الاختبار';

  @override
  String get date => 'التاريخ';

  @override
  String get selectedKUs => 'الوحدات المختارة';

  @override
  String get questionResults => 'نتائج الأسئلة';

  @override
  String get yourAnswer => 'إجابتك';

  @override
  String get correctAnswer => 'الإجابة الصحيحة';

  @override
  String get notAnswered => 'لم تتم الإجابة';

  @override
  String get close => 'إغلاق';

  @override
  String get leaderboard => 'لوحة الصدارة';

  @override
  String get topPerformers => 'أفضل المتسابقين';

  @override
  String get refresh => 'تحديث';

  @override
  String get errorLoadingLeaderboard => 'خطأ في تحميل لوحة الصدارة';

  @override
  String get noLeaderboardData => 'لا توجد بيانات في لوحة الصدارة';

  @override
  String get beFirstToCompete => 'كن أول من يتنافس!';

  @override
  String get you => 'أنت';

  @override
  String get pts => 'نقطة';

  @override
  String get units => 'وحدات';

  @override
  String get changePassword => 'تغيير كلمة المرور';

  @override
  String get currentPassword => 'كلمة المرور الحالية';

  @override
  String get newPassword => 'كلمة المرور الجديدة';

  @override
  String get confirmPassword => 'تأكيد كلمة المرور';

  @override
  String get changePasswordSuccess => 'تم تغيرر كلمة المرور بنجاح';

  @override
  String get pleaseEnterCurrentPassword => 'الرجاء إدخال كلمة المرور الحالية';

  @override
  String get pleaseEnterNewPassword => 'الرجاء إدخال كلمة مرور جديدة';

  @override
  String get pleaseConfirmNewPassword => 'الرجاء تأكيد كلمة المرور الجديدة';

  @override
  String get passwordsDoNotMatch => 'كلمات المرور غير متطابقة';

  @override
  String get passwordRequirements => 'يجب أن تتكون كلمة المرور من 6 أحرف على الأقل';

  @override
  String get newPasswordSameAsOld => 'يجب أن تكون كلمة المرور الجديدة مختلفة عن الحالية';

  @override
  String get notifications => 'الاشعارات';

  @override
  String get noNotifications => 'لايوجد اشعارات';

  @override
  String get settings => 'الاعدادات';

  @override
  String get language => 'اللغة';

  @override
  String get darkMode => 'الوضع الداكن';

  @override
  String get helpAndSupport => 'المساعدة & الدعم';

  @override
  String get about => 'ماذا عنا';

  @override
  String get logoutSuccess => 'تسجيل الخروج بنجاح';

  @override
  String get errorLoggingOut => 'خطاء في تسجيل الخروج';

  @override
  String get logoutConfirmation => 'هل انت  متاكد من تسجيل الخروج؟';

  @override
  String get errorLoggingIn => 'خطاء في تسجيل الدخول';

  @override
  String get editProfile => 'تعديل الملف الشخصي';

  @override
  String get profile => 'الملف الشخصي';

  @override
  String get chooseTheme => 'اختر المظهر المفضل لديك';

  @override
  String get systemDefault => 'افتراضي النظام';

  @override
  String get lightMode => 'الوضع الفاتح';

  @override
  String get lightModeDescription => 'مظهر ساطع وواضح';

  @override
  String get darkModeDescription => 'مريح للعيون في الإضاءة المنخفضة';

  @override
  String get systemDefaultDescription => 'اتبع إعدادات النظام';

  @override
  String get pointsHistory => 'تاريخ النقاط';

  @override
  String get pointsBreakdown => 'تفصيل النقاط';

  @override
  String get noPointsHistory => 'لا يوجد تاريخ للنقاط';

  @override
  String get earnPointsByTakingQuizzes => 'اكسب النقاط عن طريق إجراء الاختبارات والأنشطة اليومية';

  @override
  String get toNextLevel => 'للمستوى التالي';

  @override
  String get quizCompleted => 'اكتمال الاختبار';

  @override
  String get dailyLoginBonus => 'مكافأة تسجيل الدخول اليومية';

  @override
  String get firstExamBonus => 'مكافأة أول اختبار';

  @override
  String get congratsFirstExam => 'تهانينا على إكمال أول اختبار!';

  @override
  String get levelUpBonus => 'مكافأة الارتقاء بالمستوى';

  @override
  String get reachedNewLevel => 'لقد وصلت إلى مستوى جديد!';

  @override
  String get justNow => 'الآن';

  @override
  String get aiAssistant => 'المساعد الذكي';

  @override
  String get onlineNow => 'متصل الآن';

  @override
  String get clearChat => 'مسح المحادثة';

  @override
  String get clearChatConfirm => 'هل تريد حذف جميع الرسائل؟';

  @override
  String get clear => 'مسح';

  @override
  String get typeMessage => 'اكتب رسالتك...';

  @override
  String get topicSummary => 'ملخص موضوع';

  @override
  String get howToNavigate => 'كيف أصل إلى';

  @override
  String get generalQuestion => 'سؤال عام';

  @override
  String get studyTopicSummary => 'ملخص موضوع دراسي';

  @override
  String get exampleTopic => 'مثال: بحوث المستخدم';

  @override
  String get create => 'إنشاء';

  @override
  String get chooseFeature => 'اختر الميزة';

  @override
  String iWantSummaryAbout(String topic) {
    return 'أريد ملخصاً عن: $topic';
  }

  @override
  String howDoIAccess(String feature) {
    return 'كيف أصل إلى $feature؟';
  }

  @override
  String get welcomeMessage => 'مرحباً! 👋 أنا مساعدك الذكي في تطبيق Taehb.\n\nيمكنني مساعدتك في:\n• التنقل في التطبيق\n• شرح الميزات\n• تقديم ملخصات دراسية\n• الإجابة على أسئلتك\n\nكيف يمكنني مساعدتك اليوم؟ 😊';

  @override
  String get helloAgain => 'مرحباً مجدداً! كيف يمكنني مساعدتك؟ 😊';

  @override
  String get errorOccurre => 'عذراً، حدث خطأ. الرجاء المحاولة مرة أخرى.';

  @override
  String get couldntProcess => 'عذراً، لم أتمكن من معالجة طلبك. تأكد من اتصالك بالإنترنت.';

  @override
  String get couldntCreateSummary => 'عذراً، لم أتمكن من إنشاء الملخص.';

  @override
  String get couldntHelp => 'عذراً، لم أتمكن من المساعدة.';

  @override
  String get now => 'الآن';

  @override
  String minutesAgo(int count) {
    return 'منذ $count دقيقة';
  }

  @override
  String hoursAgo(int count) {
    return 'منذ $count ساعة';
  }

  @override
  String get featureTests => 'الاختبارات';

  @override
  String get featureProfile => 'الملف الشخصي';

  @override
  String get featureLeaderboard => 'لوحة المتصدرين';

  @override
  String get featurePointsHistory => 'تاريخ النقاط';

  @override
  String get featureDailyReward => 'المكافأة اليومية';

  @override
  String get knowledgeUnits => 'الوحدات المعرفية';

  @override
  String get chooseKnowledgeUnit => 'اختر الوحدة المعرفية';

  @override
  String get errorLoadingKU => 'حدث خطأ في تحميل الوحدات المعرفية';

  @override
  String generateQuestionsFor(Object topic) {
    return 'أريد أسئلة عن موضوع: $topic';
  }

  @override
  String get errorGeneratingQuestions => 'عذراً، حدث خطأ في توليد الأسئلة';

  @override
  String get courseMaterials => 'المقررات الدراسية';

  @override
  String get selectKnowledgeUnits => 'اختر وحدات المعرفة للدراسة';

  @override
  String get selectUnitsHint => 'اختر وحدة أو أكثر ثم اضغط على \"إنشاء ملخص\" للحصول على ملخص تفصيلي';

  @override
  String get selected => 'محدد';

  @override
  String get generateSummary => 'إنشاء ملخص';

  @override
  String get detailedSummary => 'الملخص التفصيلي';

  @override
  String get dismiss => 'إغلاق';

  @override
  String get topics => 'موضوع';

  @override
  String get knowledgeUnit => 'وحدة المعرفة';

  @override
  String get userResearch => 'بحث المستخدم';

  @override
  String get interactionDesign => 'تصميم التفاعل واختبار المستخدم';

  @override
  String get projectManagement => 'مبادئ إدارة المشاريع';

  @override
  String get cryptography => 'نظرة عامة على التشفير';

  @override
  String get operatingSystems => 'أنظمة التشغيل';

  @override
  String get databaseQuery => 'لغات الاستعلام عن قواعد البيانات';

  @override
  String get webMobile => 'أنظمة الويب والجوال';

  @override
  String get noUnitsSelected => 'الرجاء اختيار وحدة معرفة واحدة على الأقل';

  @override
  String get generatingSummary => 'جارٍ إنشاء الملخص...';

  @override
  String get summaryGenerated => 'تم إنشاء الملخص بنجاح';

  @override
  String get howCanWeHelp => 'كيف يمكننا مساعدتك؟';

  @override
  String get contactUs => 'اتصل بنا';

  @override
  String get phone => 'الهاتف';

  @override
  String get whatsapp => 'واتساب';

  @override
  String get frequentlyAskedQuestions => 'الأسئلة الشائعة';

  @override
  String get quickLinks => 'روابط سريعة';

  @override
  String get userGuide => 'دليل المستخدم';

  @override
  String get privacyPolicy => 'سياسة الخصوصية';

  @override
  String get termsOfService => 'شروط الخدمة';

  @override
  String get appVersion => 'إصدار التطبيق';

  @override
  String get faqQuestion1 => 'كيف أبدأ امتحان جديد؟';

  @override
  String get faqAnswer1 => 'انتقل إلى الصفحة الرئيسية، اختر \'الامتحان\'، حدد الوحدة المعرفية، ثم انقر على \'بدء الاختبار\'.';

  @override
  String get faqQuestion2 => 'كيف يتم حساب النقاط؟';

  @override
  String get faqAnswer2 => 'تحصل على 5 نقاط لكل إجابة صحيحة، مع نقاط إضافية للأسئلة الصعبة والإجابات السريعة.';

  @override
  String get faqQuestion3 => 'هل يمكنني مراجعة الامتحانات السابقة؟';

  @override
  String get faqAnswer3 => 'نعم! انتقل إلى ملفك الشخصي، ثم اختر \'سجل الامتحانات\' لعرض جميع نتائج امتحاناتك السابقة والتفاصيل.';

  @override
  String get faqQuestion4 => 'كيف أكسب النقاط وأرتقي في المستويات؟';

  @override
  String get faqAnswer4 => 'أكمل الامتحانات، أجب بشكل صحيح، سجل دخولك يومياً، وأكمل جلسات الدراسة لكسب النقاط والتقدم في المستويات.';
}
