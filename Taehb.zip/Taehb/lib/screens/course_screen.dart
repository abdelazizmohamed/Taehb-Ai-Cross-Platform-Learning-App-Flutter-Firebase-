import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taehb/l10n/app_localizations.dart';
import 'package:taehb/screens/summary_display_screen.dart';
import '../core/constants/colors.dart';
import '../services/course_service.dart';
import '../data/models/knowledge_unit.dart';

class CourseScreen extends StatefulWidget {
  const CourseScreen({Key? key}) : super(key: key);

  @override
  State<CourseScreen> createState() => _CourseScreenState();
}

class _CourseScreenState extends State<CourseScreen> with SingleTickerProviderStateMixin {
  final CourseService _courseService = CourseService();
  String? _selectedKU; // Changed: Single selection only
  bool _isLoading = false;

  // Knowledge Units with localization keys
  final List<Map<String, dynamic>> _knowledgeUnits = [
    {
      'id': 'user_research',
      'name_en': 'User Research',
      'localization_key': 'kuUserResearch',
      'icon': Icons.search_outlined,
      'color': AppColors.primary,
      'topics': ['Research Methods', 'User\'s Persona'],
    },
    {
      'id': 'interaction_design',
      'name_en': 'Interaction Design and User Testing',
      'localization_key': 'kuInteractionDesign',
      'icon': Icons.design_services_outlined,
      'color': AppColors.secondary,
      'topics': [
        'User Interface Design Techniques',
        'User Interactions Techniques',
        'Testing and Evaluation Methods',
        'Documentation'
      ],
    },
    {
      'id': 'project_management',
      'name_en': 'Project Management Principles',
      'localization_key': 'kuProjectManagement',
      'icon': Icons.assessment_outlined,
      'color': AppColors.accent,
      'topics': [
        'Project management tools and techniques',
        'Project management processes',
        'Project management life cycle',
        'Project management methodologies',
        'IT governance principles',
        'IT resource management'
      ],
    },
    {
      'id': 'ethical_legal_privacy',
      'name_en': 'Ethical, Legal, and Privacy Issues',
      'localization_key': 'kuEthicalIssues',
      'icon': Icons.gavel_outlined,
      'color': Color(0xFF795548),
      'topics': [
        'Ethical issues in IT',
        'Legal issues in IT',
        'Privacy issues in IT',
        'Intellectual property issues'
      ],
    },
    {
      'id': 'information_systems',
      'name_en': 'Information Systems Principles',
      'localization_key': 'kuInformationSystems',
      'icon': Icons.insights_outlined,
      'color': Color(0xFF9C27B0),
      'topics': [
        'Concepts of Information Systems',
        'Information systems in organizations'
      ],
    },
    {
      'id': 'cyber_attacks',
      'name_en': 'Cyber-attacks and Detection',
      'localization_key': 'kuCyberAttacks',
      'icon': Icons.security_outlined,
      'color': Color(0xFF3F51B5),
      'topics': [
        'Types of cyber-attacks',
        'Detection methods',
        'Prevention tools',
        'Best practices'
      ],
    },
    {
      'id': 'vulnerabilities_threats',
      'name_en': 'Vulnerabilities, Threats, and Risk',
      'localization_key': 'kuVulnerabilities',
      'icon': Icons.warning_amber_outlined,
      'color': Color(0xFF607D8B),
      'topics': ['Vulnerabilities', 'Threats', 'Risk'],
    },
    {
      'id': 'cryptography',
      'name_en': 'Cryptography Overview',
      'localization_key': 'kuCryptography',
      'icon': Icons.lock_outlined,
      'color': AppColors.studyColor,
      'topics': [
        'Cryptography algorithms',
        'Public-key cryptography',
        'Symmetric-key cryptography',
        'Hash functions',
        'Digital signatures',
        'Authentication',
        'Data security',
        'Privacy'
      ],
    },
    {
      'id': 'operating_systems',
      'name_en': 'Operating Systems',
      'localization_key': 'kuOperatingSystems',
      'icon': Icons.computer_outlined,
      'color': Color(0xFF00BCD4),
      'topics': [
        'Fundamentals of Windows and Unix-class systems',
        'Processes and Threads',
        'CPU Scheduling',
        'Memory Management',
        'File Systems',
        'I/O Systems'
      ],
    },
    {
      'id': 'database_query',
      'name_en': 'Database Query Languages',
      'localization_key': 'kuQueryLanguages',
      'icon': Icons.storage_outlined,
      'color': Color(0xFF009688),
      'topics': ['SQL', 'Clauses and filters', 'Joins', 'Views'],
    },
    {
      'id': 'web_mobile',
      'name_en': 'Web and Mobile Systems Concepts and Technologies',
      'localization_key': 'kuWebMobileSystems',
      'icon': Icons.phone_android_outlined,
      'color': Color(0xFF8BC34A),
      'topics': [
        'Web and mobile application technologies',
        'Data validation',
        'Client vs. server-side development',
        'Cookies',
        'Database connectivity',
        'JavaScript'
      ],
    },
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isRTL = Directionality.of(context) == TextDirection.rtl;
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(isRTL ? 'المقررات الدراسية' : 'Course Materials'),
        centerTitle: true,
        actions: [
          if (_selectedKU != null)
            TextButton.icon(
              onPressed: () {
                setState(() {
                  _selectedKU = null;
                });
              },
              icon: Icon(Icons.clear, color: Colors.white),
              label: Text(
                isRTL ? 'مسح' : 'Clear',
                style: TextStyle(color: Colors.white),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Header with instructions
          _buildHeader(theme, isRTL, l10n),

          // Knowledge Units Grid
          Expanded(
            child: _isLoading
                ? _buildLoadingState(theme, isRTL)
                : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 0.75,
                    ),
                    itemCount: _knowledgeUnits.length,
                    itemBuilder: (context, index) {
                      final ku = _knowledgeUnits[index];
                      final isSelected = _selectedKU == ku['id'];

                      return _buildKUCard(
                        ku: ku,
                        isSelected: isSelected,
                        theme: theme,
                        isRTL: isRTL,
                        l10n: l10n,
                        onTap: () {
                          setState(() {
                            // Toggle selection: select if not selected, deselect if already selected
                            _selectedKU = isSelected ? null : ku['id'];
                          });
                        },
                      );
                    },
                  ),
                  const SizedBox(height: 100), // Space for FAB
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: _selectedKU != null && !_isLoading
          ? FloatingActionButton.extended(
        onPressed: _generateSummary,
        icon: Icon(Icons.auto_awesome),
        label: Text(
          isRTL ? 'إنشاء ملخص' : 'Generate Summary',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: AppColors.accent,
      )
          : null,
    );
  }

  Widget _buildHeader(ThemeData theme, bool isRTL, AppLocalizations l10n) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.school, color: Colors.white, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  isRTL
                      ? 'اختر وحدة معرفية للدراسة'
                      : 'Select a Knowledge Unit to Study',
                  style: theme.textTheme.titleLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            isRTL
                ? 'اختر وحدة معرفية واحدة ثم اضغط على "إنشاء ملخص" للحصول على ملخص تفصيلي مدعوم بالذكاء الاصطناعي'
                : 'Select ONE knowledge unit, then tap "Generate Summary" for an AI-powered detailed overview',
            style: theme.textTheme.bodySmall?.copyWith(
              color: Colors.white.withOpacity(0.9),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _selectedKU != null ? Icons.check_circle : Icons.radio_button_unchecked,
                      color: Colors.white,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _selectedKU != null
                          ? (isRTL ? 'محدد' : 'Selected')
                          : (isRTL ? 'لم يتم الاختيار' : 'Not Selected'),
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.library_books, color: Colors.white, size: 16),
                    const SizedBox(width: 6),
                    Text(
                      '${_knowledgeUnits.length} ${isRTL ? 'وحدة' : 'Units'}',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState(ThemeData theme, bool isRTL) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: CircularProgressIndicator(
                color: AppColors.primary,
                strokeWidth: 3,
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            isRTL ? 'جارٍ إنشاء الملخص...' : 'Generating Summary...',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            isRTL
                ? 'يرجى الانتظار، هذا قد يستغرق بضع ثوانٍ'
                : 'Please wait, this may take a few seconds',
            style: theme.textTheme.bodySmall?.copyWith(
              color: AppColors.textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  String _getLocalizedKUName(String localizationKey, AppLocalizations l10n) {
    switch (localizationKey) {
      case 'kuUserResearch':
        return l10n.kuUserResearch;
      case 'kuInteractionDesign':
        return l10n.kuInteractionDesign;
      case 'kuProjectManagement':
        return l10n.kuProjectManagement;
      case 'kuEthicalIssues':
        return l10n.kuEthicalIssues;
      case 'kuInformationSystems':
        return l10n.kuInformationSystems;
      case 'kuCyberAttacks':
        return l10n.kuCyberAttacks;
      case 'kuVulnerabilities':
        return l10n.kuVulnerabilities;
      case 'kuCryptography':
        return l10n.kuCryptography;
      case 'kuOperatingSystems':
        return l10n.kuOperatingSystems;
      case 'kuQueryLanguages':
        return l10n.kuQueryLanguages;
      case 'kuWebMobileSystems':
        return l10n.kuWebMobileSystems;
      default:
        return localizationKey;
    }
  }

  Widget _buildKUCard({
    required Map<String, dynamic> ku,
    required bool isSelected,
    required ThemeData theme,
    required bool isRTL,
    required AppLocalizations l10n,
    required VoidCallback onTap,
  }) {
    final localizedName = _getLocalizedKUName(ku['localization_key'], l10n);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: isSelected ? ku['color'].withOpacity(0.1) : theme.cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isSelected ? ku['color'] : theme.dividerColor,
              width: isSelected ? 2 : 1,
            ),
            boxShadow: isSelected
                ? [
              BoxShadow(
                color: ku['color'].withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ]
                : [],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: ku['color'].withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        ku['icon'],
                        color: ku['color'],
                        size: 24,
                      ),
                    ),
                    if (isSelected)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: ku['color'],
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        localizedName,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: isSelected
                              ? ku['color']
                              : theme.textTheme.bodyLarge?.color,
                          height: 1.2,
                        ),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const Spacer(),
                      Row(
                        children: [
                          Icon(
                            Icons.topic,
                            size: 12,
                            color: AppColors.textSecondary,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '${ku['topics'].length} ${isRTL ? 'موضوع' : 'topics'}',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: AppColors.textSecondary,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _generateSummary() async {
    if (_selectedKU == null) return;

    final l10n = AppLocalizations.of(context)!;
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    setState(() {
      _isLoading = true;
    });

    try {
      // Get the selected KU details
      final ku = _knowledgeUnits.firstWhere((k) => k['id'] == _selectedKU);
      final selectedKUName = ku['name_en'];
      final localizedKUName = _getLocalizedKUName(ku['localization_key'], l10n);

      // Generate summary (single KU)
      final summary = await _courseService.generateCourseSummary(selectedKUName);

      setState(() {
        _isLoading = false;
      });

      // Navigate to summary display screen
      if (mounted) {
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SummaryDisplayScreen(
              summary: summary,
              selectedKUNames: [localizedKUName], // Single KU in a list
            ),
          ),
        );
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });

      if (mounted) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Row(
              children: [
                Icon(Icons.error_outline, color: AppColors.error),
                const SizedBox(width: 12),
                Text(isRTL ? 'حدث خطأ' : 'Error Occurred'),
              ],
            ),
            content: Text(
              e.toString().replaceAll('Exception: ', ''),
              style: TextStyle(fontSize: 16),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(isRTL ? 'إغلاق' : 'Close'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  _generateSummary();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.accent,
                ),
                child: Text(isRTL ? 'إعادة المحاولة' : 'Retry'),
              ),
            ],
          ),
        );
      }
    }
  }
}