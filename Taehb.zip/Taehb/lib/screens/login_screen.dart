import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../auth/bloc/auth_bloc.dart';
import '../auth/bloc/auth_event.dart';
import '../auth/bloc/auth_state.dart';
import '../core/constants/colors.dart';
import '../core/constants/strings.dart';
import '../core/utils/navigation.dart';
import '../core/utils/validators.dart';
import '../core/widgets/custom_button.dart';
import '../l10n/app_localizations.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  bool _isPasswordVisible = false;
  bool _rememberMe = false;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.3, 1.0, curve: Curves.easeOut),
    ));

    _animationController.forward();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _handleLogin() {
    if (_formKey.currentState?.validate() ?? false) {
      print('🔐 Login button pressed');
      print('📧 Email: ${_emailController.text.trim()}');
      print('🔑 Remember me: $_rememberMe');

      context.read<AuthBloc>().add(
        LoginRequested(
          email: _emailController.text.trim(),
          password: _passwordController.text,
          rememberMe: _rememberMe,
        ),
      );
    }
  }

  void _handleForgotPassword() {
    _showForgotPasswordDialog();
  }

  void _handleSignUp() {
    NavigationHelper.navigateTo(AppStrings.registerRoute);
  }



  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is AuthAuthenticated) {
          NavigationHelper.navigateAndRemoveUntil(
            '/home',
            arguments: {'userData': state.user},
          );
        } else if (state is AuthError) {


          NavigationHelper.showSnackBar(
            message: state.message,
            backgroundColor: AppColors.error,
            textColor: Colors.white,
          );
        } else if (state is ForgotPasswordSuccess) {

          NavigationHelper.showSnackBar(
            message: state.message,
            backgroundColor: AppColors.success,
            textColor: Colors.white,
          );
        } else if (state is AuthLoading) {
          print('AuthLoading state received');
        }
      },
      child: Scaffold(
        backgroundColor: theme.colorScheme.surface,
        body: Container(
          width: size.width,
          height: size.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.primary.withOpacity(0.1),
                theme.colorScheme.surface,
              ],
            ),
          ),
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: AnimatedBuilder(
                animation: _animationController,
                builder: (context, child) {
                  return FadeTransition(
                    opacity: _fadeAnimation,
                    child: SlideTransition(
                      position: _slideAnimation,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          SizedBox(height: size.height * 0.08),

                          // App logo and title
                          _buildHeader(theme, isRTL),

                          const SizedBox(height: 48),

                          // Login form
                          _buildLoginForm(theme),

                          const SizedBox(height: 32),

                          // Social login buttons
                          _buildSocialLogin(),

                          const SizedBox(height: 24),

                          // Sign up link
                          _buildSignUpLink(theme),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeData theme, bool isRTL) {
    final l10n = AppLocalizations.of(context)!;
    return Column(
      children: [
        // App logo
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: AppColors.primaryGradient,
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withOpacity(0.3),
                blurRadius: 15,
                spreadRadius: 1,
              ),
            ],
          ),
          child: const Icon(
            Icons.school_rounded,
            size: 40,
            color: Colors.white,
          ),
        ),

        const SizedBox(height: 24),

        // Welcome text
        Text(
          l10n.welcomeBack,
          style: theme.textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
          textAlign: TextAlign.center,
        ),

        const SizedBox(height: 8),

        // Subtitle
        Text(
          l10n.loginSubtitle,
          style: theme.textTheme.bodyLarge?.copyWith(
            color: AppColors.textSecondary,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildLoginForm(ThemeData theme) {
    final l10n = AppLocalizations.of(context)!;
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: l10n.email,
              hintText: l10n.enterYourEmail,
              prefixIcon: const Icon(Icons.email_outlined),
            ),
            validator: (value) => Validators.validateEmailLocalized(
              value,
              requiredMessage: l10n.emailRequired,
              invalidMessage: l10n.invalidEmail,
            ),
          ),

          const SizedBox(height: 16),

          // Password field
          TextFormField(
            controller: _passwordController,
            obscureText: !_isPasswordVisible,
            textInputAction: TextInputAction.done,
            onFieldSubmitted: (_) => _handleLogin(),
            decoration: InputDecoration(
              labelText: l10n.password,
              hintText: l10n.enterYourPassword,
              prefixIcon: const Icon(Icons.lock_outlined),
              suffixIcon: IconButton(
                icon: Icon(
                  _isPasswordVisible
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                ),
                onPressed: () {
                  setState(() {
                    _isPasswordVisible = !_isPasswordVisible;
                  });
                },
              ),
            ),
            validator: (value) => Validators.validateMinLengthLocalized(
              value,
              6,
              requiredMessage: l10n.passwordRequired,
              tooShortMessage: l10n.passwordMinLength(6),
            ),
          ),

          const SizedBox(height: 16),

          // Remember me and forgot password
          Row(
            children: [
              Checkbox(
                value: _rememberMe,
                onChanged: (value) {
                  setState(() {
                    _rememberMe = value ?? false;
                  });
                },
                activeColor: AppColors.primary,
              ),
              Text(l10n.rememberMe),
              const Spacer(),
              TextButton(
                onPressed: _handleForgotPassword,
                child: Text(l10n.forgotPassword),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Login button
          BlocBuilder<AuthBloc, AuthState>(
            builder: (context, state) {
              final isLoading = state is AuthLoading;
              print('🔄 Login button builder - isLoading: $isLoading');

              return CustomButton(
                text: l10n.signIn,
                onPressed: _handleLogin,
                isLoading: isLoading,
                isFullWidth: true,
                height: 52,
              );
            },
          ),
        ],
      ),
    );
  }
  void _showForgotPasswordDialog() {
    final emailController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final l10n = AppLocalizations.of(context)!;

    showDialog(
      context: context,
      barrierDismissible: false, // لا يمكن الإغلاق بالضغط خارج الحوار
      builder: (dialogContext) => BlocConsumer<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is ForgotPasswordSuccess) {
            // إغلاق الحوار
            Navigator.of(dialogContext).pop();

            // إظهار رسالة نجاح
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Row(
                  children: [
                    const Icon(Icons.check_circle, color: Colors.white),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        state.message,
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
                backgroundColor: AppColors.success,
                behavior: SnackBarBehavior.floating,
                duration: const Duration(seconds: 4),
              ),
            );
          } else if (state is AuthError) {
            // إغلاق الحوار
            Navigator.of(dialogContext).pop();

            // إظهار رسالة خطأ
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Row(
                  children: [
                    const Icon(Icons.error_outline, color: Colors.white),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        state.message,
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
                backgroundColor: AppColors.error,
                behavior: SnackBarBehavior.floating,
                duration: const Duration(seconds: 4),
              ),
            );
          }
        },
        builder: (context, state) {
          final isLoading = state is AuthLoading;

          return AlertDialog(
            title: Row(
              children: [
                Icon(Icons.lock_reset, color: AppColors.primary),
                const SizedBox(width: 12),
                Text(l10n.resetPassword),
              ],
            ),
            content: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    l10n.enterEmailToReset,
                    style: TextStyle(color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    enabled: !isLoading,
                    decoration: InputDecoration(
                      labelText: l10n.email,
                      hintText: l10n.enterYourEmail,
                      prefixIcon: const Icon(Icons.email_outlined),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    validator: (value) => Validators.validateEmailLocalized(
                      value,
                      requiredMessage: l10n.emailRequired,
                      invalidMessage: l10n.invalidEmail,
                    ),
                  ),
                  if (isLoading) ...[
                    const SizedBox(height: 16),
                    const LinearProgressIndicator(),
                    const SizedBox(height: 8),
                    Text(
                      'جارٍ إرسال الرابط...\nSending link...',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: isLoading ? null : () => Navigator.of(dialogContext).pop(),
                child: Text(l10n.cancel),
              ),
              ElevatedButton.icon(
                icon: isLoading
                    ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
                    : const Icon(Icons.send),
                label: Text(isLoading ? 'جارٍ الإرسال...' : l10n.sendResetLink),
                onPressed: isLoading
                    ? null
                    : () {
                  if (formKey.currentState?.validate() ?? false) {
                    final email = emailController.text.trim();
                    print('📧 Sending reset link to: $email');

                    context.read<AuthBloc>().add(
                      ForgotPasswordRequested(email: email),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
  Widget _buildSocialLogin() {
    final l10n = AppLocalizations.of(context)!;
    return Column(
      children: [
        // Divider with "OR"
        Row(
          children: [
            const Expanded(child: Divider()),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                l10n.or,
                style: TextStyle(
                  color: AppColors.textHint,
                  fontSize: 14,
                ),
              ),
            ),
            const Expanded(child: Divider()),
          ],
        ),

        const SizedBox(height: 24),

        // Google login button
        SocialLoginButton(
          text: l10n.continueWithGoogle,
          icon: Icon(Icons.g_mobiledata, color: Colors.red, size: 24),
          onPressed: () {
            context.read<AuthBloc>().add(const GoogleSignInRequested());
          },
        ),

        const SizedBox(height: 12),

        if (Theme.of(context).platform == TargetPlatform.iOS)
          SocialLoginButton(
            text: l10n.continueWithApple,
            icon: Icon(Icons.apple, color: Colors.black, size: 24),
            onPressed: () {
              context.read<AuthBloc>().add(const AppleSignInRequested());
            },
            backgroundColor: Colors.black,
            textColor: Colors.white,
          ),
      ],
    );
  }

  Widget _buildSignUpLink(ThemeData theme) {
    final l10n = AppLocalizations.of(context)!;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          '${l10n.dontHaveAnAccount} ',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: AppColors.textSecondary,
          ),
        ),
        TextButton(
          onPressed: _handleSignUp,
          child: Text(
            l10n.signUp,
            style: TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}