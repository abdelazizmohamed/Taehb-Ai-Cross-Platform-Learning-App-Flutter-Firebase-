import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taehb/auth/bloc/auth_bloc.dart';
import 'package:taehb/auth/bloc/auth_event.dart';
import 'package:taehb/core/constants/colors.dart';
import 'package:taehb/core/utils/navigation.dart';
import 'package:taehb/core/widgets/custom_profile.dart';
import 'package:taehb/l10n/app_localizations.dart';
import 'package:taehb/screens/change_password_screen.dart';
import 'package:taehb/screens/edit_profile_screen.dart';
import 'package:taehb/screens/exam_history_screen.dart';
import 'package:taehb/screens/help_support_screen.dart';
import 'package:taehb/screens/language_selection_screen.dart';
import 'package:taehb/screens/theme_selection_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authBloc = context.read<AuthBloc>();
    final user = authBloc.currentUser;
    ThemeData theme = Theme.of(context);
    final l10n = AppLocalizations.of(context)!;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          // Profile header
          Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: AppColors.primaryGradient,
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.3),
                  blurRadius: 15,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: user?.profileImageUrl != null
                ? ClipOval(
              child: Image.network(
                user!.profileImageUrl!,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.person,
                  size: 50,
                  color: Colors.white,
                ),
              ),
            )
                : const Icon(
              Icons.person,
              size: 50,
              color: Colors.white,
            ),
          ),

          const SizedBox(height: 16),

          Text(
            user?.name ?? 'Student',
            style: theme.textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 4),

          Text(
            user?.email ?? '',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: AppColors.textSecondary,
            ),
          ),

          const SizedBox(height: 32),

          // Profile Options
          buildProfileOption(
            theme: theme,
            icon: Icons.person_outline,
            title:l10n.editProfile,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const EditProfileScreen(),
                ),
              );
            },
          ),

          buildProfileOption(
            theme: theme,
            icon: Icons.history,
            title: l10n.examHistory,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ExamHistoryPage(),
                ),
              );
            },
          ),

          buildProfileOption(
            theme: theme,
            icon: Icons.lock_outline,
            title: l10n.changePassword,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ChangePasswordScreen(),
                ),
              );
            },
          ),

          // buildProfileOption(
          //   theme: theme,
          //   icon: Icons.notifications_outlined,
          //   title: l10n.notifications,
          //   onTap: () => _showComingSoon(context, 'Notifications'),
          // ),

          buildProfileOption(
            theme: theme,
            icon: Icons.language_outlined,
            title: l10n.language,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const LanguageSelectionScreen(),
                ),
              );
            },
          ),

          buildProfileOption(
            theme: theme,
            icon: Icons.dark_mode_outlined,
            title: l10n.darkMode,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ThemeSelectionScreen(),
                ),
              );
            },
          ),

          buildProfileOption(
            theme: theme,
            icon: Icons.help_outline,
            title: l10n.helpAndSupport,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const HelpSupportScreen(),
                ),
              );
            },
          ),

          const SizedBox(height: 16),

          // Logout button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              key: const Key('logout_button'),
              onPressed: () {
                _showLogoutDialog(context, theme, l10n);
              },
              icon: const Icon(Icons.logout),
              label: Text(l10n.logout),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.error,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog(BuildContext context, ThemeData theme ,AppLocalizations l10n) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.confirmLogout),
        content: Text(
          l10n.logoutConfirmation
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(l10n.cancel),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.read<AuthBloc>().add(const LogoutRequested());
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
            ),
            child: Text(l10n.logout),
          ),
        ],
      ),
    );
  }

  /// Show coming soon snackbar
  void _showComingSoon(BuildContext context, String feature) {
    final isRTL = Directionality.of(context) == TextDirection.rtl;
    NavigationHelper.showSnackBar(
      message: isRTL ? '$feature - قريباً!' : '$feature - Coming Soon!',
      backgroundColor: AppColors.info,
      textColor: Colors.white,
    );
  }
}