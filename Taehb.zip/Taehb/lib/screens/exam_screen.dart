import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:taehb/data/models/question.dart';
import 'package:taehb/data/repositories/exam_repository.dart';
import 'package:taehb/services/points_progress_service.dart';
import 'package:taehb/screens/results_screen.dart';
import 'package:taehb/l10n/app_localizations.dart';

class ExamScreen extends StatefulWidget {
  final List<Question> questions;
  final String knowledgeUnit;
  final int timePerQuestion;

  const ExamScreen({
    super.key,
    required this.questions,
    required this.knowledgeUnit,
    this.timePerQuestion = 30,
  });

  @override
  State<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends State<ExamScreen> {
  final PointsProgressService _pointsService = PointsProgressService();
  final ExamRepository _examRepository = ExamRepository();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  late String _sessionId;
  late String _userId;
  int _currentIndex = 0;
  final PageController _pageController = PageController();
  Timer? _timer;
  int _remainingTime = 0;
  bool _canAnswer = true;
  bool _isSubmitting = false;
  bool _isProcessingAnswer = false;
  bool _isMovingToNext = false; // جديد: لمنع الانتقال المتعدد

  // لتتبع وقت كل سؤال
  Map<int, DateTime> _questionStartTimes = {};
  Map<int, int> _questionTimeSpent = {};

  @override
  void initState() {
    super.initState();
    _userId = FirebaseAuth.instance.currentUser!.uid;
    _initializeSession();
    // بدء المؤقت بعد تأخير بسيط للسماح بتهيئة الواجهة
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) {
        _questionStartTimes[_currentIndex] = DateTime.now();
        _startTimer();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _initializeSession() async {
    try {
      final session = {
        'userId': _userId,
        'knowledgeUnit': widget.knowledgeUnit,
        'questionIds': widget.questions.map((q) => 'q_${q.questionNumber}').toList(),
        'startedAt': FieldValue.serverTimestamp(),
        'totalQuestions': widget.questions.length,
        'answeredQuestions': 0,
        'correctAnswers': 0,
        'totalPoints': 0,
        'status': 'in_progress',
      };

      final docRef = await _firestore.collection('quiz_sessions').add(session);
      _sessionId = docRef.id;
      print('✅ Session initialized: $_sessionId');
    } catch (e) {
      print('❌ Error initializing session: $e');
    }
  }


  void _startTimer() {
    // إلغاء أي مؤقت موجود
    _timer?.cancel();

    // إعادة تعيين الحالة
    setState(() {
      _remainingTime = widget.timePerQuestion;
      _canAnswer = true;
      _isProcessingAnswer = false;
      _isMovingToNext = false;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }

      setState(() {
        if (_remainingTime > 0) {
          _remainingTime--;
        } else {
          _onTimeUp();
        }
      });
    });
  }

  void _onTimeUp() {
    // تجنب التنفيذ المتعدد
    if (_isProcessingAnswer || _isMovingToNext) return;

    print('⏰ Time up for question ${_currentIndex + 1}');

    _timer?.cancel();

    setState(() {
      _canAnswer = false;
      _isProcessingAnswer = true;
    });

    // حساب الوقت المستغرق
    _recordQuestionTime();

    // الانتقال للسؤال التالي بدون حفظ إجابة
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted && !_isMovingToNext && !_isSubmitting) {
        _moveToNextQuestion();
      }
    });
  }

  void _recordQuestionTime() {
    if (_questionStartTimes.containsKey(_currentIndex)) {
      final startTime = _questionStartTimes[_currentIndex]!;
      final timeSpent = DateTime.now().difference(startTime).inSeconds;
      _questionTimeSpent[_currentIndex] = timeSpent;
      print('📊 Question ${_currentIndex + 1} time spent: $timeSpent seconds');
    }
  }

  String _getOptionLetter(String option) {
    final match = RegExp(r'^([A-D])[\)\.]').firstMatch(option);
    return match?.group(1) ?? '';
  }

  String _getCorrectAnswerLetter(Question question) {
    final match = RegExp(r'^([A-D])[\)\.]').firstMatch(question.correctAnswerText);
    return match?.group(1) ?? '';
  }

  Future<void> _selectAnswer(String option) async {
    // التحقق من الحالة
    if (!_canAnswer || _isProcessingAnswer || _isMovingToNext) {
      print('⛔ Cannot select answer - already processing');
      return;
    }

    final question = widget.questions[_currentIndex];
    if (question.selectedAnswer != null) {
      print('⛔ Question already answered');
      return;
    }

    print('✅ Answer selected for question ${_currentIndex + 1}');

    // قفل الإجابات فوراً
    setState(() {
      _isProcessingAnswer = true;
      _canAnswer = false;
    });

    // إيقاف المؤقت
    _timer?.cancel();

    // حساب الوقت المستغرق
    _recordQuestionTime();
    final timeSpent = _questionTimeSpent[_currentIndex] ?? widget.timePerQuestion;

    // تحديث حالة السؤال
    setState(() {
      question.selectedAnswer = option;

      final selectedLetter = _getOptionLetter(option);
      final correctLetter = _getCorrectAnswerLetter(question);
      question.isCorrect = selectedLetter == correctLetter;
    });

    // حفظ المحاولة
    try {
      await _recordAttempt(question, timeSpent);
    } catch (e) {
      print('❌ Error recording attempt: $e');
    }

    // الانتقال للسؤال التالي
    await Future.delayed(const Duration(milliseconds: 1500));

    if (mounted && !_isMovingToNext && !_isSubmitting) {
      _moveToNextQuestion();
    }
  }

  /// تسجيل المحاولة في Firebase
  Future<void> _recordAttempt(Question question, int timeSpent) async {
    try {
      final difficulty = 3;
      final selectedAnswerIndex = question.options.indexOf(question.selectedAnswer!);

      final attempt = await _pointsService.recordAttempt(
        sessionId: _sessionId,
        userId: _userId,
        questionId: 'q_${question.questionNumber}',
        unitId: widget.knowledgeUnit, // Changed: use single KU
        selectedAnswerIndex: selectedAnswerIndex,
        isCorrect: question.isCorrect ?? false,
        difficulty: difficulty,
        timeSpentSeconds: timeSpent,
      );

      await _pointsService.updateQuizSession(
        sessionId: _sessionId,
        isCorrect: question.isCorrect ?? false,
        pointsEarned: attempt.pointsEarned,
      );

      print('✅ Attempt recorded: +${attempt.pointsEarned} points');
    } catch (e) {
      print('❌ Error recording attempt: $e');
    }
  }

  void _moveToNextQuestion() {
    // منع الانتقال المتعدد
    if (_isMovingToNext) {
      print('⛔ Already moving to next question');
      return;
    }

    setState(() {
      _isMovingToNext = true;
    });

    if (_currentIndex < widget.questions.length - 1) {
      print('➡️ Moving to question ${_currentIndex + 2}');

      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      ).then((_) {
        if (mounted) {
          setState(() {
            _currentIndex++;
            _questionStartTimes[_currentIndex] = DateTime.now();
            _isProcessingAnswer = false;
            _isMovingToNext = false;
          });

          print('📝 Now on question ${_currentIndex + 1}');

          // بدء المؤقت للسؤال الجديد
          _startTimer();
        }
      });
    } else {
      print('🏁 Finishing exam');
      _finishExam();
    }
  }

  Future<void> _finishExam() async {
    if (_isSubmitting) {
      print('⛔ Already submitting');
      return;
    }

    print('💾 Submitting exam results...');

    _timer?.cancel();

    setState(() {
      _isSubmitting = true;
    });

    try {
      await _pointsService.completeQuizSession(
        sessionId: _sessionId,
        userId: _userId,
        unitIds: [widget.knowledgeUnit], // Changed: single unit
      );

      await _examRepository.saveExamResult(
        userId: _userId,
        selectedKU: widget.knowledgeUnit, // Changed
        questions: widget.questions,
      );

      print('✅ Exam completed successfully');

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ResultsPage(
              questions: widget.questions,
              knowledgeUnit: widget.knowledgeUnit, // Changed: pass single KU
              sessionId: _sessionId,
            ),
          ),
        );
      }
    } catch (e) {
      print('❌ Error finishing exam: $e');

      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(AppLocalizations.of(context)!.errorSavingResults),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Color _getTimerColor() {
    final percentage = _remainingTime / widget.timePerQuestion;
    if (percentage > 0.5) return Colors.green;
    if (percentage > 0.25) return Colors.orange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final question = widget.questions[_currentIndex];
    final progress = (_currentIndex + 1) / widget.questions.length;

    return WillPopScope(
      onWillPop: () async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(l10n.warning),
            content: Text(l10n.exitExamWarning ?? 'Are you sure you want to exit the exam? Your progress will be lost.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text(l10n.cancel ?? 'Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: Text(l10n.exit ?? 'Exit'),
              ),
            ],
          ),
        );
        return shouldPop ?? false;
      },
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: AppBar(
          backgroundColor: Colors.deepPurple,
          foregroundColor: Colors.white,
          title: Text(l10n.questionProgress(_currentIndex + 1, widget.questions.length)),
          centerTitle: true,
          automaticallyImplyLeading: false,
        ),
        body: _isSubmitting
            ? Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              Text(
                l10n.savingResults,
                style: const TextStyle(fontSize: 16),
              ),
            ],
          ),
        )
            : Column(
          children: [
            // Progress bar
            LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.grey.shade200,
              valueColor: const AlwaysStoppedAnimation<Color>(Colors.deepPurple),
              minHeight: 6,
            ),

            // Timer display
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
              decoration: BoxDecoration(
                color: _getTimerColor().withOpacity(0.1),
                border: Border(
                  bottom: BorderSide(
                    color: _getTimerColor(),
                    width: 3,
                  ),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.timer_outlined,
                    color: _getTimerColor(),
                    size: 28,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '$_remainingTime ${l10n.seconds ?? 'seconds'}',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: _getTimerColor(),
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: PageView.builder(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.questions.length,
                itemBuilder: (context, index) {
                  final q = widget.questions[index];
                  final isCurrentQuestion = index == _currentIndex;

                  return SingleChildScrollView(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.08),
                                blurRadius: 20,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                      color: Colors.deepPurple,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Center(
                                      child: Text(
                                        '${q.questionNumber}',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  if (q.selectedAnswer != null)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: q.isCorrect! ? Colors.green.shade50 : Colors.red.shade50,
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                          color: q.isCorrect! ? Colors.green : Colors.red,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          Icon(
                                            q.isCorrect! ? Icons.check_circle : Icons.cancel,
                                            size: 18,
                                            color: q.isCorrect! ? Colors.green : Colors.red,
                                          ),
                                          const SizedBox(width: 6),
                                          Text(
                                            q.isCorrect! ? l10n.correct : l10n.wrong,
                                            style: TextStyle(
                                              color: q.isCorrect! ? Colors.green : Colors.red,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  else if (!_canAnswer && q.selectedAnswer == null && isCurrentQuestion)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade100,
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(color: Colors.grey),
                                      ),
                                      child: Row(
                                        children: [
                                          Icon(Icons.timer_off, size: 18, color: Colors.grey.shade700),
                                          const SizedBox(width: 6),
                                          Text(
                                            l10n.timeUp ?? 'Time Up',
                                            style: TextStyle(
                                              color: Colors.grey.shade700,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                ],
                              ),
                              const SizedBox(height: 20),
                              Text(
                                q.questionText,
                                style: TextStyle(
                                  fontSize: 18,
                                  height: 1.6,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey.shade900,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),

                        // Options
                        ...q.options.map((option) {
                          final letter = _getOptionLetter(option);
                          final isSelected = q.selectedAnswer == option;
                          final correctLetter = _getCorrectAnswerLetter(q);
                          final isCorrectOption = letter == correctLetter;
                          final showAsCorrect = q.selectedAnswer != null && isCorrectOption;
                          final showAsWrong = q.selectedAnswer != null && isSelected && !isCorrectOption;
                          final isDisabled = !isCurrentQuestion || !_canAnswer || q.selectedAnswer != null || _isProcessingAnswer || _isMovingToNext;

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Opacity(
                              opacity: isDisabled && !isSelected && !showAsCorrect ? 0.5 : 1.0,
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: isDisabled ? null : () => _selectAnswer(option),
                                  borderRadius: BorderRadius.circular(16),
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 300),
                                    padding: const EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color: showAsCorrect
                                          ? Colors.green.shade50
                                          : showAsWrong
                                          ? Colors.red.shade50
                                          : Colors.white,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(
                                        color: showAsCorrect
                                            ? Colors.green
                                            : showAsWrong
                                            ? Colors.red
                                            : Colors.grey.shade300,
                                        width: showAsCorrect || showAsWrong ? 2 : 1,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.05),
                                          blurRadius: 8,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 36,
                                          height: 36,
                                          decoration: BoxDecoration(
                                            color: showAsCorrect
                                                ? Colors.green
                                                : showAsWrong
                                                ? Colors.red
                                                : Colors.grey.shade200,
                                            shape: BoxShape.circle,
                                          ),
                                          child: Center(
                                            child: Text(
                                              letter,
                                              style: TextStyle(
                                                color: showAsCorrect || showAsWrong
                                                    ? Colors.white
                                                    : Colors.grey.shade700,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 16,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Text(
                                            option.replaceFirst(RegExp(r'^[A-D][\)\.]?\s*'), ''),
                                            style: TextStyle(
                                              fontSize: 16,
                                              height: 1.5,
                                              color: Colors.grey.shade800,
                                            ),
                                          ),
                                        ),
                                        if (showAsCorrect)
                                          const Icon(Icons.check_circle, color: Colors.green, size: 24),
                                        if (showAsWrong)
                                          const Icon(Icons.cancel, color: Colors.red, size: 24),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}