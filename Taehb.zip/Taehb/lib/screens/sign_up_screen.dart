import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../auth/bloc/auth_bloc.dart';
import '../auth/bloc/auth_event.dart';
import '../auth/bloc/auth_state.dart';
import '../core/constants/colors.dart';
import '../core/constants/strings.dart';
import '../core/utils/navigation.dart';
import '../core/utils/validators.dart';
import '../core/widgets/custom_button.dart';

/// Complete Sign Up Screen with profile image upload
class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _phoneController = TextEditingController();
  final _universityController = TextEditingController();
  final _majorController = TextEditingController();

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  bool _agreedToTerms = false;
  int? _selectedYearOfStudy;
  File? _selectedImage;
  final ImagePicker _imagePicker = ImagePicker();

  final List<int> _yearsOfStudy = [1, 2, 3, 4, 5, 6];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.3, 1.0, curve: Curves.easeOut),
    ));

    _animationController.forward();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _phoneController.dispose();
    _universityController.dispose();
    _majorController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image != null) {
        setState(() {
          _selectedImage = File(image.path);
        });
      }
    } catch (e) {
      NavigationHelper.showSnackBar(
        message: 'Failed to pick image: ${e.toString()}',
        backgroundColor: AppColors.error,
        textColor: Colors.white,
      );
    }
  }

  Future<void> _takePhoto() async {
    try {
      final XFile? photo = await _imagePicker.pickImage(
        source: ImageSource.camera,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (photo != null) {
        setState(() {
          _selectedImage = File(photo.path);
        });
      }
    } catch (e) {
      NavigationHelper.showSnackBar(
        message: 'Failed to take photo: ${e.toString()}',
        backgroundColor: AppColors.error,
        textColor: Colors.white,
      );
    }
  }

  void _showImageSourceDialog() {
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              isRTL ? 'اختر مصدر الصورة' : 'Choose Image Source',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.photo_library, color: AppColors.primary),
              title: Text(isRTL ? 'معرض الصور' : 'Gallery'),
              onTap: () {
                Navigator.pop(context);
                _pickImage();
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: AppColors.primary),
              title: Text(isRTL ? 'الكاميرا' : 'Camera'),
              onTap: () {
                Navigator.pop(context);
                _takePhoto();
              },
            ),
            if (_selectedImage != null)
              ListTile(
                leading: const Icon(Icons.delete, color: AppColors.error),
                title: Text(isRTL ? 'إزالة الصورة' : 'Remove Image'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _selectedImage = null;
                  });
                },
              ),
          ],
        ),
      ),
    );
  }

  void _handleSignUp() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (!_agreedToTerms) {
      NavigationHelper.showSnackBar(
        message: 'Please agree to Terms & Conditions',
        backgroundColor: AppColors.warning,
        textColor: Colors.white,
      );
      return;
    }

    context.read<AuthBloc>().add(
      RegisterRequested(
        name: _nameController.text.trim(),
        email: _emailController.text.trim(),
        password: _passwordController.text,
        phone: _phoneController.text.trim().isEmpty
            ? null
            : _phoneController.text.trim(),
        university: _universityController.text.trim().isEmpty
            ? null
            : _universityController.text.trim(),
        major: _majorController.text.trim().isEmpty
            ? null
            : _majorController.text.trim(),
        yearOfStudy: _selectedYearOfStudy,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is AuthAuthenticated) {
          NavigationHelper.navigateAndRemoveUntil(
            AppStrings.homeRoute,
            arguments: {'userData': state.user},
          );
        } else if (state is AuthError) {
          NavigationHelper.showSnackBar(
            message: state.message,
            backgroundColor: AppColors.error,
            textColor: Colors.white,
          );
        }
      },
      child: Scaffold(
        backgroundColor: theme.colorScheme.background,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: Icon(
              isRTL ? Icons.arrow_forward : Icons.arrow_back,
              color: AppColors.primary,
            ),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: Container(
          width: size.width,
          height: size.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.primary.withOpacity(0.05),
                theme.colorScheme.background,
              ],
            ),
          ),
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: AnimatedBuilder(
                animation: _animationController,
                builder: (context, child) {
                  return FadeTransition(
                    opacity: _fadeAnimation,
                    child: SlideTransition(
                      position: _slideAnimation,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // Header
                          _buildHeader(theme, isRTL),

                          const SizedBox(height: 32),

                          // Profile Image Picker
                          _buildProfileImagePicker(theme, isRTL),

                          const SizedBox(height: 32),

                          // Sign Up Form
                          _buildSignUpForm(theme, isRTL),

                          const SizedBox(height: 24),

                          // Terms & Conditions
                          _buildTermsCheckbox(theme, isRTL),

                          const SizedBox(height: 24),

                          // Sign Up Button
                          BlocBuilder<AuthBloc, AuthState>(
                            builder: (context, state) {
                              return CustomButton(
                                key: const Key('signup_button'),
                                text: isRTL ? 'إنشاء حساب' : 'Create Account',
                                onPressed: _handleSignUp,
                                isLoading: state is AuthLoading,
                                isFullWidth: true,
                                height: 52,
                              );
                            },
                          ),

                          const SizedBox(height: 16),

                          // Login Link
                          _buildLoginLink(theme, isRTL),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeData theme, bool isRTL) {
    return Column(
      children: [
        // App logo
        Container(
          width: 70,
          height: 70,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: AppColors.primaryGradient,
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withOpacity(0.3),
                blurRadius: 15,
                spreadRadius: 1,
              ),
            ],
          ),
          child: const Icon(
            Icons.school_rounded,
            size: 35,
            color: Colors.white,
          ),
        ),

        const SizedBox(height: 20),

        Text(
          isRTL ? 'إنشاء حساب جديد' : 'Create Account',
          style: theme.textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: AppColors.textPrimary,
          ),
          textAlign: TextAlign.center,
        ),

        const SizedBox(height: 8),

        Text(
          isRTL ? 'انضم إلى آلاف الطلاب الناجحين' : 'Join thousands of successful students',
          style: theme.textTheme.bodyLarge?.copyWith(
            color: AppColors.textSecondary,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildProfileImagePicker(ThemeData theme, bool isRTL) {
    return Center(
      child: GestureDetector(
        onTap: _showImageSourceDialog,
        child: Stack(
          children: [
            // Profile Image Container
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.primary.withOpacity(0.1),
                border: Border.all(
                  color: AppColors.primary,
                  width: 3,
                ),
                image: _selectedImage != null
                    ? DecorationImage(
                  image: FileImage(_selectedImage!),
                  fit: BoxFit.cover,
                )
                    : null,
              ),
              child: _selectedImage == null
                  ? const Icon(
                Icons.person,
                size: 50,
                color: AppColors.primary,
              )
                  : null,
            ),

            // Camera Icon
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white,
                    width: 3,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.accent.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.camera_alt,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSignUpForm(ThemeData theme, bool isRTL) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          // Full Name
          TextFormField(
            key: const Key('name_field'),
            controller: _nameController,
            keyboardType: TextInputType.name,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: isRTL ? 'الاسم الكامل' : 'Full Name',
              hintText: isRTL ? 'أدخل اسمك الكامل' : 'Enter your full name',
              prefixIcon: const Icon(Icons.person_outline),
            ),
            validator: Validators.validateName,
          ),

          const SizedBox(height: 16),

          // Email
          TextFormField(
            key: const Key('email_field'),
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: isRTL ? 'البريد الإلكتروني' : 'Email',
              hintText: isRTL ? 'أدخل بريدك الإلكتروني' : 'Enter your email',
              prefixIcon: const Icon(Icons.email_outlined),
            ),
            validator: Validators.validateEmail,
          ),

          const SizedBox(height: 16),

          // Password
          TextFormField(
            key: const Key('password_field'),
            controller: _passwordController,
            obscureText: !_isPasswordVisible,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: isRTL ? 'كلمة المرور' : 'Password',
              hintText: isRTL ? 'أدخل كلمة المرور' : 'Enter password',
              prefixIcon: const Icon(Icons.lock_outlined),
              suffixIcon: IconButton(
                icon: Icon(
                  _isPasswordVisible
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                ),
                onPressed: () {
                  setState(() {
                    _isPasswordVisible = !_isPasswordVisible;
                  });
                },
              ),
            ),
            validator: Validators.validatePassword,
          ),

          const SizedBox(height: 16),

          // Confirm Password
          TextFormField(
            key: const Key('confirm_password_field'),
            controller: _confirmPasswordController,
            obscureText: !_isConfirmPasswordVisible,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: isRTL ? 'تأكيد كلمة المرور' : 'Confirm Password',
              hintText: isRTL ? 'أعد إدخال كلمة المرور' : 'Re-enter password',
              prefixIcon: const Icon(Icons.lock_outlined),
              suffixIcon: IconButton(
                icon: Icon(
                  _isConfirmPasswordVisible
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                ),
                onPressed: () {
                  setState(() {
                    _isConfirmPasswordVisible = !_isConfirmPasswordVisible;
                  });
                },
              ),
            ),
            validator: (value) => Validators.validatePasswordMatch(
              value,
              _passwordController.text,
            ),
          ),

          const SizedBox(height: 16),

          TextFormField(
            key: const Key('phone_field'),
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: isRTL ? 'رقم الهاتف (اختياري)' : 'Phone (Optional)',
              hintText: isRTL ? 'أدخل رقم هاتفك' : 'Enter your phone',
              prefixIcon: const Icon(Icons.phone_outlined),
            ),
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return null;
              }
              return Validators.validatePhone(value);
            },
          ),

          const SizedBox(height: 16),

          // University (Optional)
          TextFormField(
            key: const Key('university_field'),
            controller: _universityController,
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: isRTL ? 'الجامعة (اختياري)' : 'University (Optional)',
              hintText: isRTL ? 'أدخل اسم جامعتك' : 'Enter your university',
              prefixIcon: const Icon(Icons.school_outlined),
            ),
          ),

          const SizedBox(height: 16),

          // Major (Optional)
          TextFormField(
            key: const Key('major_field'),
            controller: _majorController,
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              labelText: isRTL ? 'التخصص (اختياري)' : 'Major (Optional)',
              hintText: isRTL ? 'أدخل تخصصك' : 'Enter your major',
              prefixIcon: const Icon(Icons.book_outlined),
            ),
          ),

          const SizedBox(height: 16),

          // Year of Study Dropdown
          DropdownButtonFormField<int>(
            key: const Key('year_of_study_field'),
            value: _selectedYearOfStudy,
            decoration: InputDecoration(
              labelText: isRTL ? 'السنة الدراسية (اختياري)' : 'Year of Study (Optional)',
              prefixIcon: const Icon(Icons.calendar_today_outlined),
            ),
            items: _yearsOfStudy.map((year) {
              return DropdownMenuItem(
                value: year,
                child: Text(isRTL ? 'السنة $year' : 'Year $year'),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedYearOfStudy = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTermsCheckbox(ThemeData theme, bool isRTL) {
    return Row(
      children: [
        Checkbox(
          key: const Key('terms_checkbox'),
          value: _agreedToTerms,
          onChanged: (value) {
            setState(() {
              _agreedToTerms = value ?? false;
            });
          },
          activeColor: AppColors.primary,
        ),
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _agreedToTerms = !_agreedToTerms;
              });
            },
            child: Text.rich(
              TextSpan(
                text: isRTL ? 'أوافق على ' : 'I agree to ',
                style: theme.textTheme.bodyMedium,
                children: [
                  TextSpan(
                    text: isRTL ? 'الشروط والأحكام' : 'Terms & Conditions',
                    style: TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  TextSpan(
                    text: isRTL ? ' و' : ' and ',
                  ),
                  TextSpan(
                    text: isRTL ? 'سياسة الخصوصية' : 'Privacy Policy',
                    style: TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoginLink(ThemeData theme, bool isRTL) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          isRTL ? 'لديك حساب بالفعل؟ ' : 'Already have an account? ',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: AppColors.textSecondary,
          ),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(
            isRTL ? 'تسجيل الدخول' : 'Sign In',
            style: TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}