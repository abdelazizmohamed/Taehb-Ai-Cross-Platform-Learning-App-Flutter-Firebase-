import 'package:flutter/material.dart';
import 'package:taehb/screens/exam_confirmation_screen.dart';
import 'package:taehb/l10n/app_localizations.dart';

class KUSelectionPage extends StatefulWidget {
  const KUSelectionPage({super.key});

  @override
  State<KUSelectionPage> createState() => _KUSelectionPageState();
}

class _KUSelectionPageState extends State<KUSelectionPage> {
  final Map<String, String> kuKeys = {
    'kuUserResearch': "User Research",
    'kuInteractionDesign': "Interaction Design and User Testing",
    'kuProjectManagement': "Project Management Principles",
    'kuEthicalIssues': "Ethical, Legal, and Privacy Issues",
    'kuInformationSystems': "Information Systems Principles",
    'kuCyberAttacks': "Cyber-attacks and Detection",
    'kuVulnerabilities': "Vulnerabilities, Threats, and Risk",
    'kuCryptography': "Cryptography Overview",
    'kuSecurityServices': "Security Services, Mechanisms, and Countermeasures",
    'kuNetworkingFoundations': "Foundations of Networking",
    'kuNetworkManagement': "Network Management",
    'kuOperatingSystems': "Operating Systems",
    'kuDataConcepts': "Data-information Concepts",
    'kuDataModeling': "Data Modeling",
    'kuDatabaseEnvironment': "Managing the Database Environment",
    'kuQueryLanguages': "Database Query Languages",
    'kuRequirementsEngineering': "Requirements Engineering and Testing",
    'kuProblemSolving': "Problem Solving and Program Development",
    'kuDataStructures': "Fundamentals of Data Structures and Algorithms",
    'kuWebMobileSystems': "Web and Mobile Systems Concepts and Technologies",
  };

  String? selectedKU;

  void navigateToConfirmation() {
    final l10n = AppLocalizations.of(context)!;

    if (selectedKU == null) {
      _showSnackBar(l10n.pleaseSelectKU, isError: true);
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ExamConfirmationPage(
          selectedKU: selectedKU!, // Changed: pass single KU
          kuKeys: kuKeys,
        ),
      ),
    );
  }

  void _showSnackBar(String message, {required bool isError}) {
    final colorScheme = Theme.of(context).colorScheme;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white,
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: isError ? colorScheme.error : colorScheme.secondary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final kuKeysList = kuKeys.keys.toList();
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: CustomScrollView(
        slivers: [
          SliverAppBar.large(
            floating: true,
            snap: true,
            centerTitle: true,
            backgroundColor: colorScheme.primary,
            foregroundColor: colorScheme.onPrimary,
            title: Text(
              l10n.selectKUs,
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(50),
              child: Container(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.info_outline, color: colorScheme.onPrimary, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'Select ONE Knowledge Unit',
                      style: TextStyle(
                        color: colorScheme.onPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(16.0),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  final kuKey = kuKeysList[index];
                  final isSelected = selectedKU == kuKey;

                  String getLocalizedKU(String key) {
                    switch (key) {
                      case 'kuUserResearch': return l10n.kuUserResearch;
                      case 'kuInteractionDesign': return l10n.kuInteractionDesign;
                      case 'kuProjectManagement': return l10n.kuProjectManagement;
                      case 'kuEthicalIssues': return l10n.kuEthicalIssues;
                      case 'kuInformationSystems': return l10n.kuInformationSystems;
                      case 'kuCyberAttacks': return l10n.kuCyberAttacks;
                      case 'kuVulnerabilities': return l10n.kuVulnerabilities;
                      case 'kuCryptography': return l10n.kuCryptography;
                      case 'kuSecurityServices': return l10n.kuSecurityServices;
                      case 'kuNetworkingFoundations': return l10n.kuNetworkingFoundations;
                      case 'kuNetworkManagement': return l10n.kuNetworkManagement;
                      case 'kuOperatingSystems': return l10n.kuOperatingSystems;
                      case 'kuDataConcepts': return l10n.kuDataConcepts;
                      case 'kuDataModeling': return l10n.kuDataModeling;
                      case 'kuDatabaseEnvironment': return l10n.kuDatabaseEnvironment;
                      case 'kuQueryLanguages': return l10n.kuQueryLanguages;
                      case 'kuRequirementsEngineering': return l10n.kuRequirementsEngineering;
                      case 'kuProblemSolving': return l10n.kuProblemSolving;
                      case 'kuDataStructures': return l10n.kuDataStructures;
                      case 'kuWebMobileSystems': return l10n.kuWebMobileSystems;
                      default: return key;
                    }
                  }

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            // Changed: Only one selection at a time
                            selectedKU = isSelected ? null : kuKey;
                          });
                        },
                        borderRadius: BorderRadius.circular(20),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          decoration: BoxDecoration(
                            gradient: isSelected
                                ? LinearGradient(
                              colors: [
                                colorScheme.primary.withOpacity(0.1),
                                colorScheme.primaryContainer.withOpacity(0.2),
                              ],
                            )
                                : null,
                            color: isSelected ? null : theme.cardColor,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isSelected ? colorScheme.primary : colorScheme.outline,
                              width: isSelected ? 2.5 : 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: !isSelected
                                    ? Colors.black.withOpacity(0.05)
                                    : colorScheme.primary.withOpacity(0.2),
                                blurRadius: isSelected ? 12 : 8,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              children: [
                                AnimatedContainer(
                                  duration: const Duration(milliseconds: 300),
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    color: isSelected ? colorScheme.primary : colorScheme.surfaceVariant,
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: Icon(
                                    isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                                    color: isSelected ? colorScheme.onPrimary : colorScheme.outline,
                                    size: 28,
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Text(
                                    getLocalizedKU(kuKey),
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                                      color: isSelected ? colorScheme.primary : colorScheme.onSurface,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
                childCount: kuKeysList.length,
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: selectedKU != null
          ? FloatingActionButton.extended(
        onPressed: navigateToConfirmation,
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        icon: const Icon(Icons.play_arrow_rounded),
        label: Text(
          l10n.startExam,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        elevation: 8,
      )
          : null,
    );
  }
}