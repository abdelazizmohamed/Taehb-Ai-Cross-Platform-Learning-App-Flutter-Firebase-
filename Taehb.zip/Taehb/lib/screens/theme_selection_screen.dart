import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taehb/core/constants/colors.dart';
import '../core/themes/theme_cubit.dart';
import 'package:taehb/l10n/app_localizations.dart';

class ThemeSelectionScreen extends StatelessWidget {
  const ThemeSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.darkMode),
      ),
      body: BlocBuilder<ThemeCubit, AppThemeMode>(
        builder: (context, currentTheme) {
          return ListView(
            padding: const EdgeInsets.all(20.0),
            children: [
              Text(
                l10n.chooseTheme ?? 'Choose your preferred theme',
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: AppColors.textSecondary,
                ),
              ),

              const SizedBox(height: 24),

              // Light Theme Option
              _ThemeOption(
                title: l10n.lightMode ?? 'Light Mode',
                description: l10n.lightModeDescription ??
                    'Bright and clear appearance',
                icon: Icons.light_mode,
                isSelected: currentTheme == AppThemeMode.light,
                onTap: () {
                  context.read<ThemeCubit>().changeTheme(AppThemeMode.light);
                },
              ),

              const SizedBox(height: 12),

              // Dark Theme Option
              _ThemeOption(
                title: l10n.darkMode,
                description: l10n.darkModeDescription ??
                    'Easy on the eyes in low light',
                icon: Icons.dark_mode,
                isSelected: currentTheme == AppThemeMode.dark,
                onTap: () {
                  context.read<ThemeCubit>().changeTheme(AppThemeMode.dark);
                },
              ),

              const SizedBox(height: 12),

              // System Theme Option
              _ThemeOption(
                title: l10n.systemDefault ?? 'System Default',
                description: l10n.systemDefaultDescription ??
                    'Follow system settings',
                icon: Icons.settings_suggest,
                isSelected: currentTheme == AppThemeMode.system,
                onTap: () {
                  context.read<ThemeCubit>().changeTheme(AppThemeMode.system);
                },
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ThemeOption extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _ThemeOption({
    required this.title,
    required this.description,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary.withOpacity(0.1)
              : theme.cardTheme.color,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? AppColors.primary
                : Colors.transparent,
            width: 2,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isSelected
                    ? AppColors.primary
                    : theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: isSelected
                    ? Colors.white
                    : theme.iconTheme.color,
                size: 28,
              ),
            ),

            const SizedBox(width: 16),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: isSelected
                          ? AppColors.primary
                          : null,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),

            if (isSelected)
              Icon(
                Icons.check_circle,
                color: AppColors.primary,
                size: 28,
              ),
          ],
        ),
      ),
    );
  }
}