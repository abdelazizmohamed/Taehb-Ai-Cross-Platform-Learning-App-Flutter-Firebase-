// lib/screens/leaderboard/leaderboard_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:taehb/l10n/app_localizations.dart';
import '../providers/app_providers.dart';
import '../data/models/leaderboard_entry.dart';

class LeaderboardScreen extends ConsumerWidget {
  const LeaderboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final leaderboardAsync = ref.watch(leaderboardProvider);
    final currentUser = ref.watch(currentUserProvider).value;
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              colorScheme.primary.withOpacity(0.1),
              colorScheme.surface,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Container(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: isRTL
                                ? CrossAxisAlignment.center
                                : CrossAxisAlignment.center,
                            children: [
                              Text(
                                l10n.leaderboard,
                                style: theme.textTheme.headlineMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: colorScheme.primary,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                l10n.topPerformers,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: colorScheme.onSurface.withOpacity(0.6),
                                ),
                              ),
                            ],
                          ),
                        ),

                      ],
                    ),
                  ],
                ),
              ),

              // Leaderboard List
              Expanded(
                child: leaderboardAsync.when(
                  loading: () => Center(
                    child: CircularProgressIndicator(color: colorScheme.primary),
                  ),
                  error: (error, stack) => Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.error_outline, size: 48, color: colorScheme.error),
                        const SizedBox(height: 16),
                        Text(
                          l10n.errorLoadingLeaderboard,
                          style: TextStyle(
                            fontSize: 16,
                            color: colorScheme.onSurface,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          error.toString(),
                          style: TextStyle(
                            fontSize: 12,
                            color: colorScheme.onSurface.withOpacity(0.6),
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () => ref.invalidate(leaderboardProvider),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: colorScheme.primary,
                            foregroundColor: colorScheme.onPrimary,
                          ),
                          child: Text(l10n.retry),
                        ),
                      ],
                    ),
                  ),
                  data: (entries) {
                    if (entries.isEmpty) {
                      return Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.emoji_events_outlined,
                              size: 64,
                              color: colorScheme.outline,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              l10n.noLeaderboardData,
                              style: TextStyle(
                                fontSize: 18,
                                color: colorScheme.onSurface.withOpacity(0.6),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              l10n.beFirstToCompete,
                              style: TextStyle(
                                fontSize: 14,
                                color: colorScheme.onSurface.withOpacity(0.5),
                              ),
                            ),
                          ],
                        ),
                      );
                    }

                    final topThree = entries.take(3).toList();
                    final remaining = entries.skip(3).toList();

                    return RefreshIndicator(
                      color: colorScheme.primary,
                      onRefresh: () async {
                        ref.invalidate(leaderboardProvider);
                      },
                      child: Column(
                        children: [
                          if (topThree.isNotEmpty)
                            _buildPodium(context, topThree, currentUser?.id, l10n, colorScheme),
                          const SizedBox(height: 20),
                          Expanded(
                            child: ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              itemCount: remaining.length,
                              itemBuilder: (context, index) {
                                final entry = remaining[index];
                                final isCurrentUser = entry.userId == currentUser?.id;

                                return _buildLeaderboardTile(
                                  context,
                                  entry,
                                  isCurrentUser,
                                  l10n,
                                  theme,
                                  colorScheme,
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPodium(
      BuildContext context,
      List<LeaderboardEntry> topThree,
      String? currentUserId,
      AppLocalizations l10n,
      ColorScheme colorScheme,
      ) {
    final podiumOrder = <LeaderboardEntry?>[];
    if (topThree.length >= 2) {
      podiumOrder.add(topThree[1]);
    } else {
      podiumOrder.add(null);
    }
    if (topThree.isNotEmpty) {
      podiumOrder.add(topThree[0]);
    } else {
      podiumOrder.add(null);
    }
    if (topThree.length >= 3) {
      podiumOrder.add(topThree[2]);
    } else {
      podiumOrder.add(null);
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      height: 260,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (podiumOrder[0] != null)
            _buildPodiumPlace(
              context,
              podiumOrder[0]!,
              2,
              120,
              colorScheme.outline,
              podiumOrder[0]!.userId == currentUserId,
              l10n,
              colorScheme,
            ),
          const SizedBox(width: 8),
          if (podiumOrder[1] != null)
            _buildPodiumPlace(
              context,
              podiumOrder[1]!,
              1,
              140,
              colorScheme.tertiary,
              podiumOrder[1]!.userId == currentUserId,
              l10n,
              colorScheme,
            ),
          const SizedBox(width: 8),
          if (podiumOrder[2] != null)
            _buildPodiumPlace(
              context,
              podiumOrder[2]!,
              3,
              100,
              Colors.brown,
              podiumOrder[2]!.userId == currentUserId,
              l10n,
              colorScheme,
            ),
        ],
      ),
    );
  }

  Widget _buildPodiumPlace(
      BuildContext context,
      LeaderboardEntry entry,
      int place,
      double height,
      Color medalColor,
      bool isCurrentUser,
      AppLocalizations l10n,
      ColorScheme colorScheme,
      ) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: isCurrentUser ? colorScheme.primary : medalColor,
              width: 2,
            ),
          ),
          child: CircleAvatar(
            radius: 24,
            backgroundColor: medalColor.withOpacity(0.1),
            child: Text(
              entry.displayName.isNotEmpty
                  ? entry.displayName[0].toUpperCase()
                  : 'U',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: medalColor,
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        SizedBox(
          width: 80,
          child: Text(
            entry.displayName,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: isCurrentUser ? colorScheme.primary : colorScheme.onSurface,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          '${entry.totalPoints} ${l10n.pts}',
          style: TextStyle(
            fontSize: 10,
            color: colorScheme.onSurface.withOpacity(0.6),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          width: 80,
          height: height,
          decoration: BoxDecoration(
            color: medalColor.withOpacity(0.15),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(8),
              topRight: Radius.circular(8),
            ),
            border: Border.all(
              color: medalColor.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                place == 1
                    ? Icons.emoji_events
                    : place == 2
                    ? Icons.military_tech
                    : Icons.grade,
                color: medalColor,
                size: 28,
              ),
              const SizedBox(height: 4),
              Container(
                width: 26,
                height: 26,
                decoration: BoxDecoration(
                  color: medalColor,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    place.toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLeaderboardTile(
      BuildContext context,
      LeaderboardEntry entry,
      bool isCurrentUser,
      AppLocalizations l10n,
      ThemeData theme,
      ColorScheme colorScheme,
      ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: isCurrentUser
            ? colorScheme.primary.withOpacity(0.1)
            : theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isCurrentUser ? colorScheme.primary : colorScheme.outline,
          width: isCurrentUser ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: _getRankColor(entry.rank, colorScheme).withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              entry.rank.toString(),
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: _getRankColor(entry.rank, colorScheme),
                fontSize: 16,
              ),
            ),
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                entry.displayName,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: isCurrentUser ? colorScheme.primary : colorScheme.onSurface,
                ),
              ),
            ),
            if (isCurrentUser)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: colorScheme.primary,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  l10n.you,
                  style: TextStyle(
                    color: colorScheme.onPrimary,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        subtitle: Row(
          children: [
            Icon(
              Icons.school,
              size: 14,
              color: colorScheme.onSurface.withOpacity(0.6),
            ),
            const SizedBox(width: 4),
            Text(
              '${l10n.level} ${entry.currentLevel}',
              style: TextStyle(
                fontSize: 12,
                color: colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
            const SizedBox(width: 12),
            Icon(
              Icons.book,
              size: 14,
              color: colorScheme.onSurface.withOpacity(0.6),
            ),
            const SizedBox(width: 4),
            Text(
              '${entry.distinctUnitsCount} ${l10n.units}',
              style: TextStyle(
                fontSize: 12,
                color: colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.star,
                  color: colorScheme.tertiary,
                  size: 20,
                ),
                const SizedBox(width: 4),
                Text(
                  entry.totalPoints.toString(),
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: colorScheme.onSurface,
                  ),
                ),
              ],
            ),
            Text(
              l10n.points,
              style: TextStyle(
                fontSize: 11,
                color: colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getRankColor(int rank, ColorScheme colorScheme) {
    if (rank == 1) return colorScheme.tertiary;
    if (rank == 2) return colorScheme.outline;
    if (rank == 3) return Colors.brown;
    if (rank <= 10) return colorScheme.secondary;
    return colorScheme.primary;
  }
}