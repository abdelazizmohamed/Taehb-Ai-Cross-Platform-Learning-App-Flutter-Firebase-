import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:taehb/data/models/question.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:taehb/l10n/app_localizations.dart';
import 'package:taehb/data/repositories/exam_repository.dart';

class ResultsPage extends StatefulWidget {
  final List<Question> questions;
  final String knowledgeUnit;
  final String? sessionId;

  const ResultsPage({
    super.key,
    required this.questions,
    required this.knowledgeUnit,
    this.sessionId,
  });

  @override
  State<ResultsPage> createState() => _ResultsPageState();
}

class _ResultsPageState extends State<ResultsPage> with SingleTickerProviderStateMixin {
  bool _isLoadingRecommendations = true;
  bool _isSavingResults = false;
  Map<String, dynamic>? _analysisResults;
  String? _errorMessage;

  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _analyzeResults();
    _saveResults();
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.elasticOut,
      ),
    );

    _animationController.forward();
  }

  Future<void> _saveResults() async {
    setState(() => _isSavingResults = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final examRepo = ExamRepository();
        await examRepo.saveExamResult(
          userId: user.uid,
          selectedKU: widget.knowledgeUnit,
          questions: widget.questions,
        );
        print('✅ Exam results saved successfully');
      }
    } catch (e) {
      print('❌ Error saving exam results: $e');
    } finally {
      setState(() => _isSavingResults = false);
    }
  }

  Future<void> _analyzeResults() async {
    try {
      // تحضير نتائج الأسئلة مع ربط LO
      final questionResults = widget.questions.map((q) {
        return {
          'question_number': q.questionNumber ?? 0,
          'lo': q.learningOutcome ?? 'LO.1',
          'correct': q.isCorrect ?? false,
        };
      }).toList();

      final response = await http.post(
        Uri.parse('http://10.0.2.2:5000/analyze_results'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'knowledge_unit': widget.knowledgeUnit,
          'question_results': questionResults,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _analysisResults = data;
          _isLoadingRecommendations = false;
        });
      } else {
        setState(() {
          _errorMessage = 'Failed to analyze results';
          _isLoadingRecommendations = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error connecting to server';
        _isLoadingRecommendations = false;
      });
    }
  }

  int get correctAnswers => widget.questions.where((q) => q.isCorrect == true).length;
  int get wrongAnswers => widget.questions.where((q) => q.isCorrect == false && q.selectedAnswer != null).length;
  int get unanswered => widget.questions.where((q) => q.selectedAnswer == null).length;
  int get totalQuestions => widget.questions.length;
  double get scorePercentage => (correctAnswers / totalQuestions * 100);

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: AppBar(
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        title: Text(l10n.examResults),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Knowledge Unit Badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: colorScheme.primary),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.school, color: colorScheme.primary, size: 20),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      widget.knowledgeUnit,
                      style: TextStyle(
                        color: colorScheme.primary,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Score Card with Animation
            AnimatedBuilder(
              animation: _scaleAnimation,
              builder: (context, child) {
                return Transform.scale(
                  scale: _scaleAnimation.value,
                  child: _buildScoreCard(l10n, colorScheme),
                );
              },
            ),

            const SizedBox(height: 24),

            // Statistics Cards
            _buildStatisticsCards(l10n, colorScheme),

            const SizedBox(height: 24),

            // Learning Outcomes Performance
            if (_isLoadingRecommendations)
              Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      CircularProgressIndicator(color: colorScheme.primary),
                      const SizedBox(height: 16),
                      Text(
                        'Analyzing your performance...',
                        style: TextStyle(color: colorScheme.onSurface),
                      ),
                    ],
                  ),
                ),
              )
            else if (_analysisResults != null)
              _buildLearningOutcomesCard(l10n, colorScheme)
            else if (_errorMessage != null)
                Card(
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      _errorMessage!,
                      style: TextStyle(color: colorScheme.error),
                    ),
                  ),
                ),

            const SizedBox(height: 24),

            // Recommendations Card
            if (_analysisResults != null)
              _buildRecommendationsCard(l10n, colorScheme),

            const SizedBox(height: 24),

            // Questions Review
            _buildQuestionsReview(l10n, theme, colorScheme),

            const SizedBox(height: 24),

            // Action Buttons
            _buildActionButtons(l10n, colorScheme),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreCard(AppLocalizations l10n, ColorScheme colorScheme) {
    final percentage = scorePercentage.round();
    Color scoreColor;
    IconData scoreIcon;
    String scoreMessage;

    if (percentage >= 90) {
      scoreColor = colorScheme.secondary;
      scoreIcon = Icons.emoji_events;
      scoreMessage = l10n.excellent;
    } else if (percentage >= 70) {
      scoreColor = colorScheme.primary;
      scoreIcon = Icons.thumb_up;
      scoreMessage = l10n.good;
    } else if (percentage >= 50) {
      scoreColor = colorScheme.tertiary;
      scoreIcon = Icons.sentiment_satisfied;
      scoreMessage = l10n.passable;
    } else {
      scoreColor = colorScheme.error;
      scoreIcon = Icons.sentiment_dissatisfied;
      scoreMessage = l10n.needsImprovement;
    }

    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [scoreColor, scoreColor.withOpacity(0.7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          children: [
            Icon(scoreIcon, color: Colors.white, size: 64),
            const SizedBox(height: 16),
            Text(
              scoreMessage,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '$percentage%',
              style: const TextStyle(
                fontSize: 56,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            Text(
              '${l10n.score}: $correctAnswers/$totalQuestions',
              style: const TextStyle(
                fontSize: 20,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatisticsCards(AppLocalizations l10n, ColorScheme colorScheme) {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            icon: Icons.check_circle,
            label: l10n.correct,
            value: correctAnswers.toString(),
            color: colorScheme.secondary,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildStatCard(
            icon: Icons.cancel,
            label: l10n.wrong,
            value: wrongAnswers.toString(),
            color: colorScheme.error,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildStatCard(
            icon: Icons.help_outline,
            label: l10n.unanswered,
            value: unanswered.toString(),
            color: colorScheme.tertiary,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLearningOutcomesCard(AppLocalizations l10n, ColorScheme colorScheme) {
    final loPerformance = _analysisResults!['lo_performance'] as Map<String, dynamic>;
    final overallAchieved = _analysisResults!['overall_achieved'] as bool;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  overallAchieved ? Icons.verified : Icons.school,
                  color: overallAchieved ? colorScheme.secondary : colorScheme.primary,
                  size: 28,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Learning Outcomes Achievement',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: colorScheme.onSurface,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            ...loPerformance.entries.map((entry) {
              final loId = entry.key;
              final loData = entry.value as Map<String, dynamic>;
              final achieved = loData['achieved'] as bool;
              final percentage = loData['percentage'] as double;
              final text = loData['text'] as String;

              return Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: achieved ? colorScheme.secondary.withOpacity(0.1) : colorScheme.error.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            loId,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: achieved ? colorScheme.secondary : colorScheme.error,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Icon(
                          achieved ? Icons.check_circle : Icons.cancel,
                          color: achieved ? colorScheme.secondary : colorScheme.error,
                          size: 20,
                        ),
                        const Spacer(),
                        Text(
                          '${percentage.toStringAsFixed(0)}%',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: achieved ? colorScheme.secondary : colorScheme.error,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      text,
                      style: TextStyle(
                        fontSize: 13,
                        color: colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: percentage / 100,
                        backgroundColor: colorScheme.surfaceVariant,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          achieved ? colorScheme.secondary : colorScheme.error,
                        ),
                        minHeight: 8,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildRecommendationsCard(AppLocalizations l10n, ColorScheme colorScheme) {
    final recommendations = _analysisResults!['recommendations'] as String;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              colorScheme.tertiary.withOpacity(0.1),
              colorScheme.primary.withOpacity(0.05),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.lightbulb, color: colorScheme.tertiary, size: 28),
                const SizedBox(width: 12),
                Text(
                  'Recommendations',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: colorScheme.onSurface,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              recommendations,
              style: TextStyle(
                fontSize: 15,
                height: 1.6,
                color: colorScheme.onSurface.withOpacity(0.8),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionsReview(AppLocalizations l10n, ThemeData theme, ColorScheme colorScheme) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              l10n.questionsReview,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 16),
            ...widget.questions.asMap().entries.map((entry) {
              final index = entry.key;
              final question = entry.value;

              Color statusColor;
              IconData statusIcon;

              if (question.selectedAnswer == null) {
                statusColor = colorScheme.tertiary;
                statusIcon = Icons.help_outline;
              } else if (question.isCorrect == true) {
                statusColor = colorScheme.secondary;
                statusIcon = Icons.check_circle;
              } else {
                statusColor = colorScheme.error;
                statusIcon = Icons.cancel;
              }

              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: statusColor.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: statusColor,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            '${index + 1}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              question.questionText.length > 50
                                  ? '${question.questionText.substring(0, 50)}...'
                                  : question.questionText,
                              style: TextStyle(
                                fontSize: 14,
                                color: colorScheme.onSurface,
                              ),
                            ),
                            if (question.learningOutcome != null)
                              Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: Text(
                                  'Tests: ${question.learningOutcome}',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: colorScheme.onSurface.withOpacity(0.5),
                                    fontStyle: FontStyle.italic,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                      Icon(statusIcon, color: statusColor, size: 24),
                    ],
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButtons(AppLocalizations l10n, ColorScheme colorScheme) {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
            icon: const Icon(Icons.home),
            label: Text(l10n.backToHome),
            style: ElevatedButton.styleFrom(
              backgroundColor: colorScheme.primary,
              foregroundColor: colorScheme.onPrimary,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () {
              Navigator.pushNamed(context, '/exam_history');
            },
            icon: Icon(Icons.history, color: colorScheme.primary),
            label: Text(l10n.viewHistory),
            style: OutlinedButton.styleFrom(
              foregroundColor: colorScheme.primary,
              side: BorderSide(color: colorScheme.primary),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }
}