import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:taehb/data/models/question.dart';
import 'package:taehb/screens/exam_screen.dart';
import 'package:taehb/l10n/app_localizations.dart';

class ExamConfirmationPage extends StatefulWidget {
  final String selectedKU; // وحدة معرفية واحدة
  final Map<String, String> kuKeys;

  const ExamConfirmationPage({
    super.key,
    required this.selectedKU,
    required this.kuKeys,
  });

  @override
  State<ExamConfirmationPage> createState() => _ExamConfirmationPageState();
}

class _ExamConfirmationPageState extends State<ExamConfirmationPage> {
  bool _agreedToTerms = false;
  bool _isReady = false;
  bool _isGenerating = false;
  List<Question>? _generatedQuestions;
  String? _errorMessage;
  Map<String, dynamic>? _learningOutcomes;

  @override
  void initState() {
    super.initState();
    _startGeneratingQuestions();
  }

  Future<void> _startGeneratingQuestions() async {
    setState(() {
      _isGenerating = true;
      _errorMessage = null;
    });

    try {
      final selectedEnglishName = widget.kuKeys[widget.selectedKU]!;

      final response = await http.post(
        Uri.parse('http://10.0.2.2:5000/generate_questions'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'selected_ku': selectedEnglishName,
          'n_questions': 15,
        }),
      ).timeout(const Duration(seconds: 60));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final questionsText = data['questions'] ?? '';
        _learningOutcomes = data['learning_outcomes'];

        final questions = _parseQuestions(questionsText);

        if (questions.isNotEmpty) {
          setState(() {
            _generatedQuestions = questions;
            _isGenerating = false;
          });
        } else {
          final l10n = AppLocalizations.of(context)!;
          setState(() {
            _errorMessage = l10n.questionsNotRecognized;
            _isGenerating = false;
          });
        }
      } else {
        final l10n = AppLocalizations.of(context)!;
        setState(() {
          _errorMessage = l10n.serverConnectionFailed;
          _isGenerating = false;
        });
      }
    } catch (e) {
      final l10n = AppLocalizations.of(context)!;
      setState(() {
        _errorMessage = l10n.unableToConnectServer;
        _isGenerating = false;
      });
    }
  }

  List<Question> _parseQuestions(String response) {
    final List<Question> questions = [];
    final lines = response.split('\n');

    String? currentQuestion;
    String? currentLO;
    List<String> currentOptions = [];
    String? currentAnswer;
    int questionNumber = 0;

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i].trim();

      // فحص رقم السؤال
      if (RegExp(r'^\d+[\.\)]\s*').hasMatch(line) && !line.toLowerCase().contains('answer')) {
        if (currentQuestion != null && currentOptions.isNotEmpty && currentAnswer != null) {
          questionNumber++;

          // إيجاد الفهرس الصحيح للإجابة
          int correctIndex = 0;
          for (int j = 0; j < currentOptions.length; j++) {
            if (currentOptions[j].trim().toLowerCase().contains(currentAnswer.trim().toLowerCase()) ||
                currentAnswer.trim().toLowerCase().contains(currentOptions[j].replaceFirst(RegExp(r'^[A-D][\)\.]'), '').trim().toLowerCase())) {
              correctIndex = j;
              break;
            }
          }

          questions.add(Question(
            id: 'q_$questionNumber',
            unitId: widget.selectedKU,
            questionText: currentQuestion,
            options: List.from(currentOptions),
            correctAnswerIndex: correctIndex,
            learningOutcome: currentLO,
            questionNumber: questionNumber,
            pointValue: 10,
            difficulty: 3,
          ));
        }

        currentQuestion = line.replaceFirst(RegExp(r'^\d+[\.\)]\s*'), '').trim();
        currentOptions = [];
        currentAnswer = null;
        currentLO = null;
      }
      // فحص وسم Learning Outcome: [Tests: LO.X]
      else if (line.contains('[Tests:') || line.contains('[Tests :')) {
        final loMatch = RegExp(r'\[Tests:\s*(LO\.\d+)\]', caseSensitive: false).firstMatch(line);
        if (loMatch != null) {
          currentLO = loMatch.group(1);
        }
      }
      // فحص الخيار
      else if (RegExp(r'^[A-D][\)\.]').hasMatch(line)) {
        currentOptions.add(line);
      }
      // فحص الإجابة
      else if (line.toLowerCase().contains('answer:')) {
        currentAnswer = line.replaceFirst(RegExp(r'answer:\s*', caseSensitive: false), '').trim();
      }
      // استمرار نص السؤال
      else if (currentQuestion != null && currentOptions.isEmpty && line.isNotEmpty && !line.startsWith('[')) {
        currentQuestion += ' $line';
      }
    }

    // لا تنسَ السؤال الأخير
    if (currentQuestion != null && currentOptions.isNotEmpty && currentAnswer != null) {
      questionNumber++;

      int correctIndex = 0;
      for (int j = 0; j < currentOptions.length; j++) {
        if (currentOptions[j].trim().toLowerCase().contains(currentAnswer.trim().toLowerCase()) ||
            currentAnswer.trim().toLowerCase().contains(currentOptions[j].replaceFirst(RegExp(r'^[A-D][\)\.]'), '').trim().toLowerCase())) {
          correctIndex = j;
          break;
        }
      }

      questions.add(Question(
        id: 'q_$questionNumber',
        unitId: widget.selectedKU,
        questionText: currentQuestion,
        options: List.from(currentOptions),
        correctAnswerIndex: correctIndex,
        learningOutcome: currentLO,
        questionNumber: questionNumber,
        pointValue: 10,
        difficulty: 3,
      ));
    }

    return questions;
  }

  void _startExam() {
    final l10n = AppLocalizations.of(context)!;

    if (!_agreedToTerms || !_isReady) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.error_outline, color: Colors.white),
              const SizedBox(width: 12),
              Expanded(child: Text(l10n.agreeAndConfirm)),
            ],
          ),
          backgroundColor: Theme.of(context).colorScheme.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
      return;
    }

    if (_generatedQuestions != null) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ExamScreen(
            questions: _generatedQuestions!,
            knowledgeUnit: widget.kuKeys[widget.selectedKU]!,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.error_outline, color: Colors.white),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _errorMessage ?? l10n.unableToConnectServer,
                ),
              ),
            ],
          ),
          backgroundColor: Theme.of(context).colorScheme.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          action: SnackBarAction(
            label: l10n.retry ?? 'Retry',
            textColor: Colors.white,
            onPressed: _startGeneratingQuestions,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: AppBar(
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        title: Text(
          l10n.confirmExamStart,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // عرض الوحدة المعرفية
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: colorScheme.primary, width: 2),
              ),
              child: Row(
                children: [
                  Icon(Icons.school, color: colorScheme.primary, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Knowledge Unit',
                          style: TextStyle(
                            fontSize: 12,
                            color: colorScheme.onSurface.withOpacity(0.6),
                          ),
                        ),
                        Text(
                          widget.kuKeys[widget.selectedKU]!,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: colorScheme.primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // حالة توليد الأسئلة
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _generatedQuestions != null
                    ? colorScheme.secondary.withOpacity(0.1)
                    : _errorMessage != null
                    ? colorScheme.error.withOpacity(0.1)
                    : colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _generatedQuestions != null
                      ? colorScheme.secondary
                      : _errorMessage != null
                      ? colorScheme.error
                      : colorScheme.primary,
                  width: 2,
                ),
              ),
              child: Row(
                children: [
                  if (_isGenerating)
                    SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        color: colorScheme.primary,
                      ),
                    )
                  else
                    Icon(
                      _generatedQuestions != null
                          ? Icons.check_circle
                          : Icons.error_outline,
                      color: _generatedQuestions != null
                          ? colorScheme.secondary
                          : colorScheme.error,
                      size: 28,
                    ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _generatedQuestions != null
                          ? l10n.questionsReady
                          : _errorMessage != null
                          ? l10n.errorOccurred(_errorMessage!)
                          : l10n.preparingQuestions,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: _generatedQuestions != null
                            ? colorScheme.secondary
                            : _errorMessage != null
                            ? colorScheme.error
                            : colorScheme.primary,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // معلومات الاختبار
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: theme.cardColor,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: colorScheme.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          Icons.info_outline,
                          color: colorScheme.primary,
                          size: 28,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        l10n.examInfo,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: colorScheme.onSurface,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _buildInfoRow(Icons.quiz, l10n.numberOfQuestions, l10n.questionsCount(15), colorScheme),
                  const SizedBox(height: 12),
                  _buildInfoRow(Icons.access_time, l10n.expectedTime, l10n.estimatedMinutes(20), colorScheme),
                  const SizedBox(height: 12),
                  _buildInfoRow(Icons.track_changes, 'Learning Outcomes', '${_learningOutcomes?.length ?? 0} outcomes', colorScheme),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ملاحظات مهمة
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: theme.cardColor,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: colorScheme.tertiary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          Icons.warning_amber_rounded,
                          color: colorScheme.tertiary,
                          size: 28,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        l10n.importantNotices,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: colorScheme.onSurface,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _buildWarningItem(l10n.multipleChoiceOnly, colorScheme),
                  _buildWarningItem(l10n.answerAllQuestions, colorScheme),
                  _buildWarningItem('Each question tests a specific Learning Outcome', colorScheme),
                  _buildWarningItem('You will receive personalized recommendations after the exam', colorScheme),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Checkbox 1: الموافقة على الشروط
            Material(
              color: theme.cardColor,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                onTap: () => setState(() => _agreedToTerms = !_agreedToTerms),
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _agreedToTerms ? colorScheme.primary : colorScheme.outline,
                      width: 2,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        _agreedToTerms ? Icons.check_box : Icons.check_box_outline_blank,
                        color: _agreedToTerms ? colorScheme.primary : colorScheme.outline,
                        size: 28,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          l10n.agreeMultipleChoice,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurface,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Checkbox 2: الجاهزية للبدء
            Material(
              color: theme.cardColor,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                onTap: () => setState(() => _isReady = !_isReady),
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _isReady ? colorScheme.primary : colorScheme.outline,
                      width: 2,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        _isReady ? Icons.check_box : Icons.check_box_outline_blank,
                        color: _isReady ? colorScheme.primary : colorScheme.outline,
                        size: 28,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          l10n.readyToStart,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurface,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 32),

            // زر بدء الاختبار
            ElevatedButton(
              onPressed: (_agreedToTerms && _isReady && _generatedQuestions != null) ? _startExam : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: colorScheme.primary,
                foregroundColor: colorScheme.onPrimary,
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 8,
                disabledBackgroundColor: colorScheme.surfaceVariant,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.play_arrow_rounded, size: 28),
                  const SizedBox(width: 8),
                  Text(
                    l10n.startExam,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value, ColorScheme colorScheme) {
    return Row(
      children: [
        Icon(icon, color: colorScheme.primary, size: 20),
        const SizedBox(width: 12),
        Text(
          '$label: ',
          style: TextStyle(
            fontSize: 15,
            color: colorScheme.onSurface.withOpacity(0.7),
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: colorScheme.onSurface,
          ),
        ),
      ],
    );
  }

  Widget _buildWarningItem(String text, ColorScheme colorScheme) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 4),
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: colorScheme.tertiary,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 15,
                height: 1.5,
                color: colorScheme.onSurface.withOpacity(0.8),
              ),
            ),
          ),
        ],
      ),
    );
  }
}