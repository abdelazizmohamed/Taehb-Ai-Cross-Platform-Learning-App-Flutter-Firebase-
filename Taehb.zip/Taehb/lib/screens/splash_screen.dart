import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:lottie/lottie.dart';
import 'dart:math' as math;
import '../auth/bloc/auth_bloc.dart';
import '../auth/bloc/auth_event.dart';
import '../auth/bloc/auth_state.dart';
import '../core/constants/colors.dart';
import '../core/constants/strings.dart';
import '../core/utils/navigation.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {

  // Animation Controllers
  late AnimationController _mainController;
  late AnimationController _logoController;
  late AnimationController _textController;
  late AnimationController _backgroundController;
  late AnimationController _pulseController;

  // Animations
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _logoScaleAnimation;
  late Animation<double> _logoRotationAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _textOpacityAnimation;
  late Animation<double> _backgroundAnimation;
  late Animation<double> _pulseAnimation;

  bool _animationsCompleted = false;
  bool _authCheckStarted = false;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startAnimationSequence();
  }

  void _initializeAnimations() {
    _mainController = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    );

    // Logo animation controller
    _logoController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _textController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _backgroundController = AnimationController(
      duration: const Duration(milliseconds: 4000),
      vsync: this,
    );

    // Pulse animation controller (continuous)
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _setupAnimations();
  }

  void _setupAnimations() {
    // Main fade and scale animations
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _mainController,
      curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
    ));

    _scaleAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _mainController,
      curve: const Interval(0.0, 0.8, curve: Curves.elasticOut),
    ));

    // Logo specific animations
    _logoScaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoController,
      curve: Curves.bounceOut,
    ));

    _logoRotationAnimation = Tween<double>(
      begin: 0.0,
      end: 2 * math.pi,
    ).animate(CurvedAnimation(
      parent: _logoController,
      curve: const Interval(0.5, 1.0, curve: Curves.easeInOut),
    ));

    // Text animations
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _textController,
      curve: Curves.easeOutBack,
    ));

    _textOpacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _textController,
      curve: const Interval(0.3, 1.0, curve: Curves.easeIn),
    ));

    // Background gradient animation
    _backgroundAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _backgroundController,
      curve: Curves.easeInOut,
    ));

    // Continuous pulse animation
    _pulseAnimation = Tween<double>(
      begin: 0.95,
      end: 1.05,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));
  }

  /// Start the animation sequence
  void _startAnimationSequence() async {
    // Start background animation immediately
    _backgroundController.forward();

    // Small delay then start main animations
    await Future.delayed(const Duration(milliseconds: 300));
    _mainController.forward();

    // Start logo animation
    await Future.delayed(const Duration(milliseconds: 500));
    _logoController.forward();

    // Start text animation
    await Future.delayed(const Duration(milliseconds: 800));
    _textController.forward();

    // Start continuous pulse animation
    await Future.delayed(const Duration(milliseconds: 1200));
    _pulseController.repeat(reverse: true);

    // Mark animations as completed and start auth check
    await Future.delayed(const Duration(milliseconds: 2500));
    if (mounted) {
      setState(() {
        _animationsCompleted = true;
      });
      _startAuthenticationCheck();
    }
  }

  /// Start authentication status check
  /// ✅ التعديل الرئيسي هنا
  void _startAuthenticationCheck() {
    if (!_authCheckStarted && mounted) {
      _authCheckStarted = true;
      print('🔍 SplashScreen - Starting auth check...');

      // إرسال event لفحص حالة الـ authentication
      context.read<AuthBloc>().add(const CheckAuthStatus());
    }
  }

  @override
  void dispose() {
    _mainController.dispose();
    _logoController.dispose();
    _textController.dispose();
    _backgroundController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        print('🎯 SplashScreen - Auth state changed: ${state.runtimeType}');
        print('🎯 Animations completed: $_animationsCompleted');

        if (_animationsCompleted) {
          if (state is AuthAuthenticated) {
            print('✅ User authenticated, navigating to home...');
            _navigateToHome(state.user);
          } else if (state is AuthUnauthenticated) {
            print('❌ User not authenticated, navigating to login...');
            _navigateToLogin();
          } else if (state is AuthError) {
            print('❌ Auth error: ${state.message}');
            _navigateToLogin();
          }
        }
      },
      child: Scaffold(
        backgroundColor: theme.colorScheme.surface,
        body: AnimatedBuilder(
          animation: Listenable.merge([
            _backgroundController,
            _mainController,
            _logoController,
            _textController,
            _pulseController,
          ]),
          builder: (context, child) {
            return Container(
              width: size.width,
              height: size.height,
              decoration: _buildBackgroundDecoration(),
              child: SafeArea(
                child: Column(
                  children: [
                    // Top spacer
                    const Spacer(flex: 2),

                    // Main content
                    _buildMainContent(theme, isRTL),

                    // Bottom section
                    const Spacer(flex: 2),
                    _buildBottomSection(theme),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  /// Build animated background decoration
  BoxDecoration _buildBackgroundDecoration() {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        stops: [
          0.0,
          0.3 + (_backgroundAnimation.value * 0.2),
          0.7 + (_backgroundAnimation.value * 0.3),
          1.0,
        ],
        colors: [
          AppColors.primary.withOpacity(0.1 + _backgroundAnimation.value * 0.05),
          AppColors.secondary.withOpacity(0.08 + _backgroundAnimation.value * 0.04),
          AppColors.accent.withOpacity(0.06 + _backgroundAnimation.value * 0.03),
          Colors.transparent,
        ],
      ),
    );
  }

  /// Build main content with logo and text
  Widget _buildMainContent(ThemeData theme, bool isRTL) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Logo section
            _buildLogoSection(),

            const SizedBox(height: 32),

            // App name and slogan
            _buildTextSection(theme, isRTL),
          ],
        ),
      ),
    );
  }

  /// Build animated logo section
  Widget _buildLogoSection() {
    return ScaleTransition(
      scale: _logoScaleAnimation,
      child: Transform.scale(
        scale: _pulseAnimation.value,
        child: Transform.rotate(
          angle: _logoRotationAnimation.value * 0.1, // Subtle rotation
          child: Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.3 * _logoScaleAnimation.value),
                  blurRadius: 30 * _logoScaleAnimation.value,
                  spreadRadius: 5 * _logoScaleAnimation.value,
                ),
                BoxShadow(
                  color: AppColors.accent.withOpacity(0.2 * _logoScaleAnimation.value),
                  blurRadius: 20 * _logoScaleAnimation.value,
                  spreadRadius: 2 * _logoScaleAnimation.value,
                ),
              ],
            ),
            child: _buildLottieOrFallback(),
          ),
        ),
      ),
    );
  }

  /// Build Lottie animation or fallback
  Widget _buildLottieOrFallback() {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Background circle
        Container(
          width: 180,
          height: 180,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppColors.primary.withOpacity(0.9),
                AppColors.accent.withOpacity(0.8),
              ],
            ),
          ),
        ),

        // Lottie animation or fallback
        SizedBox(
          width: 140,
          height: 140,
          child: _buildEducationAnimation(),
        ),
      ],
    );
  }

  /// Build educational animation (Lottie with fallback)
  Widget _buildEducationAnimation() {
    return FutureBuilder<bool>(
      future: _checkLottieAsset(),
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data == true) {
          // Lottie animation available
          return Lottie.asset(
            'assets/animations/splash_animation.json',
            width: 140,
            height: 140,
            fit: BoxFit.contain,
            repeat: true,
            animate: true,
            errorBuilder: (context, error, stackTrace) => _buildFallbackIcon(),
          );
        } else {
          return _buildFallbackIcon();
        }
      },
    );
  }

  /// Check if Lottie asset exists
  Future<bool> _checkLottieAsset() async {
    try {
      return true;
    } catch (e) {
      return false;
    }
  }

  Widget _buildFallbackIcon() {
    return AnimatedBuilder(
      animation: _logoController,
      builder: (context, child) {
        return Transform.rotate(
          angle: _logoController.value * 0.5,
          child: Container(
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
            ),
            child: const Icon(
              Icons.school_rounded,
              size: 70,
              color: AppColors.primary,
            ),
          ),
        );
      },
    );
  }

  Widget _buildTextSection(ThemeData theme, bool isRTL) {
    return SlideTransition(
      position: _slideAnimation,
      child: FadeTransition(
        opacity: _textOpacityAnimation,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            children: [
              // App name in Arabic
              Text(
                AppStrings.appNameArabic,
                style: theme.textTheme.displayLarge?.copyWith(
                  fontWeight: FontWeight.w900,
                  color: AppColors.primary,
                  letterSpacing: 3,
                  shadows: [
                    Shadow(
                      color: AppColors.primary.withOpacity(0.3),
                      offset: const Offset(0, 2),
                      blurRadius: 4,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 8),

              // App name in English
              Text(
                AppStrings.appName,
                style: theme.textTheme.titleLarge?.copyWith(
                  color: AppColors.textSecondary,
                  letterSpacing: 8,
                  fontWeight: FontWeight.w300,
                ),
              ),

              const SizedBox(height: 24),

              // Animated divider
              Container(
                width: 100 * _textOpacityAnimation.value,
                height: 2,
                decoration: BoxDecoration(
                  gradient: AppColors.primaryGradient,
                  borderRadius: BorderRadius.circular(1),
                ),
              ),

              const SizedBox(height: 24),

              Text(
                isRTL ? AppStrings.appSlogan : AppStrings.appSloganEnglish,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: AppColors.textSecondary,
                  height: 1.6,
                  fontStyle: FontStyle.italic,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomSection(ThemeData theme) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Loading indicator
          BlocBuilder<AuthBloc, AuthState>(
            builder: (context, state) {
              return AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: _buildLoadingIndicator(state),
              );
            },
          ),

          const SizedBox(height: 24),

          _buildVersionInfo(theme),

          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildLoadingIndicator(AuthState state) {
    if (state is AuthLoading || !_animationsCompleted) {
      return Column(
        key: const ValueKey('loading'),
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(AppColors.primary),
            strokeWidth: 3,
          ),
          const SizedBox(height: 12),
          Text(
            'تحميل... Loading...',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppColors.textHint,
            ),
          ),
        ],
      );
    } else {
      return const SizedBox.shrink(key: ValueKey('empty'));
    }
  }

  Widget _buildVersionInfo(ThemeData theme) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          'Version ${AppStrings.appVersion}',
          style: theme.textTheme.bodySmall?.copyWith(
            color: AppColors.textHint,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '© 2024 Taehb Educational Solutions',
          style: theme.textTheme.bodySmall?.copyWith(
            color: AppColors.textHint.withOpacity(0.7),
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  /// Navigate to home screen with smooth transition
  void _navigateToHome(dynamic userData) {
    if (mounted) {
      NavigationHelper.navigateAndRemoveUntil(
        AppStrings.homeRoute,
        arguments: {'userData': userData},
      );
    }
  }

  void _navigateToLogin() {
    if (mounted) {
      NavigationHelper.navigateAndRemoveUntil(AppStrings.loginRoute);
    }
  }
}