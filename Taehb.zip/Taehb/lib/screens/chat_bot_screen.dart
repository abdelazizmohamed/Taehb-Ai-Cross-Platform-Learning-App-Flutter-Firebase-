import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:taehb/l10n/app_localizations.dart';
import '../services/groq_chat_service.dart';

class ChatBotScreen extends StatefulWidget {
  const ChatBotScreen({Key? key}) : super(key: key);

  @override
  State<ChatBotScreen> createState() => _ChatBotScreenState();
}

class _ChatBotScreenState extends State<ChatBotScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final GroqChatService _chatService = GroqChatService();

  final List<ChatMessage> _messages = [];
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final l10n = AppLocalizations.of(context)!;
      _addMessage(
        text: l10n.welcomeMessage,
        isUser: false,
        timestamp: DateTime.now(),
      );
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _addMessage({
    required String text,
    required bool isUser,
    required DateTime timestamp,
  }) {
    setState(() {
      _messages.add(ChatMessage(
        text: text,
        isUser: isUser,
        timestamp: timestamp,
      ));
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _getCurrentLanguage() {
    return Localizations.localeOf(context).languageCode;
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    _addMessage(
      text: text,
      isUser: true,
      timestamp: DateTime.now(),
    );

    _messageController.clear();
    setState(() => _isTyping = true);

    try {
      final chatHistory = _messages
          .skip(_messages.length > 10 ? _messages.length - 10 : 0)
          .map((msg) => {
        'role': msg.isUser ? 'user' : 'assistant',
        'content': msg.text,
      })
          .toList();

      final response = await _chatService.sendMessage(
        message: text,
        chatHistory: chatHistory,
      );

      _addMessage(
        text: response,
        isUser: false,
        timestamp: DateTime.now(),
      );
    } catch (e) {
      final l10n = AppLocalizations.of(context)!;
      _addMessage(
        text: l10n.errorOccurre,
        isUser: false,
        timestamp: DateTime.now(),
      );
    } finally {
      setState(() => _isTyping = false);
    }
  }

  Widget _buildQuickActions(ColorScheme colorScheme) {
    final l10n = AppLocalizations.of(context)!;

    final actions = [
      _QuickAction(
        icon: Icons.school,
        label: l10n.topicSummary,
        onTap: () => _showSummaryDialog(),
      ),
      _QuickAction(
        icon: Icons.quiz,
        label: l10n.knowledgeUnits ?? 'الوحدات المعرفية',
        onTap: () => _showKnowledgeUnitsDialog(),
      ),
      _QuickAction(
        icon: Icons.map,
        label: l10n.howToNavigate,
        onTap: () => _showNavigationDialog(),
      ),
      _QuickAction(
        icon: Icons.help_outline,
        label: l10n.generalQuestion,
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
      ),
    ];

    return Container(
      height: 80,
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: actions.length,
        itemBuilder: (context, index) {
          final action = actions[index];
          return Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: action.onTap,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  width: 100,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [colorScheme.primary, colorScheme.primaryContainer],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: colorScheme.primary.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(action.icon, color: colorScheme.onPrimary, size: 24),
                      const SizedBox(height: 4),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Text(
                          action.label,
                          style: TextStyle(
                            color: colorScheme.onPrimary,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _showSummaryDialog() {
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: Text(
          l10n.studyTopicSummary,
          style: TextStyle(color: colorScheme.onSurface),
        ),
        content: TextField(
          controller: controller,
          decoration: InputDecoration(
            hintText: l10n.exampleTopic,
            border: OutlineInputBorder(
              borderSide: BorderSide(color: colorScheme.outline),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: colorScheme.primary, width: 2),
            ),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(l10n.cancel, style: TextStyle(color: colorScheme.primary)),
          ),
          ElevatedButton(
            onPressed: () async {
              final topic = controller.text.trim();
              if (topic.isEmpty) return;

              Navigator.pop(context);

              final l10nContext = AppLocalizations.of(context)!;
              _addMessage(
                text: l10nContext.iWantSummaryAbout(topic),
                isUser: true,
                timestamp: DateTime.now(),
              );

              setState(() => _isTyping = true);

              try {
                final language = _getCurrentLanguage();
                final summary = await _chatService.createSummary(topic, language);
                _addMessage(
                  text: summary,
                  isUser: false,
                  timestamp: DateTime.now(),
                );
              } catch (e) {
                _addMessage(
                  text: l10nContext.couldntCreateSummary,
                  isUser: false,
                  timestamp: DateTime.now(),
                );
              } finally {
                setState(() => _isTyping = false);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: colorScheme.primary,
              foregroundColor: colorScheme.onPrimary,
            ),
            child: Text(l10n.create),
          ),
        ],
      ),
    );
  }

  void _showKnowledgeUnitsDialog() async {
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;

    // عرض مؤشر التحميل
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(
        child: CircularProgressIndicator(color: colorScheme.primary),
      ),
    );

    try {
      // تحميل الوحدات المعرفية
      final kuData = await _chatService.loadKnowledgeUnits();

      // إغلاق مؤشر التحميل
      if (mounted) Navigator.pop(context);

      // عرض قائمة الوحدات المعرفية
      if (mounted) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: Theme.of(context).cardColor,
            title: Text(
              l10n.chooseKnowledgeUnit ?? 'اختر الوحدة المعرفية',
              style: TextStyle(color: colorScheme.onSurface),
            ),
            content: SizedBox(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: kuData.length,
                itemBuilder: (context, index) {
                  final unit = kuData.entries.elementAt(index);
                  final unitName = unit.key;
                  final topics = unit.value['Topics'] as List;

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    color: colorScheme.surface,
                    elevation: 2,
                    child: ExpansionTile(
                      leading: Icon(Icons.folder, color: colorScheme.primary),
                      title: Text(
                        unitName,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.onSurface,
                        ),
                      ),
                      children: topics.map<Widget>((topic) {
                        return ListTile(
                          leading: Icon(
                            Icons.article,
                            color: colorScheme.secondary,
                            size: 20,
                          ),
                          title: Text(
                            topic.toString(),
                            style: TextStyle(color: colorScheme.onSurface),
                          ),
                          onTap: () async {
                            Navigator.pop(context);
                            await _generateQuestionsForTopic(topic.toString());
                          },
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  l10n.cancel,
                  style: TextStyle(color: colorScheme.primary),
                ),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context); // إغلاق مؤشر التحميل
        _addMessage(
          text: l10n.errorLoadingKU ?? 'حدث خطأ في تحميل الوحدات المعرفية',
          isUser: false,
          timestamp: DateTime.now(),
        );
      }
    }
  }

  Future<void> _generateQuestionsForTopic(String topicName) async {
    final l10n = AppLocalizations.of(context)!;
    final language = _getCurrentLanguage();

    _addMessage(
      text: language == 'ar'
          ? 'أريد أسئلة عن موضوع: $topicName'
          : 'I want questions about: $topicName',
      isUser: true,
      timestamp: DateTime.now(),
    );

    setState(() => _isTyping = true);

    try {
      final questions = await _chatService.generateQuestionFromTopic(
        topicName,
        language,
      );

      _addMessage(
        text: questions,
        isUser: false,
        timestamp: DateTime.now(),
      );
    } catch (e) {
      _addMessage(
        text: language == 'ar'
            ? 'عذراً، حدث خطأ في توليد الأسئلة'
            : 'Sorry, an error occurred while generating questions',
        isUser: false,
        timestamp: DateTime.now(),
      );
    } finally {
      setState(() => _isTyping = false);
    }
  }

  void _showNavigationDialog() {
    final l10n = AppLocalizations.of(context)!;
    final colorScheme = Theme.of(context).colorScheme;

    final features = [
      l10n.featureTests,
      l10n.featureProfile,
      l10n.featureLeaderboard,
      l10n.featurePointsHistory,
      l10n.featureDailyReward,
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Theme.of(context).cardColor,
        title: Text(
          l10n.chooseFeature,
          style: TextStyle(color: colorScheme.onSurface),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: features.length,
            itemBuilder: (context, index) {
              final isRTL = Directionality.of(context) == TextDirection.rtl;
              return ListTile(
                leading: Icon(
                  Icons.arrow_forward_ios,
                  size: 16,
                  color: colorScheme.primary,
                  textDirection: isRTL ? TextDirection.rtl : TextDirection.ltr,
                ),
                title: Text(
                  features[index],
                  style: TextStyle(color: colorScheme.onSurface),
                ),
                onTap: () async {
                  Navigator.pop(context);

                  final l10nContext = AppLocalizations.of(context)!;
                  _addMessage(
                    text: l10nContext.howDoIAccess(features[index]),
                    isUser: true,
                    timestamp: DateTime.now(),
                  );

                  setState(() => _isTyping = true);

                  try {
                    final language = _getCurrentLanguage();
                    final help = await _chatService.getNavigationHelp(
                      features[index],
                      language,
                    );
                    _addMessage(
                      text: help,
                      isUser: false,
                      timestamp: DateTime.now(),
                    );
                  } catch (e) {
                    _addMessage(
                      text: l10nContext.couldntHelp,
                      isUser: false,
                      timestamp: DateTime.now(),
                    );
                  } finally {
                    setState(() => _isTyping = false);
                  }
                },
              );
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: AppBar(
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [colorScheme.primary, colorScheme.primaryContainer],
                ),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.smart_toy, size: 20, color: colorScheme.onPrimary),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  l10n.aiAssistant,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: colorScheme.onPrimary,
                  ),
                ),
                Text(
                  l10n.onlineNow,
                  style: TextStyle(
                    fontSize: 11,
                    color: colorScheme.onPrimary.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.delete_outline, color: colorScheme.onPrimary),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  backgroundColor: theme.cardColor,
                  title: Text(
                    l10n.clearChat,
                    style: TextStyle(color: colorScheme.onSurface),
                  ),
                  content: Text(
                    l10n.clearChatConfirm,
                    style: TextStyle(color: colorScheme.onSurface),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text(l10n.cancel, style: TextStyle(color: colorScheme.primary)),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        final l10nContext = AppLocalizations.of(context)!;
                        setState(() {
                          _messages.clear();
                          _addMessage(
                            text: l10nContext.helloAgain,
                            isUser: false,
                            timestamp: DateTime.now(),
                          );
                        });
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: colorScheme.error,
                        foregroundColor: colorScheme.onError,
                      ),
                      child: Text(l10n.clear),
                    ),
                  ],
                ),
              );
            },
            tooltip: l10n.clearChat,
          ),
        ],
      ),
      body: Column(
        children: [
          if (_messages.length <= 1) _buildQuickActions(colorScheme),

          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length + (_isTyping ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _messages.length && _isTyping) {
                  return _buildTypingIndicator(colorScheme);
                }
                return _buildMessageBubble(_messages[index], theme, colorScheme);
              },
            ),
          ),

          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: theme.cardColor,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    style: TextStyle(color: colorScheme.onSurface),
                    decoration: InputDecoration(
                      hintText: l10n.typeMessage,
                      hintStyle: TextStyle(color: colorScheme.onSurface.withOpacity(0.5)),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: colorScheme.surfaceVariant,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 12,
                      ),
                    ),
                    maxLines: null,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [colorScheme.primary, colorScheme.primaryContainer],
                    ),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: colorScheme.primary.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: IconButton(
                    icon: Icon(Icons.send, color: colorScheme.onPrimary),
                    onPressed: _isTyping ? null : _sendMessage,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message, ThemeData theme, ColorScheme colorScheme) {
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.75,
        ),
        child: Column(
          crossAxisAlignment: message.isUser
              ? CrossAxisAlignment.end
              : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: message.isUser
                    ? LinearGradient(
                  colors: [colorScheme.primary, colorScheme.primaryContainer],
                )
                    : null,
                color: message.isUser ? null : theme.cardColor,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 5,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: message.isUser
                  ? Text(
                message.text,
                style: TextStyle(color: colorScheme.onPrimary),
              )
                  : MarkdownBody(
                data: message.text,
                styleSheet: MarkdownStyleSheet(
                  p: TextStyle(fontSize: 14, color: colorScheme.onSurface),
                  h1: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: colorScheme.onSurface),
                  h2: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: colorScheme.onSurface),
                  h3: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: colorScheme.onSurface),
                  strong: TextStyle(fontWeight: FontWeight.bold, color: colorScheme.onSurface),
                  listBullet: TextStyle(color: colorScheme.primary),
                ),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              _formatTime(message.timestamp),
              style: TextStyle(
                fontSize: 10,
                color: colorScheme.onSurface.withOpacity(0.5),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypingIndicator(ColorScheme colorScheme) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildDot(0, colorScheme),
            const SizedBox(width: 4),
            _buildDot(1, colorScheme),
            const SizedBox(width: 4),
            _buildDot(2, colorScheme),
          ],
        ),
      ),
    );
  }

  Widget _buildDot(int index, ColorScheme colorScheme) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 600),
      builder: (context, value, child) {
        return Transform.translate(
          offset: Offset(0, -5 * (0.5 - (value - index * 0.2).abs())),
          child: Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: colorScheme.primary,
              shape: BoxShape.circle,
            ),
          ),
        );
      },
      onEnd: () {
        if (mounted) setState(() {});
      },
    );
  }

  String _formatTime(DateTime time) {
    final l10n = AppLocalizations.of(context)!;
    final now = DateTime.now();
    final diff = now.difference(time);

    if (diff.inMinutes < 1) return l10n.now;
    if (diff.inMinutes < 60) {
      return l10n.minutesAgo(diff.inMinutes);
    }
    if (diff.inHours < 24) {
      return l10n.hoursAgo(diff.inHours);
    }
    return '${time.hour}:${time.minute.toString().padLeft(2, '0')}';
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
  });
}

class _QuickAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  _QuickAction({
    required this.icon,
    required this.label,
    required this.onTap,
  });
}