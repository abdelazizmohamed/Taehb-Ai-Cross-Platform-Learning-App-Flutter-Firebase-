import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:taehb/l10n/app_localizations.dart';
import 'package:taehb/screens/chat_bot_screen.dart';
import 'package:taehb/screens/course_screen.dart';
import 'package:taehb/screens/leaderboard_screen.dart';
import 'package:taehb/screens/points_history_screen.dart';
import 'package:taehb/screens/profile_screen.dart';
import '../auth/bloc/auth_bloc.dart';
import '../auth/bloc/auth_state.dart';
import '../core/constants/colors.dart';
import '../core/utils/navigation.dart';
import 'package:taehb/services/daily_login_manager.dart';
import 'package:taehb/services/points_progress_service.dart';
import 'package:taehb/services/activity_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  int _currentIndex = 0;
  late AnimationController _animationController;
  late List<Animation<double>> _cardAnimations;

  int _userPoints = 0;
  int _userLevel = 0;
  int _userRank = 0;
  bool _isLoadingStats = true;
  List<ActivityItem> _recentActivities = [];
  bool _isLoadingActivities = true;

  final PointsProgressService _pointsService = PointsProgressService();
  final ActivityService _activityService = ActivityService();

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    WidgetsBinding.instance.addObserver(this);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkDailyLogin();
      _loadUserStats();
      _loadRecentActivities();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _animationController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      _loadUserStats();
      _loadRecentActivities();
    }
  }

  Future<void> _checkDailyLogin() async {
    await DailyLoginManager().checkDailyLogin(context);
    _loadUserStats();
    _loadRecentActivities();
  }

  /// تحميل إحصائيات المستخدم
  Future<void> _loadUserStats() async {
    try {
      final authBloc = context.read<AuthBloc>();
      final userId = authBloc.currentUser?.id;

      if (userId != null) {
        final stats = await _pointsService.getUserStats(userId);

        if (mounted) {
          setState(() {
            _userPoints = stats['totalPoints'] ?? 0;
            _userLevel = stats['currentLevel'] ?? 0;
            _userRank = stats['rank'] ?? 0;
            _isLoadingStats = false;
          });
        }
      }
    } catch (e) {
      print('Error loading user stats: $e');
      if (mounted) {
        setState(() {
          _isLoadingStats = false;
        });
      }
    }
  }

  /// تحميل النشاط الأخير
  Future<void> _loadRecentActivities() async {
    try {
      final authBloc = context.read<AuthBloc>();
      final userId = authBloc.currentUser?.id;

      if (userId != null) {
        final activities = await _activityService.getUserActivities(userId, limit: 5);

        if (mounted) {
          setState(() {
            _recentActivities = activities;
            _isLoadingActivities = false;
          });
        }
      }
    } catch (e) {
      print('Error loading activities: $e');
      if (mounted) {
        setState(() {
          _isLoadingActivities = false;
        });
      }
    }
  }

  Future<void> _refreshData() async {
    setState(() {
      _isLoadingStats = true;
      _isLoadingActivities = true;
    });
    await Future.wait([
      _loadUserStats(),
      _loadRecentActivities(),
    ]);
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _cardAnimations = List.generate(4, (index) {
      return Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: _animationController,
          curve: Interval(
            index * 0.1,
            0.4 + (index * 0.1),
            curve: Curves.easeOut,
          ),
        ),
      );
    });

    _animationController.forward();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is AuthUnauthenticated) {
          NavigationHelper.navigateAndRemoveUntil('/login');
        }
      },
      child: Scaffold(
        appBar: _buildAppBar(theme),
        body: IndexedStack(
          index: _currentIndex,
          children: [
            RefreshIndicator(
              onRefresh: _refreshData,
              child: _buildHomePage(theme),
            ),
            LeaderboardScreen(),
            ProfileScreen(),
          ],
        ),
        bottomNavigationBar: _buildBottomNavigation(theme),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(ThemeData theme) {
    final authBloc = context.read<AuthBloc>();
    final user = authBloc.currentUser;
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    return AppBar(
      title: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: AppColors.primaryGradient,
            ),
            child: const Icon(Icons.school_rounded, size: 18, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  isRTL ? 'مرحباً' : 'Welcome',
                  style: theme.textTheme.displayMedium?.copyWith(
                    color: Colors.white.withOpacity(0.9),
                  ),
                ),
                Text(
                  user?.name ?? 'Student',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 8),
          decoration: BoxDecoration(
            gradient: AppColors.primaryGradient,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: AppColors.accent.withOpacity(0.4),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: IconButton(
            key: const Key('chatbot_button'),
            icon: const Icon(Icons.smart_toy_outlined, size: 30),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ChatBotScreen(),
                ),
              );
            },
            tooltip: isRTL ? 'المساعد الذكي' : 'AI Assistant',
          ),
        ),

        // IconButton(
        //   key: const Key('notifications_button'),
        //   icon: Stack(
        //     children: [
        //       const Icon(Icons.notifications_outlined),
        //       Positioned(
        //         right: 0,
        //         top: 0,
        //         child: Container(
        //           width: 8,
        //           height: 8,
        //           decoration: BoxDecoration(
        //             color: AppColors.error,
        //             shape: BoxShape.circle,
        //             border: Border.all(color: Colors.white, width: 1.5),
        //           ),
        //         ),
        //       ),
        //     ],
        //   ),
        //   onPressed: () {
        //     // TODO: Navigate to notifications
        //   },
        //   tooltip: isRTL ? 'الإشعارات' : 'Notifications',
        // ),
      ],
    );
  }

  Widget _buildHomePage(ThemeData theme) {
    final authBloc = context.read<AuthBloc>();
    final user = authBloc.currentUser;
    final l10n = AppLocalizations.of(context)!;
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStatsCard(theme, user, isRTL),
          const SizedBox(height: 24),
          Text(
            l10n.quickAccess,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          _buildFourCardGrid(theme, isRTL),
          const SizedBox(height: 24),
          _buildRecentActivity(theme, isRTL),
        ],
      ),
    );
  }

  Widget _buildStatsCard(ThemeData theme, dynamic user, bool isRTL) {
    return Container(
      key: const Key('stats_card'),
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.2),
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: user?.profileImageUrl != null
                    ? ClipOval(
                  child: Image.network(
                    user!.profileImageUrl!,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                )
                    : const Icon(Icons.person, color: Colors.white, size: 30),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user?.name ?? 'Student',
                      style: theme.textTheme.titleLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      user?.email ?? '',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: Colors.white.withOpacity(0.9),
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          if (_isLoadingStats)
            const CircularProgressIndicator(color: Colors.white)
          else
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem(
                  icon: Icons.emoji_events,
                  label: isRTL ? 'النقاط' : 'Points',
                  value: _userPoints.toString(),
                  theme: theme,
                ),
                _buildStatDivider(),
                _buildStatItem(
                  icon: Icons.trending_up,
                  label: isRTL ? 'المستوى' : 'Level',
                  value: _userLevel.toString(),
                  theme: theme,
                ),
                _buildStatDivider(),
                _buildStatItem(
                  icon: Icons.stars,
                  label: isRTL ? 'الترتيب' : 'Rank',
                  value: '#$_userRank',
                  theme: theme,
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
    required ThemeData theme,
  }) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 24),
        const SizedBox(height: 4),
        Text(
          value,
          style: theme.textTheme.titleLarge?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: Colors.white.withOpacity(0.8),
          ),
        ),
      ],
    );
  }

  Widget _buildStatDivider() {
    return Container(
      width: 1,
      height: 40,
      color: Colors.white.withOpacity(0.3),
    );
  }

  Widget _buildFourCardGrid(ThemeData theme, bool isRTL) {
    final cards = [
      _HomeCardData(
        key: 'courses_card',
        title: isRTL ? 'الدورات' : 'Courses',
        subtitle: isRTL ? 'تصفح المواد' : 'Browse materials',
        icon: Icons.book_outlined,
        color: AppColors.primary,
        gradient: AppColors.primaryGradient,
        onTap: () async {
          // Navigate to Course Screen
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const CourseScreen(),
            ),
          );
          // Refresh data when returning
          _refreshData();
        },
      ),
      _HomeCardData(
        key: 'exam_card',
        title: isRTL ? 'الامتحان' : 'Exam',
        subtitle: isRTL ? 'ابدأ الاختبار' : 'Start test',
        icon: Icons.quiz_outlined,
        color: AppColors.secondary,
        gradient: AppColors.secondaryGradient,
        onTap: () async {
          await NavigationHelper.navigateTo('/ku_screen');
          _refreshData();
        },
      ),
      _HomeCardData(
        key: 'profile_card',
        title: isRTL ? 'الملف الشخصي' : 'Profile',
        subtitle: isRTL ? 'عرض الملف' : 'View profile',
        icon: Icons.person_outlined,
        color: AppColors.accent,
        gradient: AppColors.accentGradient,
        onTap: () {
          setState(() => _currentIndex = 2);
        },
      ),
      _HomeCardData(
        key: 'points_card',
        title: isRTL ? 'النقاط' : 'Points',
        subtitle: isRTL ? 'عرض التاريخ' : 'View history',
        icon: Icons.stars_outlined,
        color: AppColors.studyColor,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.studyColor, Color(0xFF0097A7)],
        ),
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const PointsHistoryScreen(),
            ),
          );
          _refreshData();
        },
      ),
    ];

    return GridView.builder(
      key: const Key('home_cards_grid'),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.0,
      ),
      itemCount: cards.length,
      itemBuilder: (context, index) {
        return AnimatedBuilder(
          animation: _cardAnimations[index],
          builder: (context, child) {
            return Transform.scale(
              scale: _cardAnimations[index].value,
              child: Opacity(
                opacity: _cardAnimations[index].value,
                child: _buildHomeCard(cards[index], theme),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildHomeCard(_HomeCardData data, ThemeData theme) {
    return Material(
      key: Key(data.key),
      color: Colors.transparent,
      child: InkWell(
        onTap: data.onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            gradient: data.gradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: data.color.withOpacity(0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    data.icon,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      data.title,
                      style: theme.textTheme.titleLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      data.subtitle,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: Colors.white.withOpacity(0.9),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Build recent activity section with real data
  Widget _buildRecentActivity(ThemeData theme, bool isRTL) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              isRTL ? 'النشاط الأخير' : 'Recent Activity',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            if (_recentActivities.length > 3)
              TextButton(
                onPressed: () {
                  // TODO: Navigate to full activity log
                  _showComingSoon(context, isRTL ? 'سجل النشاط' : 'Activity Log');
                },
                child: Text(isRTL ? 'عرض الكل' : 'View All'),
              ),
          ],
        ),
        const SizedBox(height: 12),

        // Show loading or activities
        if (_isLoadingActivities)
          Center(
            child: Padding(
              padding: const EdgeInsets.all(32.0),
              child: CircularProgressIndicator(color: AppColors.primary),
            ),
          )
        else if (_recentActivities.isEmpty)
          _buildEmptyActivities(theme, isRTL)
        else
          ..._recentActivities.take(3).map((activity) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _buildActivityItem(
                theme: theme,
                activity: activity,
                isRTL: isRTL,
              ),
            );
          }).toList(),
      ],
    );
  }

  Widget _buildEmptyActivities(ThemeData theme, bool isRTL) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.dividerColor,
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.history,
            size: 48,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 12),
          Text(
            isRTL ? 'لا يوجد نشاط حتى الآن' : 'No activity yet',
            style: theme.textTheme.bodyLarge?.copyWith(
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            isRTL ? 'ابدأ بحل الاختبارات لتظهر أنشطتك هنا' : 'Start taking exams to see your activity here',
            style: theme.textTheme.bodySmall?.copyWith(
              color: Colors.grey.shade500,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildActivityItem({
    required ThemeData theme,
    required ActivityItem activity,
    required bool isRTL,
  }) {
    final activityInfo = _getActivityInfo(activity, isRTL);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.dividerColor,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: activityInfo['color'].withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              activityInfo['icon'],
              color: activityInfo['color'],
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  activity.title,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _getTimeAgo(activity.timestamp, isRTL),
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          if (activity.points != null && activity.points! > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.warning.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.star,
                    size: 14,
                    color: AppColors.warning,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '+${activity.points}',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: AppColors.warning,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Map<String, dynamic> _getActivityInfo(ActivityItem activity, bool isRTL) {
    switch (activity.type) {
      case ActivityType.examCompleted:
        return {
          'icon': Icons.check_circle,
          'color': AppColors.success,
        };
      case ActivityType.pointsEarned:
        return {
          'icon': Icons.emoji_events,
          'color': AppColors.warning,
        };
      case ActivityType.levelUp:
        return {
          'icon': Icons.trending_up,
          'color': AppColors.info,
        };
      case ActivityType.unitUnlocked:
        return {
          'icon': Icons.lock_open,
          'color': AppColors.accent,
        };
      case ActivityType.achievementUnlocked:
        return {
          'icon': Icons.military_tech,
          'color': AppColors.secondary,
        };
      case ActivityType.dailyLogin:
        return {
          'icon': Icons.login,
          'color': AppColors.primary,
        };
      default:
        return {
          'icon': Icons.circle,
          'color': AppColors.textSecondary,
        };
    }
  }

  String _getTimeAgo(DateTime timestamp, bool isRTL) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 30) {
      final months = (difference.inDays / 30).floor();
      return isRTL ? 'منذ $months ${months == 1 ? 'شهر' : 'أشهر'}' : '$months month${months == 1 ? '' : 's'} ago';
    } else if (difference.inDays > 0) {
      return isRTL ? 'منذ ${difference.inDays} ${difference.inDays == 1 ? 'يوم' : 'أيام'}' : '${difference.inDays} day${difference.inDays == 1 ? '' : 's'} ago';
    } else if (difference.inHours > 0) {
      return isRTL ? 'منذ ${difference.inHours} ${difference.inHours == 1 ? 'ساعة' : 'ساعات'}' : '${difference.inHours} hour${difference.inHours == 1 ? '' : 's'} ago';
    } else if (difference.inMinutes > 0) {
      return isRTL ? 'منذ ${difference.inMinutes} ${difference.inMinutes == 1 ? 'دقيقة' : 'دقائق'}' : '${difference.inMinutes} minute${difference.inMinutes == 1 ? '' : 's'} ago';
    } else {
      return isRTL ? 'الآن' : 'Just now';
    }
  }

  Widget _buildBottomNavigation(ThemeData theme) {
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    return Container(
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: BottomNavigationBar(
        key: const Key('bottom_navigation'),
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
          if (index == 0) {
            _refreshData();
          }
        },
        type: BottomNavigationBarType.fixed,
        backgroundColor: theme.cardColor,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.textSecondary,
        selectedFontSize: 12,
        unselectedFontSize: 12,
        elevation: 0,
        items: [
          BottomNavigationBarItem(
            key: const Key('home_tab'),
            icon: const Icon(Icons.home_outlined),
            activeIcon: const Icon(Icons.home),
            label: isRTL ? 'الرئيسية' : 'Home',
            tooltip: isRTL ? 'الصفحة الرئيسية' : 'Home Page',
          ),
          BottomNavigationBarItem(
            key: const Key('leaderboard_tab'),
            icon: const Icon(Icons.emoji_events_outlined),
            activeIcon: const Icon(Icons.emoji_events),
            label: isRTL ? 'المتصدرين' : 'Leaderboard',
            tooltip: isRTL ? 'لوحة المتصدرين' : 'Leaderboard',
          ),
          BottomNavigationBarItem(
            key: const Key('profile_tab'),
            icon: const Icon(Icons.person_outlined),
            activeIcon: const Icon(Icons.person),
            label: isRTL ? 'الملف الشخصي' : 'Profile',
            tooltip: isRTL ? 'الملف الشخصي' : 'Profile',
          ),
        ],
      ),
    );
  }

  void _showComingSoon(BuildContext context, String feature) {
    final isRTL = Directionality.of(context) == TextDirection.rtl;
    NavigationHelper.showSnackBar(
      message: isRTL ? '$feature - قريباً!' : '$feature - Coming Soon!',
      backgroundColor: AppColors.info,
      textColor: Colors.white,
    );
  }
}

class _HomeCardData {
  final String key;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final LinearGradient gradient;
  final VoidCallback onTap;

  _HomeCardData({
    required this.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.gradient,
    required this.onTap,
  });
}