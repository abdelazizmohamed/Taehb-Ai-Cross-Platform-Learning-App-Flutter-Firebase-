import 'package:flutter/material.dart';
import 'package:taehb/data/models/question.dart';
import 'package:taehb/screens/exam_history_screen.dart';
import 'package:taehb/screens/exam_screen.dart';
import 'package:taehb/screens/ku_selection_screen.dart';
import 'package:taehb/screens/leaderboard_screen.dart';
import 'package:taehb/screens/results_screen.dart';
import 'package:taehb/screens/sign_up_screen.dart';

import '../../screens/home_screen.dart';
import '../../screens/login_screen.dart';
import '../../screens/profile_screen.dart';
import '../../screens/splash_screen.dart';

/// Navigation helper class for managing app navigation
class NavigationHelper {
  static final GlobalKey<NavigatorState> navigatorKey =
  GlobalKey<NavigatorState>();

  /// Get the current context
  static BuildContext? get context => navigatorKey.currentContext;

  /// Generate routes for named navigation
  static Route<dynamic>? generateRoute(RouteSettings settings) {
    print('🚀 NavigationHelper.generateRoute called for: ${settings.name}');
    print('📦 Arguments: ${settings.arguments}');

    switch (settings.name) {
      case '/':
        return MaterialPageRoute(
          builder: (_) => const SplashScreen(),
          settings: settings,
        );
      case '/login':
        return MaterialPageRoute(
          builder: (_) => const LoginScreen(),
          settings: settings,
        );
      case '/home':
        print('✅ Navigating to HomeScreen');
        return MaterialPageRoute(
          builder: (_) => const HomeScreen(),
          settings: settings,
        );
      case '/splash':
        return MaterialPageRoute(
          builder: (_) => const SplashScreen(),
          settings: settings,
        );
      case '/register':
        return MaterialPageRoute(
          builder: (_) => const SignUpScreen(),
          settings: settings,
        );

      case '/exam':
      // Expect arguments as a Map with 'questions' and 'knowledgeUnit'
        final args = settings.arguments as Map<String, dynamic>?;
        if (args == null) {
          print('❌ No arguments provided for /exam route');
          return _errorRoute('Missing exam arguments');
        }

        final questions = args['questions'] as List<Question>?;
        final knowledgeUnit = args['knowledgeUnit'] as String?; // تغيير من selectedKUs

        if (questions == null || knowledgeUnit == null) {
          print('❌ Invalid arguments for /exam route');
          return _errorRoute('Invalid exam arguments');
        }

        return MaterialPageRoute(
          builder: (_) => ExamScreen(
            questions: questions,
            knowledgeUnit: knowledgeUnit, // تغيير من selectedKUs
          ),
          settings: settings,
        );

      case '/profile':
        return MaterialPageRoute(
          builder: (_) => ProfileScreen(),
          settings: settings,
        );

      case '/leaderboard':
        return MaterialPageRoute(
          builder: (_) => LeaderboardScreen(),
          settings: settings,
        );

      case '/exam_history':
        return MaterialPageRoute(
          builder: (_) => ExamHistoryPage(),
          settings: settings,
        );

      case '/result':
        final args = settings.arguments as Map<String, dynamic>?;
        if (args == null) {
          print('❌ No arguments provided for /result route');
          return _errorRoute('Missing result arguments');
        }

        final questions = args['questions'] as List<Question>?;
        final knowledgeUnit = args['knowledgeUnit'] as String?; // تغيير من selectedKUs

        if (questions == null || knowledgeUnit == null) {
          print('❌ Invalid arguments for /result route');
          return _errorRoute('Invalid result arguments');
        }

        return MaterialPageRoute(
          builder: (_) => ResultsPage(
            questions: questions,
            knowledgeUnit: knowledgeUnit, // تغيير من selectedKUs
          ),
          settings: settings,
        );

      case '/ku_screen':
        return MaterialPageRoute(
          builder: (_) => const KUSelectionPage(),
          settings: settings,
        );

      default:
        print('❌ No route found for: ${settings.name}');
        return _errorRoute('No route defined for ${settings.name}');
    }
  }

  /// Helper method to create error route
  static MaterialPageRoute _errorRoute(String message) {
    return MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(
          title: const Text('Error'),
          backgroundColor: Colors.red,
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.error_outline,
                  color: Colors.red,
                  size: 64,
                ),
                const SizedBox(height: 16),
                Text(
                  message,
                  style: const TextStyle(fontSize: 18),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: () => navigateAndRemoveUntil('/home'),
                  icon: const Icon(Icons.home),
                  label: const Text('Go to Home'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Navigate to a named route
  static Future<dynamic>? navigateTo(
      String routeName, {
        Object? arguments,
      }) {
    return navigatorKey.currentState?.pushNamed(
      routeName,
      arguments: arguments,
    );
  }

  /// Navigate to a named route and remove all previous routes
  static Future<dynamic>? navigateAndRemoveUntil(
      String routeName, {
        Object? arguments,
      }) {
    return navigatorKey.currentState?.pushNamedAndRemoveUntil(
      routeName,
          (route) => false,
      arguments: arguments,
    );
  }

  /// Navigate to a named route and replace current route
  static Future<dynamic>? navigateReplacement(
      String routeName, {
        Object? arguments,
      }) {
    return navigatorKey.currentState?.pushReplacementNamed(
      routeName,
      arguments: arguments,
    );
  }

  /// Pop the current route
  static void pop({dynamic result}) {
    navigatorKey.currentState?.pop(result);
  }

  /// Pop until a specific route
  static void popUntil(String routeName) {
    navigatorKey.currentState?.popUntil(
      ModalRoute.withName(routeName),
    );
  }

  /// Check if can pop
  static bool canPop() {
    return navigatorKey.currentState?.canPop() ?? false;
  }

  /// Show snackbar
  static void showSnackBar({
    required String message,
    Color? backgroundColor,
    Color? textColor,
    Duration duration = const Duration(seconds: 3),
    SnackBarAction? action,
  }) {
    final context = navigatorKey.currentContext;
    if (context != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            message,
            style: TextStyle(color: textColor ?? Colors.white),
          ),
          backgroundColor: backgroundColor,
          duration: duration,
          action: action,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          margin: const EdgeInsets.all(16),
        ),
      );
    }
  }

  /// Show dialog
  static Future<T?> showCustomDialog<T>({
    required Widget dialog,
    bool barrierDismissible = true,
  }) {
    final context = navigatorKey.currentContext;
    if (context != null) {
      return showDialog<T>(
        context: context,
        barrierDismissible: barrierDismissible,
        builder: (context) => dialog,
      );
    }
    return Future.value(null);
  }

  /// Show bottom sheet
  static Future<T?> showBottomSheet<T>({
    required Widget child,
    bool isDismissible = true,
    bool enableDrag = true,
  }) {
    final context = navigatorKey.currentContext;
    if (context != null) {
      return showModalBottomSheet<T>(
        context: context,
        isDismissible: isDismissible,
        enableDrag: enableDrag,
        isScrollControlled: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        builder: (context) => child,
      );
    }
    return Future.value(null);
  }
}