class Validators {
  static final RegExp _emailRegex = RegExp(r'^[\w\.-]+@[\w\.-]+\.[A-Za-z]{2,}$');

  /// Validates email format
  static String? validateEmail(String? value, {String? errorMessage}) {
    final v = (value ?? '').trim();
    if (v.isEmpty) {
      return errorMessage ?? 'Email is required';
    }
    if (!_emailRegex.hasMatch(v)) {
      return errorMessage ?? 'Please enter a valid email address';
    }
    return null;
  }

  /// Validates minimum length for any field
  static String? validateMinLength(
      String? value,
      int minLength,
      String fieldName, {
        String? errorMessage,
      }) {
    final v = value ?? '';
    if (v.isEmpty) {
      return errorMessage ?? '$fieldName is required';
    }
    if (v.length < minLength) {
      return errorMessage ?? '$fieldName must be at least $minLength characters long';
    }
    return null;
  }

  /// Validates password with specific requirements
  static String? validatePassword(String? value, {int minLength = 6, String? errorMessage}) {
    final v = value ?? '';
    if (v.isEmpty) {
      return errorMessage ?? 'Password is required';
    }
    if (v.length < minLength) {
      return errorMessage ?? 'Password must be at least $minLength characters long';
    }
    return null;
  }

  static String? validateRequired(String? value, String fieldName, {String? errorMessage}) {
    final v = (value ?? '').trim();
    if (v.isEmpty) {
      return errorMessage ?? '$fieldName is required';
    }
    return null;
  }
  /// Validates that a name is not empty
  static String? validateName(String? value, {String? errorMessage}) {
    final v = (value ?? '').trim();
    if (v.isEmpty) {
      return errorMessage ?? 'Name is required';
    }
    return null;
  }
  /// Validates phone number format
  static String? validatePhone(String? value, {String? errorMessage}) {
    final v = (value ?? '').trim();
    if (v.isEmpty) {
      return errorMessage ?? 'Phone number is required';
    }


    // Remove spaces, dashes, parentheses, and plus signs
    final cleanPhone = v.replaceAll(RegExp(r'[\s\-\(\)\+]'), '');

    // Check if it's a valid phone number (10-15 digits)
    if (!RegExp(r'^\d{10,15}$').hasMatch(cleanPhone)) {
      return errorMessage ?? 'Please enter a valid phone number';
    }
    return null;
  }

  /// Validates that two passwords match
  static String? validatePasswordMatch(String? value, String? confirmValue, {String? errorMessage}) {
    if (value != confirmValue) {
      return errorMessage ?? 'Passwords do not match';
    }
    return null;
  }

  /// Validates URL format
  static String? validateUrl(String? value, {String? errorMessage}) {
    final v = (value ?? '').trim();
    if (v.isEmpty) {
      return errorMessage ?? 'URL is required';
    }

    if (!RegExp(r'^https?:\/\/[\w\-]+(\.[\w\-]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?$').hasMatch(v)) {
      return errorMessage ?? 'Please enter a valid URL';
    }
    return null;
  }

  /// Validates numeric input
  static String? validateNumeric(String? value, String fieldName, {String? errorMessage}) {
    final v = (value ?? '').trim();
    if (v.isEmpty) {
      return errorMessage ?? '$fieldName is required';
    }

    if (double.tryParse(v) == null) {
      return errorMessage ?? '$fieldName must be a valid number';
    }
    return null;
  }

  /// Validates that a number is within a specific range
  static String? validateNumberRange(
      String? value,
      String fieldName,
      double min,
      double max, {
        String? errorMessage,
      }) {
    final v = (value ?? '').trim();
    if (v.isEmpty) {
      return '$fieldName is required';
    }

    final number = double.tryParse(v);
    if (number == null) {
      return '$fieldName must be a valid number';
    }
    if (number < min || number > max) {
      return errorMessage ?? '$fieldName must be between $min and $max';
    }
    return null;
  }

  /// Localized email validator using provided messages
  static String? validateEmailLocalized(
    String? value, {
    required String requiredMessage,
    required String invalidMessage,
  }) {
    final v = (value ?? '').trim();
    if (v.isEmpty) return requiredMessage;
    if (!_emailRegex.hasMatch(v)) return invalidMessage;
    return null;
  }

  /// Localized min length validator using provided messages
  static String? validateMinLengthLocalized(
    String? value,
    int minLength, {
    required String requiredMessage,
    required String tooShortMessage,
  }) {
    final v = value ?? '';
    if (v.isEmpty) return requiredMessage;
    if (v.length < minLength) return tooShortMessage;
    return null;
  }
}