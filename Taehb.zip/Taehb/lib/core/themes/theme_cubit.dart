import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';
import 'package:taehb/data/datasources/local_data_source.dart';

/// Theme mode enum
enum AppThemeMode { light, dark, system }

class ThemeCubit extends Cubit<AppThemeMode> {
  final LocalDataSource _localDataSource;

  ThemeCubit(this._localDataSource) : super(AppThemeMode.system) {
    _loadTheme();
  }

  ThemeMode get themeMode {
    switch (state) {
      case AppThemeMode.light:
        return ThemeMode.light;
      case AppThemeMode.dark:
        return ThemeMode.dark;
      case AppThemeMode.system:
        return ThemeMode.system;
    }
  }

  /// Load saved theme preference
  Future<void> _loadTheme() async {
    try {
      final savedTheme = await _localDataSource.getTheme();
      if (savedTheme != null) {
        switch (savedTheme) {
          case 'light':
            emit(AppThemeMode.light);
            break;
          case 'dark':
            emit(AppThemeMode.dark);
            break;
          case 'system':
            emit(AppThemeMode.system);
            break;
        }
      }
    } catch (e) {
      print('Error loading theme: $e');
    }
  }

  /// Change theme
  Future<void> changeTheme(AppThemeMode mode) async {
    try {
      emit(mode);
      await _localDataSource.saveTheme(mode.toString().split('.').last);
    } catch (e) {
      print('Error saving theme: $e');
    }
  }

  /// Toggle between light and dark
  Future<void> toggleTheme() async {
    final newMode = state == AppThemeMode.light ? AppThemeMode.dark : AppThemeMode.light;
    await changeTheme(newMode);
  }
}