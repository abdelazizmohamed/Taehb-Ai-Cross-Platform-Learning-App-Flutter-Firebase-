import 'package:flutter/material.dart';



class AppColors {
  AppColors._(); // Private constructor to prevent instantiation

  /// Main brand color - Blue
  static const Color primary = Color(0xFF2196F3);

  /// Lighter shade of primary color
  static const Color primaryLight = Color(0xFF64B5F6);

  /// Darker shade of primary color
  static const Color primaryDark = Color(0xFF1976D2);

  /// Primary variant for subtle variations
  static const Color primaryVariant = Color(0xFF1565C0);

  /// Ultra light primary for backgrounds
  static const Color primaryLighter = Color(0xFFE3F2FD);

  // ============================================================================
  // SECONDARY COLORS - Green Palette (Success, Positive Actions)
  // ============================================================================

  /// Secondary brand color - Green
  static const Color secondary = Color(0xFF4CAF50);

  /// Lighter shade of secondary color
  static const Color secondaryLight = Color(0xFF81C784);

  /// Darker shade of secondary color
  static const Color secondaryDark = Color(0xFF388E3C);

  /// Secondary variant
  static const Color secondaryVariant = Color(0xFF2E7D32);

  /// Ultra light secondary for backgrounds
  static const Color secondaryLighter = Color(0xFFE8F5E8);


  /// Accent color - Orange
  static const Color accent = Color(0xFFFF9800);

  /// Lighter shade of accent color
  static const Color accentLight = Color(0xFFFFB74D);

  /// Darker shade of accent color
  static const Color accentDark = Color(0xFFF57C00);

  /// Ultra light accent for backgrounds
  static const Color accentLighter = Color(0xFFFFF3E0);

  /// Main surface color (cards, sheets)
  static const Color surface = Color(0xFFFFFFFF);

  /// App background color
  static const Color background = Color(0xFFFAFAFA);

  /// Card color
  static const Color card = Color(0xFFFFFFFF);

  /// Elevated surface (dialogs, menus)
  static const Color surfaceElevated = Color(0xFFFFFFFF);

  /// Surface variant for subtle differentiation
  static const Color surfaceVariant = Color(0xFFF5F5F5);


  /// Dark theme main surface
  static const Color surfaceDark = Color(0xFF121212);

  /// Dark theme background
  static const Color backgroundDark = Color(0xFF000000);

  /// Dark theme card color
  static const Color cardDark = Color(0xFF1E1E1E);

  /// Dark theme elevated surface
  static const Color surfaceElevatedDark = Color(0xFF1F1F1F);

  /// Dark theme surface variant
  static const Color surfaceVariantDark = Color(0xFF2C2C2C);


  /// Primary text color (high emphasis)
  static const Color textPrimary = Color(0xFF212121);

  /// Secondary text color (medium emphasis)
  static const Color textSecondary = Color(0xFF757575);

  /// Hint text color (low emphasis)
  static const Color textHint = Color(0xFF9E9E9E);

  /// Disabled text color
  static const Color textDisabled = Color(0xFFBDBDBD);

  /// Inverse text (for dark backgrounds)
  static const Color textInverse = Color(0xFFFFFFFF);


  /// Dark theme primary text
  static const Color textPrimaryDark = Color(0xFFFFFFFF);

  /// Dark theme secondary text
  static const Color textSecondaryDark = Color(0xFFB3B3B3);

  /// Dark theme hint text
  static const Color textHintDark = Color(0xFF666666);

  /// Dark theme disabled text
  static const Color textDisabledDark = Color(0xFF555555);

  /// Success state color
  static const Color success = Color(0xFF4CAF50);

  /// Success light variant
  static const Color successLight = Color(0xFF81C784);

  /// Success dark variant
  static const Color successDark = Color(0xFF388E3C);

  /// Error state color
  static const Color error = Color(0xFFF44336);

  /// Error light variant
  static const Color errorLight = Color(0xFFEF5350);

  /// Error dark variant
  static const Color errorDark = Color(0xFFD32F2F);

  /// Warning state color
  static const Color warning = Color(0xFFFF9800);

  /// Warning light variant
  static const Color warningLight = Color(0xFFFFB74D);

  /// Warning dark variant
  static const Color warningDark = Color(0xFFF57C00);

  /// Info state color
  static const Color info = Color(0xFF2196F3);

  /// Info light variant
  static const Color infoLight = Color(0xFF64B5F6);

  /// Info dark variant
  static const Color infoDark = Color(0xFF1976D2);

  /// Divider color
  static const Color divider = Color(0xFFE0E0E0);

  /// Border color
  static const Color border = Color(0xFFE0E0E0);

  /// Dark theme border
  static const Color borderDark = Color(0xFF424242);

  /// Outline color
  static const Color outline = Color(0xFFBDBDBD);

  /// Dark theme outline
  static const Color outlineDark = Color(0xFF616161);

  /// Light shadow
  static const Color shadow = Color(0x1F000000);

  /// Medium shadow
  static const Color shadowMedium = Color(0x33000000);

  /// Dark shadow
  static const Color shadowDark = Color(0x3F000000);

  /// Colored shadow for primary elements
  static const Color shadowPrimary = Color(0x1A2196F3);

  /// Colored shadow for accent elements
  static const Color shadowAccent = Color(0x1AFF9800);

  /// Primary gradient (blue tones)
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primary, primaryDark],
    stops: [0.0, 1.0],
  );

  /// Secondary gradient (green tones)
  static const LinearGradient secondaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [secondary, secondaryDark],
    stops: [0.0, 1.0],
  );

  /// Accent gradient (orange tones)
  static const LinearGradient accentGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [accent, accentDark],
    stops: [0.0, 1.0],
  );

  /// Success gradient
  static const LinearGradient successGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [success, successDark],
    stops: [0.0, 1.0],
  );

  /// Shimmer gradient for loading states
  static const LinearGradient shimmerGradient = LinearGradient(
    begin: Alignment(-1.0, -0.3),
    end: Alignment(1.0, 0.3),
    colors: [
      Color(0xFFE0E0E0),
      Color(0xFFF5F5F5),
      Color(0xFFE0E0E0),
    ],
    stops: [0.0, 0.5, 1.0],
  );

  /// Background gradient for splash/onboarding
  static const LinearGradient backgroundGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xFFE3F2FD), // primaryLighter
      Color(0xFFFAFAFA), // background
      Color(0xFFFFF3E0), // accentLighter
    ],
    stops: [0.0, 0.5, 1.0],
  );

  /// Books and reading color
  static const Color bookColor = Color(0xFF8E24AA);

  /// Brain and intelligence color
  static const Color brainColor = Color(0xFFE91E63);

  /// Study and learning color
  static const Color studyColor = Color(0xFF00BCD4);

  /// Exam and test color
  static const Color examColor = Color(0xFFFF5722);

  /// Achievement and progress color
  static const Color achievementColor = Color(0xFFFFC107);

  /// Certificate and completion color
  static const Color certificateColor = Color(0xFF9C27B0);

  /// Chart color palette for data visualization
  static const List<Color> chartColors = [
    Color(0xFF2196F3), // Primary blue
    Color(0xFF4CAF50), // Secondary green
    Color(0xFFFF9800), // Accent orange
    Color(0xFF9C27B0), // Purple
    Color(0xFFF44336), // Red
    Color(0xFF00BCD4), // Cyan
    Color(0xFFFFEB3B), // Yellow
    Color(0xFF795548), // Brown
  ];

  /// Progress indicator colors (from red to green)
  static const List<Color> progressColors = [
    Color(0xFFF44336), // 0-25% Red
    Color(0xFFFF9800), // 25-50% Orange
    Color(0xFFFFC107), // 50-75% Yellow
    Color(0xFF4CAF50), // 75-100% Green
  ];

  /// Get color with opacity
  static Color withOpacity(Color color, double opacity) {
    return color.withOpacity(opacity);
  }

  /// Get progress color based on percentage
  static Color getProgressColor(double percentage) {
    if (percentage < 0.25) return progressColors[0];
    if (percentage < 0.5) return progressColors[1];
    if (percentage < 0.75) return progressColors[2];
    return progressColors[3];
  }

  /// Get chart color by index (cycles through palette)
  static Color getChartColor(int index) {
    return chartColors[index % chartColors.length];
  }

  /// Blend two colors
  static Color blendColors(Color color1, Color color2, double ratio) {
    return Color.lerp(color1, color2, ratio) ?? color1;
  }

  /// Get contrasting text color for background
  static Color getContrastingTextColor(Color backgroundColor) {
    final luminance = backgroundColor.computeLuminance();
    return luminance > 0.5 ? textPrimary : textPrimaryDark;
  }

  /// Generate material color swatch from single color
  static MaterialColor generateMaterialColor(Color color) {
    final swatch = <int, Color>{};
    final hsl = HSLColor.fromColor(color);

    swatch[50] = hsl.withLightness(0.95).toColor();
    swatch[100] = hsl.withLightness(0.9).toColor();
    swatch[200] = hsl.withLightness(0.8).toColor();
    swatch[300] = hsl.withLightness(0.7).toColor();
    swatch[400] = hsl.withLightness(0.6).toColor();
    swatch[500] = color;
    swatch[600] = hsl.withLightness(0.4).toColor();
    swatch[700] = hsl.withLightness(0.3).toColor();
    swatch[800] = hsl.withLightness(0.2).toColor();
    swatch[900] = hsl.withLightness(0.1).toColor();

    return MaterialColor(color.value, swatch);
  }
}

extension ColorExtensions on Color {
  String toHex() => '#${value.toRadixString(16).substring(2).toUpperCase()}';

  Color lighter([double amount = 0.1]) {
    final hsl = HSLColor.fromColor(this);
    return hsl.withLightness((hsl.lightness + amount).clamp(0.0, 1.0)).toColor();
  }

  /// Get darker shade of color
  Color darker([double amount = 0.1]) {
    final hsl = HSLColor.fromColor(this);
    return hsl.withLightness((hsl.lightness - amount).clamp(0.0, 1.0)).toColor();
  }

  /// Get more saturated version of color
  Color saturate([double amount = 0.1]) {
    final hsl = HSLColor.fromColor(this);
    return hsl.withSaturation((hsl.saturation + amount).clamp(0.0, 1.0)).toColor();
  }

  /// Get desaturated version of color
  Color desaturate([double amount = 0.1]) {
    final hsl = HSLColor.fromColor(this);
    return hsl.withSaturation((hsl.saturation - amount).clamp(0.0, 1.0)).toColor();
  }
}

/// Color scheme generator for different themes
class ColorSchemeGenerator {
  /// Generate light color scheme
  static ColorScheme lightColorScheme() {
    return ColorScheme.light(
      primary: AppColors.primary,
      primaryContainer: AppColors.primaryLight,
      secondary: AppColors.secondary,
      secondaryContainer: AppColors.secondaryLight,
      tertiary: AppColors.accent,
      tertiaryContainer: AppColors.accentLight,
      surface: AppColors.surface,
      onSurfaceVariant: AppColors.surfaceVariant,
      error: AppColors.error,
      errorContainer: AppColors.errorLight,
      outline: AppColors.outline,
      shadow: AppColors.shadow,
      inverseSurface: AppColors.surfaceDark,
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onTertiary: Colors.white,
      onSurface: AppColors.textPrimary,
      onError: Colors.white,
    );
  }

  /// Generate dark color scheme
  static ColorScheme darkColorScheme() {
    return ColorScheme.dark(
      primary: AppColors.primaryLight,
      primaryContainer: AppColors.primary,
      secondary: AppColors.secondaryLight,
      secondaryContainer: AppColors.secondary,
      tertiary: AppColors.accentLight,
      tertiaryContainer: AppColors.accent,
      surface: AppColors.surfaceDark,
      onSurfaceVariant: AppColors.surfaceVariantDark,
      error: AppColors.errorLight,
      errorContainer: AppColors.error,
      outline: AppColors.outlineDark,
      shadow: AppColors.shadowDark,
      inverseSurface: AppColors.surface,
      onPrimary: Colors.black,
      onSecondary: Colors.black,
      onTertiary: Colors.black,
      onSurface: AppColors.textPrimaryDark,
      onError: Colors.white,
    );
  }
}