class AppStrings {
  static const String apiBaseUrl = 'http://10.0.2.2:8000';
  static const String loginRoute = '/login';
  static const String homeRoute = '/home';
  static const String registerRoute = '/register';
  static const String loginTitle = 'Welcome Back';
  static const String loginSubtitle = 'Sign in to continue your learning journey';
  static const String emailPlaceholder = 'Enter your email';
  static const String passwordPlaceholder = 'Enter your password';

  // Additional app constants
  static const String appName = 'Taehb';
  static const String appNameArabic = 'تأهّب';
  static const String appSlogan = 'تأهبك اليوم يضمن جاهزيتك غدًا';
  static const String appSloganEnglish = 'Prepare today, be ready tomorrow';
  static const String appVersion = '1.0.0';

  // API configuration and endpoints
  static const String baseUrl = apiBaseUrl; // alias for consistency
  static const String loginEndpoint = '/login';
  static const String registerEndpoint = '/register';
  static const String forgotPasswordEndpoint = '/auth/forgot-password';
  static const String refreshTokenEndpoint = '/auth/refresh-token';
  static const String logoutEndpoint = '/auth/logout';

  static const String accessTokenKey = 'access_token';
  static const String refreshTokenKey = 'refresh_token';
  static const String userDataKey = 'user_data';
  static const String rememberMeKey = 'remember_me';
}
