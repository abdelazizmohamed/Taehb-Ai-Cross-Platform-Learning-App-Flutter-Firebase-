import 'package:flutter/material.dart';
  import 'package:flutter/services.dart';
  import 'package:taehb/core/constants/colors.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final IconData? icon;
  final bool isFullWidth;
  final double height;

  const CustomButton({
    super.key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.icon,
    this.isFullWidth = true,
    this.height = 48,
  });

  @override
  Widget build(BuildContext context) {
    final content = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (isLoading) ...[
          const SizedBox(
            height: 20,
            width: 20,
            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
          ),
          const SizedBox(width: 12),
        ] else if (icon != null) ...[
          Icon(icon!, size: 20),
          const SizedBox(width: 8),
        ],
        Text(text),
      ],
    );

    final button = SizedBox(
      height: height,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        child: content,
      ),
    );

    return isFullWidth ? SizedBox(width: double.infinity, child: button) : button;
  }
}

/// Small wrapper around FloatingActionButton with project defaults
class CustomFloatingActionButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget child;
  final String? tooltip;

  const CustomFloatingActionButton({
    super.key,
    this.onPressed,
    required this.child,
    this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: onPressed,
      tooltip: tooltip,
      backgroundColor: AppColors.accent,
      foregroundColor: Colors.white,
      child: child,
    );
  }
}

class SocialLoginButton extends StatefulWidget {
  final String text;
  final Widget icon;
  final VoidCallback? onPressed;
  final Color? backgroundColor;
  final Color? textColor;
  final Color? borderColor;
  final double height;
  final double borderRadius;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final bool isLoading;
  final bool isFullWidth;
  final double? width;
  final TextStyle? textStyle;
  final double iconSpacing;

  const SocialLoginButton({
    Key? key,
    required this.text,
    required this.icon,
    this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.borderColor,
    this.height = 52.0,
    this.borderRadius = 16.0,
    this.padding,
    this.margin,
    this.isLoading = false,
    this.isFullWidth = true,
    this.width,
    this.textStyle,
    this.iconSpacing = 12.0,
  }) : super(key: key);

  @override
  State<SocialLoginButton> createState() => _SocialLoginButtonState();
}

class _SocialLoginButtonState extends State<SocialLoginButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  bool _isPressed = false;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _opacityAnimation = Tween<double>(
      begin: 1.0,
      end: 0.7,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  void _handleTapDown(TapDownDetails details) {
    if (widget.onPressed != null && !widget.isLoading) {
      setState(() {
        _isPressed = true;
      });
      _animationController.forward();
    }
  }

  void _handleTapUp(TapUpDetails details) {
    if (_isPressed) {
      setState(() {
        _isPressed = false;
      });
      _animationController.reverse();
    }
  }

  void _handleTapCancel() {
    if (_isPressed) {
      setState(() {
        _isPressed = false;
      });
      _animationController.reverse();
    }
  }

  void _handleTap() {
    if (widget.onPressed != null && !widget.isLoading) {
      HapticFeedback.lightImpact();
      widget.onPressed!();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final defaultBackgroundColor = theme.colorScheme.surface;
    final defaultTextColor = theme.colorScheme.onSurface;
    final defaultBorderColor = AppColors.border;

    return Container(
      margin: widget.margin,
      width: widget.isFullWidth ? double.infinity : widget.width,
      height: widget.height,
      child: AnimatedBuilder(
        animation: _animationController,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Opacity(
              opacity: _opacityAnimation.value,
              child: GestureDetector(
                onTapDown: _handleTapDown,
                onTapUp: _handleTapUp,
                onTapCancel: _handleTapCancel,
                onTap: _handleTap,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  decoration: BoxDecoration(
                    color: widget.backgroundColor ?? defaultBackgroundColor,
                    borderRadius: BorderRadius.circular(widget.borderRadius),
                    border: Border.all(
                      color: widget.borderColor ?? defaultBorderColor,
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        spreadRadius: 0,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(widget.borderRadius),
                      onTap: widget.isLoading ? null : _handleTap,
                      child: Container(
                        padding: widget.padding ?? const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        child: _buildButtonContent(defaultTextColor),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildButtonContent(Color defaultTextColor) {
    if (widget.isLoading) {
      return _buildLoadingContent();
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        // Icon
        widget.icon,

        SizedBox(width: widget.iconSpacing),

        // Text
        Flexible(
          child: Text(
            widget.text,
            style: widget.textStyle ?? TextStyle(
              color: widget.textColor ?? defaultTextColor,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingContent() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 20,
          height: 20,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(
              widget.textColor ?? AppColors.primary,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Text(
          'Loading...',
          style: widget.textStyle ?? TextStyle(
            color: widget.textColor ?? AppColors.textSecondary,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

/// Predefined social login buttons for common providers
class GoogleLoginButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final bool isLoading;
  final String? customText;

  const GoogleLoginButton({
    Key? key,
    this.onPressed,
    this.isLoading = false,
    this.customText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SocialLoginButton(
      text: customText ?? 'Continue with Google',
      icon: Image.asset(
        'assets/icons/google_logo.png', // You'll need to add this asset
        width: 20,
        height: 20,
        errorBuilder: (context, error, stackTrace) {
          // Fallback to a simple colored container if image not found
          return Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.red,
            ),
            child: const Center(
              child: Text(
                'G',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          );
        },
      ),
      onPressed: onPressed,
      isLoading: isLoading,
      backgroundColor: Colors.white,
      textColor: Colors.black87,
      borderColor: Colors.grey.shade300,
    );
  }
}

class AppleLoginButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final bool isLoading;
  final String? customText;

  const AppleLoginButton({
    Key? key,
    this.onPressed,
    this.isLoading = false,
    this.customText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SocialLoginButton(
      text: customText ?? 'Continue with Apple',
      icon: const Icon(
        Icons.apple,
        color: Colors.white,
        size: 20,
      ),
      onPressed: onPressed,
      isLoading: isLoading,
      backgroundColor: Colors.black,
      textColor: Colors.white,
      borderColor: Colors.black,
    );
  }
}

class FacebookLoginButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final bool isLoading;
  final String? customText;

  const FacebookLoginButton({
    Key? key,
    this.onPressed,
    this.isLoading = false,
    this.customText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SocialLoginButton(
      text: customText ?? 'Continue with Facebook',
      icon: Container(
        width: 20,
        height: 20,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFF1877F2), // Facebook blue
        ),
        child: const Center(
          child: Text(
            'f',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
      ),
      onPressed: onPressed,
      isLoading: isLoading,
      backgroundColor: const Color(0xFF1877F2),
      textColor: Colors.white,
      borderColor: const Color(0xFF1877F2),
    );
  }
}

class TwitterLoginButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final bool isLoading;
  final String? customText;

  const TwitterLoginButton({
    Key? key,
    this.onPressed,
    this.isLoading = false,
    this.customText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SocialLoginButton(
      text: customText ?? 'Continue with Twitter',
      icon: Container(
        width: 20,
        height: 20,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFF1DA1F2),
        ),
        child: const Center(
          child: Icon(
            Icons.alternate_email,
            color: Colors.white,
            size: 12,
          ),
        ),
      ),
      onPressed: onPressed,
      isLoading: isLoading,
      backgroundColor: const Color(0xFF1DA1F2),
      textColor: Colors.white,
      borderColor: const Color(0xFF1DA1F2),
    );
  }
}

class MicrosoftLoginButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final bool isLoading;
  final String? customText;

  const MicrosoftLoginButton({
    super.key,
    this.onPressed,
    this.isLoading = false,
    this.customText,
  });

  @override
  Widget build(BuildContext context) {
    return SocialLoginButton(
      text: customText ?? 'Continue with Microsoft',
      icon: Container(
        width: 20,
        height: 20,
        child: Row(
          children: [
            Container(width: 9, height: 9, color: const Color(0xFFF25022)),
            const SizedBox(width: 1),
            Container(width: 9, height: 9, color: const Color(0xFF7FBA00)),
            const SizedBox(width: 1),
            Container(width: 9, height: 9, color: const Color(0xFF00A4EF)),
            const SizedBox(width: 1),
            Container(width: 9, height: 9, color: const Color(0xFFFFB900)),
          ],
        ),
      ),
      onPressed: onPressed,
      isLoading: isLoading,
      backgroundColor: Colors.white,
      textColor: Colors.black87,
      borderColor: Colors.grey.shade300,
    );
  }
}