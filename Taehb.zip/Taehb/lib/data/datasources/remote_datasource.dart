import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path/path.dart' as path;

class RemoteDataSource {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // Collection references
  static const String _usersCollection = 'users';
  static const String _profileImagesPath = 'profile_images';

  /// Login with Firebase Authentication
  Future<User?> login({
    required String email,
    required String password,
  }) async {
    try {

      final UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email.trim().toLowerCase(),
        password: password,
      );

      if (userCredential.user == null) {
        throw Exception('Login failed: User credential is null');
      }

      final User user = userCredential.user!;


      // Update last login in Firestore
      await _firestore.collection(_usersCollection).doc(user.uid).update({
        'last_login': FieldValue.serverTimestamp(),
      });

      return user;
    } on FirebaseAuthException catch (e) {
      throw _handleFirebaseAuthError(e);
    } catch (e, stackTrace) {

      rethrow;
    }
  }

  /// Register with Firebase Authentication, Firestore, and Storage
  /// Returns a map containing success status, tokens, and user data
  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
    String? phone,
    String? university,
    String? major,
    int? yearOfStudy,
    File? profileImage,
  }) async {
    try {


      // Step 1: Create Firebase Auth user
      final UserCredential userCredential =
      await _auth.createUserWithEmailAndPassword(
        email: email.trim().toLowerCase(),
        password: password,
      );

      final User? user = userCredential.user;
      if (user == null) {
        throw Exception('Failed to create user account');
      }


      // Step 2: Upload profile image if provided
      String? profileImageUrl;
      if (profileImage != null) {
        profileImageUrl = await _uploadProfileImage(user.uid, profileImage);
      }

      await user.updateDisplayName(name);
      if (profileImageUrl != null) {
        await user.updatePhotoURL(profileImageUrl);
      }
      await user.reload();


      final userData = {
        'id': user.uid,
        'name': name.trim(),
        'email': email.trim().toLowerCase(),
        'phone': phone?.trim(),
        'university': university?.trim(),
        'major': major?.trim(),
        'year_of_study': yearOfStudy,
        'profile_image_url': profileImageUrl,
        'created_at': FieldValue.serverTimestamp(),
        'updated_at': FieldValue.serverTimestamp(),
        'email_verified': user.emailVerified,
        'last_login': FieldValue.serverTimestamp(),
        'points': 0,
        'level': 1,
        'rank': 0,
        'courses_completed': 0,
        'exams_taken': 0,
        'achievements': [],
        'preferences': {
          'language': 'en',
          'theme': 'system',
          'notifications': true,
        },
      };

      await _firestore
          .collection(_usersCollection)
          .doc(user.uid)
          .set(userData);


      // Step 5: Send email verification
      if (!user.emailVerified) {
        await user.sendEmailVerification();
      }

      // Step 6: Get ID token
      final String? token = await user.getIdToken();
      return {
        'success': true,
        'data': {
          'access_token': token ?? '',
          'refresh_token': await user.getIdToken(true) ?? '',
          'user': {
            'id': user.uid,
            'email': user.email ?? '',
            'name': name,
            'phone': phone,
            'university': university,
            'major': major,
            'year_of_study': yearOfStudy,
            'profile_image_url': profileImageUrl,
            'created_at': DateTime.now().toIso8601String(),
            'updated_at': DateTime.now().toIso8601String(),
          }
        }
      };
    } on FirebaseAuthException catch (e) {
      throw _handleFirebaseAuthError(e);
    } on FirebaseException catch (e) {
      throw Exception('Firebase error: ${e.message}');
    } catch (e) {
      throw Exception('Registration failed: ${e.toString()}');
    }
  }

  /// Upload profile image to Firebase Storage
  Future<String> _uploadProfileImage(String userId, File imageFile) async {
    try {
      // Generate unique filename
      final String fileName = '$userId${path.extension(imageFile.path)}';
      final String filePath = '$_profileImagesPath/$fileName';

      // Create reference
      final Reference storageRef = _storage.ref().child(filePath);

      // Set metadata
      final SettableMetadata metadata = SettableMetadata(
        contentType: 'image/jpeg',
        customMetadata: {
          'uploaded_by': userId,
          'uploaded_at': DateTime.now().toIso8601String(),
        },
      );

      // Upload file
      final UploadTask uploadTask = storageRef.putFile(imageFile, metadata);

      // Monitor upload progress
      uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
        final progress =
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
      });

      // Wait for upload to complete
      final TaskSnapshot snapshot = await uploadTask;

      // Get download URL
      final String downloadUrl = await snapshot.ref.getDownloadURL();

      return downloadUrl;
    } on FirebaseException catch (e) {
      throw Exception('Failed to upload image: ${e.message}');
    } catch (e) {
      throw Exception('Failed to upload image: ${e.toString()}');
    }
  }

  /// Get user data from Firestore
  Future<Map<String, dynamic>?> getUserData(String userId) async {
    try {
      final doc = await _firestore
          .collection(_usersCollection)
          .doc(userId)
          .get();

      if (doc.exists) {
        return doc.data();
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Forgot Password
  // Future<Map<String, dynamic>> forgotPassword({required String email}) async {
  //   try {
  //     await _auth.sendPasswordResetEmail(email: email.trim().toLowerCase());
  //     return {
  //       'success': true,
  //       'message': 'Password reset email sent successfully'
  //     };
  //   } on FirebaseAuthException catch (e) {
  //     throw _handleFirebaseAuthError(e);
  //   }
  // }
  Future<Map<String, dynamic>> forgotPassword({required String email}) async {
    try {
      print('📧 RemoteDataSource - Attempting to send password reset to: $email');

      // تنظيف البريد الإلكتروني
      final cleanEmail = email.trim().toLowerCase();
      print('📧 Cleaned email: $cleanEmail');

      // إرسال رابط إعادة التعيين
      await _auth.sendPasswordResetEmail(email: cleanEmail);

      print('✅ RemoteDataSource - Password reset email sent successfully');

      return {
        'success': true,
        'message': 'Password reset email sent successfully'
      };
    } on FirebaseAuthException catch (e) {
      print('❌ RemoteDataSource - FirebaseAuthException: ${e.code} - ${e.message}');

      // معالجة الأخطاء المختلفة
      switch (e.code) {
        case 'user-not-found':
          print('⚠️ User not found for email: $email');
          return {
            'success': true,
            'message': 'إذا كان البريد موجوداً، سيتم إرسال رابط إعادة التعيين'
          };
        case 'invalid-email':
          throw Exception('البريد الإلكتروني غير صالح\nInvalid email address');
        case 'too-many-requests':
          throw Exception('محاولات كثيرة جداً. حاول مرة أخرى بعد قليل\nToo many requests. Try again later');
        default:
          throw _handleFirebaseAuthError(e);
      }
    } catch (e) {
      print('💥 RemoteDataSource - Unexpected error: $e');
      throw Exception('فشل إرسال رابط إعادة التعيين: ${e.toString()}');
    }
  }


  /// Refresh Token
  Future<Map<String, dynamic>> refreshToken({required String refreshToken}) async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        throw Exception('No user logged in');
      }

      final newToken = await user.getIdToken(true);

      return {
        'success': true,
        'data': {
          'access_token': newToken ?? '',
          'refresh_token': newToken ?? '',
        }
      };
    } catch (e) {
      throw Exception('Token refresh failed: ${e.toString()}');
    }
  }

  /// Logout
  Future<Map<String, dynamic>> logout() async {
    try {
      await _auth.signOut();
      return {'success': true};
    } catch (e) {
      throw Exception('Logout failed: ${e.toString()}');
    }
  }

  /// Update user profile
  Future<Map<String, dynamic>> updateProfile({
    String? name,
    String? phone,
    String? university,
    String? major,
    int? yearOfStudy,
    File? profileImage,
  }) async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        throw Exception('No user logged in');
      }

      // Upload new profile image if provided
      String? profileImageUrl;
      if (profileImage != null) {
        profileImageUrl = await _uploadProfileImage(user.uid, profileImage);
        await user.updatePhotoURL(profileImageUrl);
      }

      // Update display name in Firebase Auth
      if (name != null) {
        await user.updateDisplayName(name);
      }

      await user.reload();

      // Update Firestore
      final updates = <String, dynamic>{
        'updated_at': FieldValue.serverTimestamp(),
      };

      if (name != null) updates['name'] = name.trim();
      if (phone != null) updates['phone'] = phone.trim();
      if (university != null) updates['university'] = university.trim();
      if (major != null) updates['major'] = major.trim();
      if (yearOfStudy != null) updates['year_of_study'] = yearOfStudy;
      if (profileImageUrl != null) updates['profile_image_url'] = profileImageUrl;

      await _firestore
          .collection(_usersCollection)
          .doc(user.uid)
          .update(updates);

      final String? token = await user.getIdToken();

      return {
        'success': true,
        'data': {
          'access_token': token ?? '',
          'user': {
            'id': user.uid,
            'email': user.email ?? '',
            'name': name ?? user.displayName ?? '',
            'phone': phone ?? '',
            'university': university,
            'major': major,
            'year_of_study': yearOfStudy,
            'profile_image_url': profileImageUrl ?? user.photoURL,
            'updated_at': DateTime.now().toIso8601String(),
          }
        }
      };
    } on FirebaseAuthException catch (e) {
      throw _handleFirebaseAuthError(e);
    } catch (e) {
      throw Exception('Profile update failed: ${e.toString()}');
    }
  }

  /// Change password
  Future<Map<String, dynamic>> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      final user = _auth.currentUser;
      if (user == null || user.email == null) {
        throw Exception('No user logged in');
      }

      final credential = EmailAuthProvider.credential(
        email: user.email!,
        password: currentPassword,
      );

      await user.reauthenticateWithCredential(credential);
      await user.updatePassword(newPassword);

      return {
        'success': true,
        'message': 'Password updated successfully'
      };
    } on FirebaseAuthException catch (e) {
      throw _handleFirebaseAuthError(e);
    } catch (e) {
      throw Exception('Password change failed: ${e.toString()}');
    }
  }

  /// Verify email
  Future<Map<String, dynamic>> verifyEmail() async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        throw Exception('No user logged in');
      }

      await user.sendEmailVerification();

      return {
        'success': true,
        'message': 'Verification email sent successfully'
      };
    } on FirebaseAuthException catch (e) {
      throw _handleFirebaseAuthError(e);
    }
  }

  /// Delete account
  Future<Map<String, dynamic>> deleteAccount({required String password}) async {
    try {
      final user = _auth.currentUser;
      if (user == null || user.email == null) {
        throw Exception('No user logged in');
      }

      final credential = EmailAuthProvider.credential(
        email: user.email!,
        password: password,
      );

      await user.reauthenticateWithCredential(credential);

      // Delete profile image from Storage
      try {
        final storageRef = _storage.ref().child('$_profileImagesPath/${user.uid}.jpg');
        await storageRef.delete();
      } catch (e) {
        throw Exception('Failed to delete profile image: ${e.toString()}');
      }

      // Delete Firestore document
      await _firestore.collection(_usersCollection).doc(user.uid).delete();

      // Delete Firebase Auth account
      await user.delete();

      return {
        'success': true,
        'message': 'Account deleted successfully'
      };
    } on FirebaseAuthException catch (e) {
      throw _handleFirebaseAuthError(e);
    } catch (e) {
      throw Exception('Account deletion failed: ${e.toString()}');
    }
  }

  /// Check if user is verified
  Future<bool> isEmailVerified() async {
    final user = _auth.currentUser;
    if (user == null) return false;

    await user.reload();
    return user.emailVerified;
  }

  /// Get current Firebase user
  User? getCurrentFirebaseUser() {
    return _auth.currentUser;
  }

  /// Handle Firebase Auth errors with localized messages
  Exception _handleFirebaseAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return Exception('لم يتم العثور على حساب بهذا البريد الإلكتروني\nNo account found with this email');
      case 'wrong-password':
        return Exception('كلمة المرور غير صحيحة\nIncorrect password');
      case 'invalid-email':
        return Exception('البريد الإلكتروني غير صالح\nInvalid email address');
      case 'user-disabled':
        return Exception('تم تعطيل هذا الحساب\nThis account has been disabled');
      case 'email-already-in-use':
        return Exception('يوجد حساب بهذا البريد الإلكتروني بالفعل\nAn account with this email already exists');
      case 'weak-password':
        return Exception('كلمة المرور ضعيفة جداً\nPassword is too weak');
      case 'operation-not-allowed':
        return Exception('العملية غير مسموح بها\nOperation not allowed');
      case 'too-many-requests':
        return Exception('محاولات كثيرة جداً. حاول مرة أخرى لاحقاً\nToo many requests. Please try again later');
      case 'requires-recent-login':
        return Exception('يجب تسجيل الدخول مرة أخرى\nPlease login again to continue');
      case 'invalid-credential':
        return Exception('بيانات الاعتماد غير صالحة\nInvalid credentials');
      case 'account-exists-with-different-credential':
        return Exception('يوجد حساب بنفس البريد الإلكتروني باستخدام طريقة تسجيل دخول مختلفة\nAccount exists with different sign-in method');
      default:
        return Exception('خطأ في المصادقة: ${e.message}\nAuthentication error: ${e.message}');
    }
  }
}