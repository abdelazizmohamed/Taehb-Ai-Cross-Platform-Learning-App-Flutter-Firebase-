import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

/// Local data source for storing user data and tokens using SharedPreferences
class LocalDataSource {
  static const String _keyAccessToken = 'access_token';
  static const String _keyRefreshToken = 'refresh_token';
  static const String _keyUserData = 'user_data';
  static const String _keyRememberMe = 'remember_me';
  static const String _keyLanguage = 'language';
  static const String _keyTheme = 'theme';

  /// Save access token
  Future<void> saveToken(String token) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyAccessToken, token);
    } catch (e) {
      rethrow;
    }
  }

  /// Get access token
  Future<String?> getToken() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString(_keyAccessToken);
      return token;
    } catch (e) {
      return null;
    }
  }

  /// Clear access token
  Future<void> clearToken() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_keyAccessToken);
    } catch (e) {
      rethrow;
    }
  }

  /// Save refresh token
  Future<void> saveRefreshToken(String token) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyRefreshToken, token);
    } catch (e) {
      rethrow;
    }
  }

  /// Get refresh token
  Future<String?> getRefreshToken() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyRefreshToken);
    } catch (e) {
      return null;
    }
  }

  /// Clear refresh token
  Future<void> clearRefreshToken() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_keyRefreshToken);
    } catch (e) {
      rethrow;
    }
  }

  /// Save user data as JSON
  Future<void> saveUserData(Map<String, dynamic> userData) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userDataJson = jsonEncode(userData);
      await prefs.setString(_keyUserData, userDataJson);
    } catch (e) {
      rethrow;
    }
  }

  /// Get user data
  Future<Map<String, dynamic>?> getUserData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userDataJson = prefs.getString(_keyUserData);

      if (userDataJson != null && userDataJson.isNotEmpty) {
        final userData = jsonDecode(userDataJson) as Map<String, dynamic>;
        return userData;
      }

      return null;
    } catch (e) {
      return null;
    }
  }

  /// Clear user data
  Future<void> clearUserData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_keyUserData);
    } catch (e) {
      rethrow;
    }
  }

  /// Save remember me preference
  Future<void> saveRememberMe(bool rememberMe) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyRememberMe, rememberMe);
    } catch (e) {
      rethrow;
    }
  }

  /// Get remember me preference
  Future<bool> getRememberMe() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_keyRememberMe) ?? false;
    } catch (e) {
      return false;
    }
  }

  /// Save language preference
  Future<void> saveLanguage(String language) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyLanguage, language);
    } catch (e) {
      rethrow;
    }
  }

  /// Get language preference
  Future<String?> getLanguage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyLanguage);
    } catch (e) {
      return null;
    }
  }

  /// Save theme preference
  Future<void> saveTheme(String theme) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyTheme, theme);
    } catch (e) {
      rethrow;
    }
  }

  /// Get theme preference
  Future<String?> getTheme() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyTheme);
    } catch (e) {
      return null;
    }
  }

  /// Clear all data (logout)
  Future<void> clearAll() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
    } catch (e) {
      rethrow;
    }
  }

  /// Check if user is logged in (has token and user data)
  Future<bool> isLoggedIn() async {
    try {
      final token = await getToken();
      final userData = await getUserData();
      return token != null && userData != null;
    } catch (e) {
      return false;
    }
  }
}