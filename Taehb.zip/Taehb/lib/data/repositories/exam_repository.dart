import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:taehb/data/models/exam_result_model.dart';
import 'package:taehb/data/models/question.dart';

class ExamRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<bool> saveExamResult({
    required String userId,
    required String selectedKU, // تغيير من List إلى String
    required List<Question> questions,
  }) async {
    try {
      final answeredQuestions = questions.where((q) => q.selectedAnswer != null).toList();
      final correctAnswers = answeredQuestions.where((q) => q.isCorrect == true).length;
      final wrongAnswers = answeredQuestions.where((q) => q.isCorrect == false).length;
      final unanswered = questions.length - answeredQuestions.length;
      final scorePercentage = answeredQuestions.isEmpty
          ? 0.0
          : (correctAnswers / questions.length) * 100;

      // تحويل الأسئلة إلى QuestionAttempt objects
      final questionAttempts = questions.map((q) {
        return QuestionAttempt(
          questionNumber: q.questionNumber ?? 0,
          questionText: q.questionText,
          options: q.options,
          correctAnswer: q.correctAnswerText,
          selectedAnswer: q.selectedAnswer,
          isCorrect: q.isCorrect ?? false,
          learningOutcome: q.learningOutcome,
        );
      }).toList();

      // إنشاء نتيجة الاختبار
      final docRef = _firestore.collection('exam_results').doc();
      final examResult = ExamResultModel(
        id: docRef.id,
        userId: userId,
        attemptDate: DateTime.now(),
        selectedKU: selectedKU, // تغيير من selectedKUs
        totalQuestions: questions.length,
        correctAnswers: correctAnswers,
        wrongAnswers: wrongAnswers,
        unanswered: unanswered,
        scorePercentage: scorePercentage,
        questionAttempts: questionAttempts,
      );

      // الحفظ في Firestore
      await docRef.set(examResult.toJson());
      return true;
    } catch (e) {
      print('❌ ExamRepository - Error saving exam result: $e');
      return false;
    }
  }

  /// الحصول على جميع نتائج الاختبارات للمستخدم
  Future<List<ExamResultModel>> getUserExamResults(String userId) async {
    try {
      final querySnapshot = await _firestore
          .collection('exam_results')
          .where('user_id', isEqualTo: userId)
          .orderBy('attempt_date', descending: true)
          .get();

      return querySnapshot.docs
          .map((doc) => ExamResultModel.fromJson(doc.data()))
          .toList();
    } catch (e) {
      print('❌ ExamRepository - Error fetching exam results: $e');
      return [];
    }
  }

  /// الحصول على نتيجة اختبار محددة بواسطة ID
  Future<ExamResultModel?> getExamResultById(String resultId) async {
    try {
      final doc = await _firestore
          .collection('exam_results')
          .doc(resultId)
          .get();

      if (doc.exists && doc.data() != null) {
        return ExamResultModel.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      print('❌ ExamRepository - Error fetching exam result: $e');
      return null;
    }
  }

  /// الحصول على إحصائيات المستخدم
  Future<Map<String, dynamic>> getUserStatistics(String userId) async {
    try {
      final results = await getUserExamResults(userId);

      if (results.isEmpty) {
        return {
          'total_attempts': 0,
          'average_score': 0.0,
          'best_score': 0.0,
          'total_questions_answered': 0,
          'total_correct_answers': 0,
        };
      }

      final totalAttempts = results.length;
      final averageScore = results
          .map((r) => r.scorePercentage)
          .reduce((a, b) => a + b) / totalAttempts;
      final bestScore = results
          .map((r) => r.scorePercentage)
          .reduce((a, b) => a > b ? a : b);
      final totalQuestionsAnswered = results
          .map((r) => r.totalQuestions - r.unanswered)
          .reduce((a, b) => a + b);
      final totalCorrectAnswers = results
          .map((r) => r.correctAnswers)
          .reduce((a, b) => a + b);

      return {
        'total_attempts': totalAttempts,
        'average_score': averageScore,
        'best_score': bestScore,
        'total_questions_answered': totalQuestionsAnswered,
        'total_correct_answers': totalCorrectAnswers,
      };
    } catch (e) {
      print('❌ ExamRepository - Error calculating statistics: $e');
      return {};
    }
  }

  /// حذف نتيجة اختبار
  Future<bool> deleteExamResult(String resultId) async {
    try {
      await _firestore.collection('exam_results').doc(resultId).delete();
      return true;
    } catch (e) {
      print('❌ ExamRepository - Error deleting exam result: $e');
      return false;
    }
  }

  /// الحصول على نتائج الاختبارات حسب الوحدة المعرفية
  Future<List<ExamResultModel>> getExamResultsByKU(String userId, String kuId) async {
    try {
      final querySnapshot = await _firestore
          .collection('exam_results')
          .where('user_id', isEqualTo: userId)
          .where('selected_ku', isEqualTo: kuId)
          .orderBy('attempt_date', descending: true)
          .get();

      return querySnapshot.docs
          .map((doc) => ExamResultModel.fromJson(doc.data()))
          .toList();
    } catch (e) {
      print('❌ ExamRepository - Error fetching exam results by KU: $e');
      return [];
    }
  }
}