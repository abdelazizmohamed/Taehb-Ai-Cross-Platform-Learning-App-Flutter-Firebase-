import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../datasources/local_data_source.dart';
import '../datasources/remote_datasource.dart';
import '../models/user_model.dart';

class AuthRepository {
  final RemoteDataSource _remoteDataSource;
  final LocalDataSource _localDataSource;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  AuthRepository(this._remoteDataSource, this._localDataSource);

  Future<UserModel?> login(
      String email,
      String password,
      bool rememberMe,
      ) async {
    try {

      final firebaseUser = await _remoteDataSource.login(
        email: email,
        password: password,
      );

      if (firebaseUser == null) {
        return null;
      }


      // Get user data from Firestore
      final userDoc = await _firestore
          .collection('users')
          .doc(firebaseUser.uid)
          .get();

      UserModel user;
      if (userDoc.exists && userDoc.data() != null) {
        user = UserModel.fromJson(userDoc.data()!);
      } else {
        user = UserModel.fromFirebaseUser(firebaseUser);
      }

      // Save tokens and user data locally if remember me is enabled
      if (rememberMe) {
        final token = await firebaseUser.getIdToken();
        if (token != null) {
          await _localDataSource.saveToken(token);
        }
        await _localDataSource.saveUserData(user.toJson());
      }

      return user;
    } catch (e) {
      print('💥 AuthRepository.login - Exception: $e');
      rethrow;
    }
  }

  /// Register user with profile image support
  Future<UserModel?> register({
    required String name,
    required String email,
    required String password,
    String? phone,
    String? university,
    String? major,
    int? yearOfStudy,
    File? profileImage,
  }) async {
    try {
      final response = await _remoteDataSource.register(
        name: name,
        email: email,
        password: password,
        phone: phone,
        university: university,
        major: major,
        yearOfStudy: yearOfStudy,
        profileImage: profileImage,
      );

      if (response['success'] == true && response['data'] != null) {

        final userData = response['data']['user'];
        final user = UserModel.fromJson(userData);

        // Save tokens and user data locally
        final token = response['data']['access_token'];
        if (token != null && token.isNotEmpty) {
          await _localDataSource.saveToken(token);
        }
        await _localDataSource.saveUserData(user.toJson());

        return user;
      }

      print('❌ AuthRepository.register - Registration failed');
      return null;
    } catch (e) {
      print('💥 AuthRepository.register - Exception: $e');
      rethrow;
    }
  }

  /// Sign in with Google
  Future<UserModel?> signInWithGoogle() async {
    try {
      // Implementation would go here
      throw UnimplementedError('Google sign-in not yet implemented');
    } catch (e) {
      rethrow;
    }
  }

  /// Sign in with Apple
  Future<UserModel?> signInWithApple() async {
    try {
      // Implementation would go here
      throw UnimplementedError('Apple sign-in not yet implemented');
    } catch (e) {
      rethrow;
    }
  }

  /// Logout user
  Future<void> logout() async {
    try {
      await _remoteDataSource.logout();
      await _localDataSource.clearUserData();
      await _localDataSource.clearToken();
    } catch (e) {
      rethrow;
    }
  }

  /// Forgot password
  Future<bool> forgotPassword({required String email}) async {
    try {
      final response = await _remoteDataSource.forgotPassword(email: email);
      return response['success'] == true;
    } catch (e) {
      rethrow;
    }
  }

  /// Refresh token
  Future<bool> refreshToken() async {
    try {
      final currentToken = await _localDataSource.getToken();
      if (currentToken == null) return false;

      final response = await _remoteDataSource.refreshToken(
        refreshToken: currentToken,
      );

      if (response['success'] == true && response['data'] != null) {
        final newToken = response['data']['access_token'];
        if (newToken != null) {
          await _localDataSource.saveToken(newToken);
          return true;
        }
      }

      return false;
    } catch (e) {
      return false;
    }
  }

  /// Check if user is logged in
  Future<bool> isUserLoggedIn() async {
    try {
      final token = await _localDataSource.getToken();
      final userData = await _localDataSource.getUserData();
      return token != null && userData != null;
    } catch (e) {
      print('❌ AuthRepository.isUserLoggedIn error: $e');
      return false;
    }
  }

  /// Get current user
  Future<UserModel?> getCurrentUser() async {
    try {
      final firebaseUser = _remoteDataSource.getCurrentFirebaseUser();
      if (firebaseUser == null) return null;

      // Try to get from Firestore first
      final userDoc = await _firestore
          .collection('users')
          .doc(firebaseUser.uid)
          .get();

      if (userDoc.exists && userDoc.data() != null) {
        return UserModel.fromJson(userDoc.data()!);
      }

      // Fallback to local storage
      final userData = await _localDataSource.getUserData();
      if (userData != null) {
        return UserModel.fromJson(userData);
      }

      // Last resort: create from Firebase user
      return UserModel.fromFirebaseUser(firebaseUser);
    } catch (e) {
      print('❌ AuthRepository.getCurrentUser - Error: $e');
      return null;
    }
  }

  /// Update user profile
  Future<UserModel?> updateProfile({
    String? name,
    String? phone,
    String? university,
    String? major,
    int? yearOfStudy,
    File? profileImage,
  }) async {
    try {
      final response = await _remoteDataSource.updateProfile(
        name: name,
        phone: phone,
        university: university,
        major: major,
        yearOfStudy: yearOfStudy,
        profileImage: profileImage,
      );

      if (response['success'] == true && response['data'] != null) {
        final userData = response['data']['user'];
        final user = UserModel.fromJson(userData);

        // Update local storage
        await _localDataSource.saveUserData(user.toJson());

        return user;
      }

      return null;
    } catch (e) {
      rethrow;
    }
  }

  /// Change password
  Future<bool> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      final response = await _remoteDataSource.changePassword(
        currentPassword: currentPassword,
        newPassword: newPassword,
      );
      return response['success'] == true;
    } catch (e) {
      rethrow;
    }
  }

  /// Verify email
  Future<bool> verifyEmail() async {
    try {
      final response = await _remoteDataSource.verifyEmail();
      return response['success'] == true;
    } catch (e) {
      rethrow;
    }
  }

  /// Delete account
  Future<bool> deleteAccount({required String password}) async {
    try {
      final response = await _remoteDataSource.deleteAccount(password: password);
      if (response['success'] == true) {
        await _localDataSource.clearUserData();
        await _localDataSource.clearToken();
        return true;
      }
      return false;
    } catch (e) {
      rethrow;
    }
  }

  /// Check if email is verified
  Future<bool> isEmailVerified() async {
    try {
      return await _remoteDataSource.isEmailVerified();
    } catch (e) {
      return false;
    }
  }
}