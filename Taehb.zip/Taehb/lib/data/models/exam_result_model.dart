class ExamResultModel {
  final String id;
  final String userId;
  final DateTime attemptDate;
  final String selectedKU; // تغيير من List إلى String واحد
  final int totalQuestions;
  final int correctAnswers;
  final int wrongAnswers;
  final int unanswered;
  final double scorePercentage;
  final List<QuestionAttempt> questionAttempts;

  ExamResultModel({
    required this.id,
    required this.userId,
    required this.attemptDate,
    required this.selectedKU,
    required this.totalQuestions,
    required this.correctAnswers,
    required this.wrongAnswers,
    required this.unanswered,
    required this.scorePercentage,
    required this.questionAttempts,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'attempt_date': attemptDate.toIso8601String(),
      'selected_ku': selectedKU, // تغيير من selected_kus
      'total_questions': totalQuestions,
      'correct_answers': correctAnswers,
      'wrong_answers': wrongAnswers,
      'unanswered': unanswered,
      'score_percentage': scorePercentage,
      'question_attempts': questionAttempts.map((q) => q.toJson()).toList(),
    };
  }

  factory ExamResultModel.fromJson(Map<String, dynamic> json) {
    return ExamResultModel(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? '',
      attemptDate: DateTime.parse(json['attempt_date']),
      selectedKU: json['selected_ku'] ?? '', // تغيير من selected_kus
      totalQuestions: json['total_questions'] ?? 0,
      correctAnswers: json['correct_answers'] ?? 0,
      wrongAnswers: json['wrong_answers'] ?? 0,
      unanswered: json['unanswered'] ?? 0,
      scorePercentage: (json['score_percentage'] ?? 0).toDouble(),
      questionAttempts: (json['question_attempts'] as List?)
          ?.map((q) => QuestionAttempt.fromJson(q))
          .toList() ??
          [],
    );
  }
}

class QuestionAttempt {
  final int questionNumber;
  final String questionText;
  final List<String> options;
  final String correctAnswer;
  final String? selectedAnswer;
  final bool isCorrect;
  final String? learningOutcome; // إضافة Learning Outcome

  QuestionAttempt({
    required this.questionNumber,
    required this.questionText,
    required this.options,
    required this.correctAnswer,
    this.selectedAnswer,
    required this.isCorrect,
    this.learningOutcome,
  });

  Map<String, dynamic> toJson() {
    return {
      'question_number': questionNumber,
      'question_text': questionText,
      'options': options,
      'correct_answer': correctAnswer,
      'selected_answer': selectedAnswer,
      'is_correct': isCorrect,
      'learning_outcome': learningOutcome,
    };
  }

  factory QuestionAttempt.fromJson(Map<String, dynamic> json) {
    return QuestionAttempt(
      questionNumber: json['question_number'] ?? 0,
      questionText: json['question_text'] ?? '',
      options: List<String>.from(json['options'] ?? []),
      correctAnswer: json['correct_answer'] ?? '',
      selectedAnswer: json['selected_answer'],
      isCorrect: json['is_correct'] ?? false,
      learningOutcome: json['learning_outcome'],
    );
  }
}