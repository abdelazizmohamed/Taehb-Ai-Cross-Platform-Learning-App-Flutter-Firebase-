import 'package:cloud_firestore/cloud_firestore.dart';


class Question {
  final String id;
  final String unitId;
  final String questionText;
  final List<String> options;
  final int correctAnswerIndex;

  final String? explanation;
  final int? pointValue;
  final int? difficulty;
  final DateTime? createdAt;

  String? selectedAnswer;
  bool? isCorrect;
  String? learningOutcome;
  int? questionNumber;


  String get correctAnswerText => options.isNotEmpty && correctAnswerIndex < options.length
      ? options[correctAnswerIndex]
      : '';

  Question({
    required this.id,
    required this.unitId,
    required this.questionText,
    required this.options,
    required this.correctAnswerIndex,
    this.explanation,
    this.pointValue,
    this.difficulty,
    this.createdAt,
    this.selectedAnswer,
    this.isCorrect,
    this.learningOutcome,
    this.questionNumber,
  });

  /// Factory for Firestore questions (existing system)
  factory Question.fromFirestore(Map<String, dynamic> map, String id) {
    return Question(
      id: id,
      unitId: map['unitId'] ?? '',
      questionText: map['questionText'] ?? '',
      options: List<String>.from(map['options'] ?? []),
      correctAnswerIndex: map['correctAnswerIndex'] ?? 0,
      explanation: map['explanation'],
      pointValue: map['pointValue'] ?? 10,
      difficulty: map['difficulty'] ?? 1,
      createdAt: map['createdAt'] != null
          ? (map['createdAt'] as Timestamp).toDate()
          : null,
      learningOutcome: map['learningOutcome'], // Support LO if stored
    );
  }

  /// Factory for AI-generated questions (new system)
  /// This is what we parse from backend response
  factory Question.fromAIGenerated({
    required int number,
    required String text,
    required List<String> options,
    required String correctAnswer,
    required String unitId,
    String? learningOutcome,
  }) {
    // Find the index of correct answer
    int correctIndex = 0;
    for (int i = 0; i < options.length; i++) {
      if (options[i].trim().toLowerCase() == correctAnswer.trim().toLowerCase() ||
          options[i].contains(correctAnswer) ||
          correctAnswer.contains(options[i])) {
        correctIndex = i;
        break;
      }
    }

    return Question(
      id: 'ai_q_$number', // Generate temporary ID
      unitId: unitId,
      questionText: text,
      options: options,
      correctAnswerIndex: correctIndex,
      questionNumber: number,
      learningOutcome: learningOutcome,
      pointValue: 10, // Default for AI questions
      difficulty: 3, // Default medium difficulty
    );
  }

  /// Convert to Firestore map (for existing system)
  Map<String, dynamic> toFirestore() {
    return {
      'unitId': unitId,
      'questionText': questionText,
      'options': options,
      'correctAnswerIndex': correctAnswerIndex,
      'explanation': explanation,
      'pointValue': pointValue,
      'difficulty': difficulty,
      'createdAt': createdAt != null
          ? Timestamp.fromDate(createdAt!)
          : FieldValue.serverTimestamp(),
      'learningOutcome': learningOutcome,
    };
  }

  /// Convert to JSON (for API calls and local storage)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'unitId': unitId,
      'questionText': questionText,
      'options': options,
      'correctAnswerIndex': correctAnswerIndex,
      'explanation': explanation,
      'pointValue': pointValue,
      'difficulty': difficulty,
      'createdAt': createdAt?.toIso8601String(),
      'selectedAnswer': selectedAnswer,
      'isCorrect': isCorrect,
      'learningOutcome': learningOutcome,
      'questionNumber': questionNumber,
    };
  }

  /// Factory from JSON
  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['id'] ?? '',
      unitId: json['unitId'] ?? '',
      questionText: json['questionText'] ?? '',
      options: List<String>.from(json['options'] ?? []),
      correctAnswerIndex: json['correctAnswerIndex'] ?? 0,
      explanation: json['explanation'],
      pointValue: json['pointValue'],
      difficulty: json['difficulty'],
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'])
          : null,
      selectedAnswer: json['selectedAnswer'],
      isCorrect: json['isCorrect'],
      learningOutcome: json['learningOutcome'],
      questionNumber: json['questionNumber'],
    );
  }

  /// Copy with method for updating fields
  Question copyWith({
    String? id,
    String? unitId,
    String? questionText,
    List<String>? options,
    int? correctAnswerIndex,
    String? explanation,
    int? pointValue,
    int? difficulty,
    DateTime? createdAt,
    String? selectedAnswer,
    bool? isCorrect,
    String? learningOutcome,
    int? questionNumber,
  }) {
    return Question(
      id: id ?? this.id,
      unitId: unitId ?? this.unitId,
      questionText: questionText ?? this.questionText,
      options: options ?? this.options,
      correctAnswerIndex: correctAnswerIndex ?? this.correctAnswerIndex,
      explanation: explanation ?? this.explanation,
      pointValue: pointValue ?? this.pointValue,
      difficulty: difficulty ?? this.difficulty,
      createdAt: createdAt ?? this.createdAt,
      selectedAnswer: selectedAnswer,
      isCorrect: isCorrect,
      learningOutcome: learningOutcome ?? this.learningOutcome,
      questionNumber: questionNumber ?? this.questionNumber,
    );
  }

  /// Check if answer is selected
  bool get hasAnswer => selectedAnswer != null;

  /// Get selected answer index
  int? get selectedAnswerIndex {
    if (selectedAnswer == null) return null;
    return options.indexWhere((option) => option == selectedAnswer);
  }

  /// Check if user answered correctly
  void checkAnswer(String answer) {
    selectedAnswer = answer;
    final answerIndex = options.indexOf(answer);
    isCorrect = answerIndex == correctAnswerIndex;
  }

  @override
  String toString() {
    return 'Question(#$questionNumber: $questionText, LO: $learningOutcome, Correct: $isCorrect)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Question && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}