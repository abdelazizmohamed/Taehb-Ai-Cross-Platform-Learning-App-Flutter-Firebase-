import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents a knowledge unit/topic in the quiz system
class KnowledgeUnit {
  final String id;
  final String title;
  final String description;
  final String category;
  final int difficulty; // 1-5 scale
  final int questionCount;
  final String iconName;
  final bool isAdvanced;
  final DateTime createdAt;

  KnowledgeUnit({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.difficulty,
    required this.questionCount,
    required this.iconName,
    required this.isAdvanced,
    required this.createdAt,
  });

  /// Create KnowledgeUnit from Firestore document
  factory KnowledgeUnit.fromMap(Map<String, dynamic> map, String id) {
    return KnowledgeUnit(
      id: id,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      category: map['category'] ?? '',
      difficulty: map['difficulty'] ?? 1,
      questionCount: map['questionCount'] ?? 0,
      iconName: map['iconName'] ?? 'book',
      isAdvanced: map['isAdvanced'] ?? false,
      createdAt: map['createdAt'] != null
          ? (map['createdAt'] as Timestamp).toDate()
          : DateTime.now(),
    );
  }

  /// Create KnowledgeUnit from Firestore DocumentSnapshot
  factory KnowledgeUnit.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return KnowledgeUnit.fromMap(data, doc.id);
  }

  /// Convert KnowledgeUnit to Firestore map
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'category': category,
      'difficulty': difficulty,
      'questionCount': questionCount,
      'iconName': iconName,
      'isAdvanced': isAdvanced,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  /// Create a copy with updated fields
  KnowledgeUnit copyWith({
    String? id,
    String? title,
    String? description,
    String? category,
    int? difficulty,
    int? questionCount,
    String? iconName,
    bool? isAdvanced,
    DateTime? createdAt,
  }) {
    return KnowledgeUnit(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      difficulty: difficulty ?? this.difficulty,
      questionCount: questionCount ?? this.questionCount,
      iconName: iconName ?? this.iconName,
      isAdvanced: isAdvanced ?? this.isAdvanced,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  /// Get difficulty label
  String get difficultyLabel {
    switch (difficulty) {
      case 1:
        return 'Very Easy';
      case 2:
        return 'Easy';
      case 3:
        return 'Medium';
      case 4:
        return 'Hard';
      case 5:
        return 'Very Hard';
      default:
        return 'Unknown';
    }
  }

  /// Get difficulty color
  /// Can be used in UI to color-code difficulty levels
  String get difficultyColorHex {
    switch (difficulty) {
      case 1:
        return '#4CAF50'; // Green
      case 2:
        return '#8BC34A'; // Light Green
      case 3:
        return '#FFC107'; // Amber
      case 4:
        return '#FF9800'; // Orange
      case 5:
        return '#F44336'; // Red
      default:
        return '#9E9E9E'; // Grey
    }
  }

  @override
  String toString() {
    return 'KnowledgeUnit(id: $id, title: $title, category: $category, '
        'difficulty: $difficulty, isAdvanced: $isAdvanced, '
        'questionCount: $questionCount)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is KnowledgeUnit &&
        other.id == id &&
        other.title == title &&
        other.description == description &&
        other.category == category &&
        other.difficulty == difficulty &&
        other.questionCount == questionCount &&
        other.iconName == iconName &&
        other.isAdvanced == isAdvanced;
  }

  @override
  int get hashCode {
    return id.hashCode ^
    title.hashCode ^
    description.hashCode ^
    category.hashCode ^
    difficulty.hashCode ^
    questionCount.hashCode ^
    iconName.hashCode ^
    isAdvanced.hashCode;
  }
}