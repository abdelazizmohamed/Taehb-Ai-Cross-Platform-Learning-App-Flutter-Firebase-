import 'package:cloud_firestore/cloud_firestore.dart';

class QuizSession {
  final String id;
  final String userId;
  final List<String> selectedUnitIds; // Keep as list for backward compatibility
  final List<String> questionIds;
  final Map<String, int> unitQuestionDistribution; // unitId: question count
  final DateTime startedAt;
  final DateTime? completedAt;
  final int totalQuestions;
  final int answeredQuestions;
  final int correctAnswers;
  final int totalPoints;
  final String status; // 'in_progress', 'completed', 'abandoned'

  // NEW: Learning Outcomes tracking
  final Map<String, dynamic>? learningOutcomesPerformance; // LO.1: {correct: 3, total: 5}
  final bool? isAIGenerated; // Track if questions were AI-generated

  QuizSession({
    required this.id,
    required this.userId,
    required this.selectedUnitIds,
    required this.questionIds,
    required this.unitQuestionDistribution,
    required this.startedAt,
    this.completedAt,
    required this.totalQuestions,
    required this.answeredQuestions,
    required this.correctAnswers,
    required this.totalPoints,
    required this.status,
    this.learningOutcomesPerformance,
    this.isAIGenerated,
  });

  /// Helper: Get primary knowledge unit (for single KU system)
  String get primaryKnowledgeUnit => selectedUnitIds.isNotEmpty
      ? selectedUnitIds.first
      : '';

  /// Helper: Check if this is a single-KU session
  bool get isSingleUnit => selectedUnitIds.length == 1;

  /// Calculate score percentage
  double get scorePercentage {
    if (totalQuestions == 0) return 0.0;
    return (correctAnswers / totalQuestions) * 100;
  }

  /// Get completion duration
  Duration? get duration {
    if (completedAt == null) return null;
    return completedAt!.difference(startedAt);
  }

  factory QuizSession.fromFirestore(Map<String, dynamic> map, String id) {
    return QuizSession(
      id: id,
      userId: map['userId'] ?? '',
      selectedUnitIds: List<String>.from(map['selectedUnitIds'] ?? []),
      questionIds: List<String>.from(map['questionIds'] ?? []),
      unitQuestionDistribution: Map<String, int>.from(
          map['unitQuestionDistribution'] ?? {}
      ),
      startedAt: map['startedAt'] != null
          ? (map['startedAt'] as Timestamp).toDate()
          : DateTime.now(),
      completedAt: map['completedAt'] != null
          ? (map['completedAt'] as Timestamp).toDate()
          : null,
      totalQuestions: map['totalQuestions'] ?? 0,
      answeredQuestions: map['answeredQuestions'] ?? 0,
      correctAnswers: map['correctAnswers'] ?? 0,
      totalPoints: map['totalPoints'] ?? 0,
      status: map['status'] ?? 'in_progress',
      learningOutcomesPerformance: map['learningOutcomesPerformance'],
      isAIGenerated: map['isAIGenerated'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'selectedUnitIds': selectedUnitIds,
      'questionIds': questionIds,
      'unitQuestionDistribution': unitQuestionDistribution,
      'startedAt': Timestamp.fromDate(startedAt),
      'completedAt': completedAt != null
          ? Timestamp.fromDate(completedAt!)
          : null,
      'totalQuestions': totalQuestions,
      'answeredQuestions': answeredQuestions,
      'correctAnswers': correctAnswers,
      'totalPoints': totalPoints,
      'status': status,
      'learningOutcomesPerformance': learningOutcomesPerformance,
      'isAIGenerated': isAIGenerated,
    };
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'selectedUnitIds': selectedUnitIds,
      'questionIds': questionIds,
      'unitQuestionDistribution': unitQuestionDistribution,
      'startedAt': startedAt.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'totalQuestions': totalQuestions,
      'answeredQuestions': answeredQuestions,
      'correctAnswers': correctAnswers,
      'totalPoints': totalPoints,
      'status': status,
      'learningOutcomesPerformance': learningOutcomesPerformance,
      'isAIGenerated': isAIGenerated,
    };
  }

  factory QuizSession.fromJson(Map<String, dynamic> json) {
    return QuizSession(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      selectedUnitIds: List<String>.from(json['selectedUnitIds'] ?? []),
      questionIds: List<String>.from(json['questionIds'] ?? []),
      unitQuestionDistribution: Map<String, int>.from(
          json['unitQuestionDistribution'] ?? {}
      ),
      startedAt: json['startedAt'] != null
          ? DateTime.parse(json['startedAt'])
          : DateTime.now(),
      completedAt: json['completedAt'] != null
          ? DateTime.parse(json['completedAt'])
          : null,
      totalQuestions: json['totalQuestions'] ?? 0,
      answeredQuestions: json['answeredQuestions'] ?? 0,
      correctAnswers: json['correctAnswers'] ?? 0,
      totalPoints: json['totalPoints'] ?? 0,
      status: json['status'] ?? 'in_progress',
      learningOutcomesPerformance: json['learningOutcomesPerformance'],
      isAIGenerated: json['isAIGenerated'],
    );
  }

  QuizSession copyWith({
    String? id,
    String? userId,
    List<String>? selectedUnitIds,
    List<String>? questionIds,
    Map<String, int>? unitQuestionDistribution,
    DateTime? startedAt,
    DateTime? completedAt,
    int? totalQuestions,
    int? answeredQuestions,
    int? correctAnswers,
    int? totalPoints,
    String? status,
    Map<String, dynamic>? learningOutcomesPerformance,
    bool? isAIGenerated,
  }) {
    return QuizSession(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      selectedUnitIds: selectedUnitIds ?? this.selectedUnitIds,
      questionIds: questionIds ?? this.questionIds,
      unitQuestionDistribution: unitQuestionDistribution ?? this.unitQuestionDistribution,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
      totalQuestions: totalQuestions ?? this.totalQuestions,
      answeredQuestions: answeredQuestions ?? this.answeredQuestions,
      correctAnswers: correctAnswers ?? this.correctAnswers,
      totalPoints: totalPoints ?? this.totalPoints,
      status: status ?? this.status,
      learningOutcomesPerformance: learningOutcomesPerformance ?? this.learningOutcomesPerformance,
      isAIGenerated: isAIGenerated ?? this.isAIGenerated,
    );
  }

  @override
  String toString() {
    return 'QuizSession(id: $id, units: $selectedUnitIds, score: $correctAnswers/$totalQuestions, status: $status)';
  }
}