import 'package:cloud_firestore/cloud_firestore.dart';

class LeaderboardEntry {
  final String userId;
  final String displayName;
  final int totalPoints;
  final int currentLevel;
  final int rank;
  final int totalSessions;
  final int distinctUnitsCount;
  final DateTime lastUpdated;

  LeaderboardEntry({
    required this.userId,
    required this.displayName,
    required this.totalPoints,
    required this.currentLevel,
    required this.rank,
    required this.totalSessions,
    required this.distinctUnitsCount,
    required this.lastUpdated,
  });

  factory LeaderboardEntry.fromMap(Map<String, dynamic> map) {
    return LeaderboardEntry(
      userId: map['userId'] ?? '',
      displayName: map['displayName'] ?? '',
      totalPoints: map['totalPoints'] ?? 0,
      currentLevel: map['currentLevel'] ?? 1,
      rank: map['rank'] ?? 0,
      totalSessions: map['totalSessions'] ?? 0,
      distinctUnitsCount: map['distinctUnitsCount'] ?? 0,
      lastUpdated: (map['lastUpdated'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'displayName': displayName,
      'totalPoints': totalPoints,
      'currentLevel': currentLevel,
      'rank': rank,
      'totalSessions': totalSessions,
      'distinctUnitsCount': distinctUnitsCount,
      'lastUpdated': Timestamp.fromDate(lastUpdated),
    };
  }
}
