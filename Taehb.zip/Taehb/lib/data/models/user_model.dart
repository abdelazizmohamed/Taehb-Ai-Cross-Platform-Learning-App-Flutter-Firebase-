import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// User data model representing a user in the application
class UserModel {
  final String id;
  final String email;
  final String name;
  final String? phone;
  final String? university;
  final String? major;
  final int? yearOfStudy;
  final String? profileImageUrl;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final DateTime? lastActive;

  // Gamification fields
  final int totalPoints;
  final int currentLevel;
  final List<String> unlockedUnits;
  final List<String> completedSessions;
  final Map<String, int> unitProgress;

  UserModel({
    required this.id,
    required this.email,
    required this.name,
    this.phone,
    this.university,
    this.major,
    this.yearOfStudy,
    this.profileImageUrl,
    this.createdAt,
    this.updatedAt,
    this.lastActive,
    this.totalPoints = 0,
    this.currentLevel = 0,
    this.unlockedUnits = const [],
    this.completedSessions = const [],
    this.unitProgress = const {},
  });

  /// Create UserModel from Firestore map
  factory UserModel.fromMap(Map<String, dynamic> map, String id) {
    // Helper function to convert Timestamp to DateTime
    DateTime? _convertToDateTime(dynamic value) {
      if (value == null) return null;
      if (value is Timestamp) return value.toDate();
      if (value is String) return DateTime.tryParse(value);
      return null;
    }

    return UserModel(
      id: id,
      email: map['email'] ?? '',
      name: map['name'] ?? map['displayName'] ?? '',
      phone: map['phone'],
      university: map['university'],
      major: map['major'],
      yearOfStudy: map['year_of_study'] ?? map['yearOfStudy'],
      profileImageUrl: map['profile_image_url'] ?? map['profileImageUrl'],
      createdAt: _convertToDateTime(map['created_at'] ?? map['createdAt']),
      updatedAt: _convertToDateTime(map['updated_at'] ?? map['updatedAt']),
      lastActive: _convertToDateTime(map['last_active'] ?? map['lastActive']),
      totalPoints: map['totalPoints'] ?? map['total_points'] ?? 0,
      currentLevel: map['currentLevel'] ?? map['current_level'] ?? 0,
      unlockedUnits: List<String>.from(map['unlockedUnits'] ?? map['unlocked_units'] ?? []),
      completedSessions: List<String>.from(map['completedSessions'] ?? map['completed_sessions'] ?? []),
      unitProgress: Map<String, int>.from(map['unitProgress'] ?? map['unit_progress'] ?? {}),
    );
  }

  /// Create UserModel from JSON
  factory UserModel.fromJson(Map<String, dynamic> json) {
    try {
      print('🔍 UserModel.fromJson - Parsing user data...');
      print('📦 Raw JSON: $json');

      // Helper function to convert various date formats to DateTime
      DateTime? _convertToDateTime(dynamic value) {
        if (value == null) return null;
        if (value is Timestamp) return value.toDate();
        if (value is String) return DateTime.tryParse(value);
        if (value is DateTime) return value;
        return null;
      }

      return UserModel(
        id: json['id']?.toString() ?? '',
        email: json['email']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        phone: json['phone']?.toString(),
        university: json['university']?.toString(),
        major: json['major']?.toString(),
        yearOfStudy: json['year_of_study'] != null
            ? int.tryParse(json['year_of_study'].toString())
            : null,
        profileImageUrl: json['profile_image_url']?.toString(),
        createdAt: _convertToDateTime(json['created_at']),
        updatedAt: _convertToDateTime(json['updated_at']),
        lastActive: _convertToDateTime(json['last_active']),
        totalPoints: json['totalPoints'] ?? json['total_points'] ?? 0,
        currentLevel: json['currentLevel'] ?? json['current_level'] ?? 0,
        unlockedUnits: List<String>.from(json['unlockedUnits'] ?? json['unlocked_units'] ?? []),
        completedSessions: List<String>.from(json['completedSessions'] ?? json['completed_sessions'] ?? []),
        unitProgress: Map<String, int>.from(json['unitProgress'] ?? json['unit_progress'] ?? {}),
      );
    } catch (e) {
      print('❌ UserModel.fromJson - Error parsing: $e');
      print('📦 JSON data: $json');
      rethrow;
    }
  }

  /// Create UserModel from Firebase User (fallback when Firestore data is unavailable)
  factory UserModel.fromFirebaseUser(User user) {
    return UserModel(
      id: user.uid,
      email: user.email ?? '',
      name: user.displayName ?? '',
      phone: user.phoneNumber,
      profileImageUrl: user.photoURL,
      createdAt: user.metadata.creationTime,
      updatedAt: DateTime.now(),
      lastActive: DateTime.now(),
    );
  }

  /// Convert UserModel to map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'name': name,
      'phone': phone,
      'university': university,
      'major': major,
      'year_of_study': yearOfStudy,
      'profile_image_url': profileImageUrl,
      'created_at': createdAt != null ? Timestamp.fromDate(createdAt!) : FieldValue.serverTimestamp(),
      'updated_at': updatedAt != null ? Timestamp.fromDate(updatedAt!) : FieldValue.serverTimestamp(),
      'last_active': lastActive != null ? Timestamp.fromDate(lastActive!) : FieldValue.serverTimestamp(),
      'totalPoints': totalPoints,
      'currentLevel': currentLevel,
      'unlockedUnits': unlockedUnits,
      'completedSessions': completedSessions,
      'unitProgress': unitProgress,
    };
  }

  /// Convert UserModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'name': name,
      'phone': phone,
      'university': university,
      'major': major,
      'year_of_study': yearOfStudy,
      'profile_image_url': profileImageUrl,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
      'last_active': lastActive?.toIso8601String(),
      'totalPoints': totalPoints,
      'currentLevel': currentLevel,
      'unlockedUnits': unlockedUnits,
      'completedSessions': completedSessions,
      'unitProgress': unitProgress,
    };
  }

  /// Gamification getters
  int get distinctUnitsCount => unitProgress.keys.length;
  bool get canAccessAdvancedTests => distinctUnitsCount >= 5;

  int calculateLevel(int points) {
    if (points >= 250) return 2;
    if (points >= 100) return 1;
    return 0;
  }

  /// Create a copy of UserModel with updated fields
  UserModel copyWith({
    String? id,
    String? email,
    String? name,
    String? phone,
    String? university,
    String? major,
    int? yearOfStudy,
    String? profileImageUrl,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? lastActive,
    int? totalPoints,
    int? currentLevel,
    List<String>? unlockedUnits,
    List<String>? completedSessions,
    Map<String, int>? unitProgress,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      university: university ?? this.university,
      major: major ?? this.major,
      yearOfStudy: yearOfStudy ?? this.yearOfStudy,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      lastActive: lastActive ?? this.lastActive,
      totalPoints: totalPoints ?? this.totalPoints,
      currentLevel: currentLevel ?? this.currentLevel,
      unlockedUnits: unlockedUnits ?? this.unlockedUnits,
      completedSessions: completedSessions ?? this.completedSessions,
      unitProgress: unitProgress ?? this.unitProgress,
    );
  }

  @override
  String toString() {
    return 'UserModel(id: $id, email: $email, name: $name, phone: $phone, '
        'university: $university, major: $major, yearOfStudy: $yearOfStudy, '
        'profileImageUrl: $profileImageUrl, totalPoints: $totalPoints, '
        'currentLevel: $currentLevel)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is UserModel &&
        other.id == id &&
        other.email == email &&
        other.name == name &&
        other.phone == phone &&
        other.university == university &&
        other.major == major &&
        other.yearOfStudy == yearOfStudy &&
        other.profileImageUrl == profileImageUrl &&
        other.totalPoints == totalPoints &&
        other.currentLevel == currentLevel;
  }

  @override
  int get hashCode {
    return id.hashCode ^
    email.hashCode ^
    name.hashCode ^
    phone.hashCode ^
    university.hashCode ^
    major.hashCode ^
    yearOfStudy.hashCode ^
    profileImageUrl.hashCode ^
    totalPoints.hashCode ^
    currentLevel.hashCode;
  }
}