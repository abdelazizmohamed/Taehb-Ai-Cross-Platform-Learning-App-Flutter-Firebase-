import 'package:cloud_firestore/cloud_firestore.dart';

class Attempt {
  final String id;
  final String sessionId;
  final String userId;
  final String questionId;
  final String unitId;
  final int selectedAnswerIndex;
  final bool isCorrect;
  final int pointsEarned;
  final DateTime answeredAt;
  final int timeSpentSeconds;

  Attempt({
    required this.id,
    required this.sessionId,
    required this.userId,
    required this.questionId,
    required this.unitId,
    required this.selectedAnswerIndex,
    required this.isCorrect,
    required this.pointsEarned,
    required this.answeredAt,
    required this.timeSpentSeconds,
  });

  factory Attempt.fromMap(Map<String, dynamic> map, String id) {
    return Attempt(
      id: id,
      sessionId: map['sessionId'] ?? '',
      userId: map['userId'] ?? '',
      questionId: map['questionId'] ?? '',
      unitId: map['unitId'] ?? '',
      selectedAnswerIndex: map['selectedAnswerIndex'] ?? -1,
      isCorrect: map['isCorrect'] ?? false,
      pointsEarned: map['pointsEarned'] ?? 0,
      answeredAt: (map['answeredAt'] as Timestamp).toDate(),
      timeSpentSeconds: map['timeSpentSeconds'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'sessionId': sessionId,
      'userId': userId,
      'questionId': questionId,
      'unitId': unitId,
      'selectedAnswerIndex': selectedAnswerIndex,
      'isCorrect': isCorrect,
      'pointsEarned': pointsEarned,
      'answeredAt': Timestamp.fromDate(answeredAt),
      'timeSpentSeconds': timeSpentSeconds,
    };
  }
}
