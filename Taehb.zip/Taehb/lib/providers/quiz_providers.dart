import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:taehb/data/models/user_model.dart';
import '../services/user_service.dart';
import '../services/leaderboard_service.dart';
import '../data/models/knowledge_unit.dart';
import '../data/models/quiz_session.dart';
import '../data/models/question.dart';
import '../data/models/leaderboard_entry.dart';
import '../config/app_config.dart';
import '../data/knowledge_units_config.dart';
import 'app_providers.dart';


final userServiceProvider = Provider((ref) => UserService());
final leaderboardServiceProvider = Provider((ref) => LeaderboardService());

// Auth state
final authStateProvider = StreamProvider<User?>((ref) {
  return FirebaseAuth.instance.authStateChanges();
});

// Current user profile
final currentUserProvider = StreamProvider<UserModel?>((ref) {
  final authAsync = ref.watch(authStateProvider);

  return authAsync.when(
    data: (user) {
      if (user == null) {
        return Stream.value(null);
      }
      final userService = ref.read(userServiceProvider);
      return userService.streamUserProfile(user.uid);
    },
    loading: () => Stream.value(null),
    error: (_, __) => Stream.value(null),
  );
});

// Knowledge units - can be from backend or local config
final knowledgeUnitsProvider = FutureProvider<List<KnowledgeUnit>>((ref) async {
  final quizService = ref.read(quizServiceProvider);
  final user = ref.watch(currentUserProvider).value;
  
  // Check if user can access advanced tests
  bool includeAdvanced = false;
  if (user != null) {
    includeAdvanced = user.canAccessAdvancedTests;
  }
  
  try {
    // Try to get from service (Firestore or config)
    return await quizService.getKnowledgeUnits(includeAdvanced: includeAdvanced);
  } catch (e) {
    print('Error loading knowledge units: $e');
    // Fallback to local config
    final units = KnowledgeUnitsConfig.defaultUnits;
    if (!includeAdvanced) {
      return units.where((unit) => !unit.isAdvanced).toList();
    }
    return units;
  }
});

// Selected units for quiz
final selectedUnitsProvider = StateNotifierProvider<SelectedUnitsNotifier, List<String>>((ref) {
  return SelectedUnitsNotifier();
});

class SelectedUnitsNotifier extends StateNotifier<List<String>> {
  SelectedUnitsNotifier() : super([]);
  
  void toggleUnit(String unitId) {
    if (state.contains(unitId)) {
      state = state.where((id) => id != unitId).toList();
    } else if (state.length < AppConfig.maxUnitsPerSession) {
      state = [...state, unitId];
    }
  }
  
  void clear() {
    state = [];
  }
  
  bool canAdd() => state.length < AppConfig.maxUnitsPerSession;
  bool canStartQuiz() => state.isNotEmpty;
}

// Current quiz session
final currentSessionProvider = StateProvider<QuizSession?>((ref) => null);

// Quiz questions (could be AI-generated or from Firestore)
final sessionQuestionsProvider = FutureProvider.family<List<Question>, String>((ref, sessionId) async {
  final quizService = ref.read(quizServiceProvider);
  return quizService.getSessionQuestions(sessionId);
});

// Quiz configuration
final quizConfigProvider = StateProvider<QuizConfig>((ref) => QuizConfig(
  useAI: AppConfig.useAIGeneratedQuestions,
  questionsPerSession: AppConfig.defaultQuestionsPerSession,
  cacheQuestions: AppConfig.cacheGeneratedQuestions,
));

class QuizConfig {
  final bool useAI;
  final int questionsPerSession;
  final bool cacheQuestions;
  
  QuizConfig({
    required this.useAI,
    required this.questionsPerSession,
    required this.cacheQuestions,
  });
  
  QuizConfig copyWith({
    bool? useAI,
    int? questionsPerSession,
    bool? cacheQuestions,
  }) {
    return QuizConfig(
      useAI: useAI ?? this.useAI,
      questionsPerSession: questionsPerSession ?? this.questionsPerSession,
      cacheQuestions: cacheQuestions ?? this.cacheQuestions,
    );
  }
}

// Quiz state management
final quizStateProvider = StateNotifierProvider<QuizStateNotifier, QuizState>((ref) {
  return QuizStateNotifier(ref);
});

class QuizState {
  final int currentQuestionIndex;
  final Map<String, int> answers;
  final Map<String, bool> results;
  final int totalPoints;
  final DateTime? startTime;
  final bool isGeneratingQuestions;
  final String? generationError;
  
  QuizState({
    this.currentQuestionIndex = 0,
    this.answers = const {},
    this.results = const {},
    this.totalPoints = 0,
    this.startTime,
    this.isGeneratingQuestions = false,
    this.generationError,
  });
  
  QuizState copyWith({
    int? currentQuestionIndex,
    Map<String, int>? answers,
    Map<String, bool>? results,
    int? totalPoints,
    DateTime? startTime,
    bool? isGeneratingQuestions,
    String? generationError,
  }) {
    return QuizState(
      currentQuestionIndex: currentQuestionIndex ?? this.currentQuestionIndex,
      answers: answers ?? this.answers,
      results: results ?? this.results,
      totalPoints: totalPoints ?? this.totalPoints,
      startTime: startTime ?? this.startTime,
      isGeneratingQuestions: isGeneratingQuestions ?? this.isGeneratingQuestions,
      generationError: generationError == '' ? null : (generationError ?? this.generationError),
    );
  }
}

class QuizStateNotifier extends StateNotifier<QuizState> {
  final Ref ref;
  
  QuizStateNotifier(this.ref) : super(QuizState());
  
  void startQuiz() {
    state = QuizState(startTime: DateTime.now());
  }
  
  void setGeneratingQuestions(bool generating) {
    state = state.copyWith(isGeneratingQuestions: generating);
  }
  
  void setGenerationError(String? error) {
    state = state.copyWith(generationError: error);
  }
  
  void selectAnswer(String questionId, int answerIndex) {
    state = state.copyWith(
      answers: {...state.answers, questionId: answerIndex},
    );
  }
  
  Future<void> submitAnswer(Question question, int answerIndex) async {
    final isCorrect = answerIndex == question.correctAnswerIndex;
    final int? pointsEarned = isCorrect ? question.pointValue : 0;
    
    state = state.copyWith(
      results: {...state.results, question.id: isCorrect},
      totalPoints: state.totalPoints + pointsEarned!,
    );
    
    // Submit to backend
    final session = ref.read(currentSessionProvider);
    if (session != null) {
      final quizService = ref.read(quizServiceProvider);
      final authState = ref.read(authStateProvider).value;
      
      if (authState != null) {
        final timeSpent = state.startTime != null 
          ? DateTime.now().difference(state.startTime!).inSeconds 
          : 0;
        
        await quizService.submitAnswer(
          sessionId: session.id,
          userId: authState.uid,
          questionId: question.id,
          unitId: question.unitId,
          selectedAnswerIndex: answerIndex,
          isCorrect: isCorrect,
          pointsEarned: pointsEarned,
          timeSpentSeconds: timeSpent ~/ (state.currentQuestionIndex + 1),
        );
      }
    }
  }
  
  void nextQuestion() {
    state = state.copyWith(
      currentQuestionIndex: state.currentQuestionIndex + 1,
    );
  }
  
  void reset() {
    state = QuizState();
  }
}

// Leaderboard
final leaderboardProvider = StreamProvider<List<LeaderboardEntry>>((ref) {
  final leaderboardService = ref.read(leaderboardServiceProvider);
  return leaderboardService.streamLeaderboard();
});

// User statistics
final userStatisticsProvider = FutureProvider.family<Map<String, dynamic>, String>((ref, userId) async {
  final userService = ref.read(userServiceProvider);
  return userService.getUserStatistics(userId);
});

// Initialize knowledge units in Firestore (run once)
final initializeKnowledgeUnitsProvider = FutureProvider<void>((ref) async {
  final quizService = ref.read(quizServiceProvider);
  await quizService.getKnowledgeUnits();
});
