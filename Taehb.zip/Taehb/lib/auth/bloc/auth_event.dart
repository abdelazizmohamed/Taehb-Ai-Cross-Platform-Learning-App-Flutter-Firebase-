import 'dart:io';
import 'package:equatable/equatable.dart';

abstract class AuthEvent extends Equatable {
  const AuthEvent();

  @override
  List<Object?> get props => [];
}

class CheckAuthStatus extends AuthEvent {
  const CheckAuthStatus();
}

class LoginRequested extends AuthEvent {
  final String email;
  final String password;
  final bool rememberMe;

  const LoginRequested({
    required this.email,
    required this.password,
    this.rememberMe = false,
  });

  @override
  List<Object?> get props => [email, password, rememberMe];
}

class RegisterRequested extends AuthEvent {
  final String name;
  final String email;
  final String password;
  final String? phone;
  final String? university;
  final String? major;
  final int? yearOfStudy;
  final File? profileImage;

  const RegisterRequested({
    required this.name,
    required this.email,
    required this.password,
    this.phone,
    this.university,
    this.major,
    this.yearOfStudy,
    this.profileImage,
  });

  @override
  List<Object?> get props => [
    name,
    email,
    password,
    phone,
    university,
    major,
    yearOfStudy,
    profileImage,
  ];
}
class UpdateProfileRequested extends AuthEvent {
  final String? name;
  final String? phone;
  final String? university;
  final String? major;
  final int? yearOfStudy;
  final File? profileImage;

  const UpdateProfileRequested({
    this.name,
    this.phone,
    this.university,
    this.major,
    this.yearOfStudy,
    this.profileImage,
  });

  @override
  List<Object?> get props => [
    name,
    phone,
    university,
    major,
    yearOfStudy,
    profileImage,
  ];
}

class LogoutRequested extends AuthEvent {
  const LogoutRequested();
}

class ForgotPasswordRequested extends AuthEvent {
  final String email;

  const ForgotPasswordRequested({required this.email});

  @override
  List<Object?> get props => [email];
}
class ChangePasswordRequested extends AuthEvent {
  final String currentPassword;
  final String newPassword;

  const ChangePasswordRequested({
    required this.currentPassword,
    required this.newPassword,
  });

  @override
  List<Object?> get props => [currentPassword, newPassword];
}

class RefreshTokenRequested extends AuthEvent {
  const RefreshTokenRequested();
}

class GoogleSignInRequested extends AuthEvent {
  const GoogleSignInRequested();
}

class AppleSignInRequested extends AuthEvent {
  const AppleSignInRequested();
}