import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/repositories/auth_repository.dart';
import '../../data/models/user_model.dart';
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository _authRepository;

  AuthBloc(this._authRepository) : super(AuthInitial()) {
    on<CheckAuthStatus>(_onCheckAuthStatus);
    on<LoginRequested>(_onLoginRequested);
    on<RegisterRequested>(_onRegisterRequested);
    on<UpdateProfileRequested>(_onUpdateProfileRequested);
    on<LogoutRequested>(_onLogoutRequested);
    on<ForgotPasswordRequested>(_onForgotPasswordRequested);
    on<RefreshTokenRequested>(_onRefreshTokenRequested);
    on<GoogleSignInRequested>(_onGoogleSignInRequested);
    on<AppleSignInRequested>(_onAppleSignInRequested);
    on<ChangePasswordRequested>(_onChangePasswordRequested);
  }

  /// Check if user is already authenticated (auto-login)
  Future<void> _onCheckAuthStatus(
      CheckAuthStatus event,
      Emitter<AuthState> emit,
      ) async {
    try {
      emit(AuthLoading());

      final isAuthenticated = await _authRepository.isUserLoggedIn();

      if (isAuthenticated) {
        final user = await _authRepository.getCurrentUser();
        if (user != null) {
          emit(AuthAuthenticated(user: user));
        } else {
          emit(AuthUnauthenticated());
        }
      } else {
        emit(AuthUnauthenticated());
      }
    } catch (e) {
      emit(AuthError(message: 'Failed to check authentication status: ${e.toString()}'));
    }
  }

  /// Handle user login
  Future<void> _onLoginRequested(
      LoginRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      print('🔐 AuthBloc._onLoginRequested - Starting login...');
      emit(const AuthLoading());
      print('⏳ AuthBloc - Emitted AuthLoading state');

      final user = await _authRepository.login(
        event.email,
        event.password,
        event.rememberMe,
      );

      print('👤 AuthBloc - Received user from repository: ${user?.email}');

      if (user != null) {
        print('✅ AuthBloc - Emitting AuthAuthenticated state');
        emit(AuthAuthenticated(user: user));
        print('✅ AuthBloc - AuthAuthenticated state emitted successfully');
      } else {
        print('❌ AuthBloc - User is null, emitting error');
        emit(const AuthError(message: 'Login failed. Please check your credentials.'));
      }
    } catch (e) {
      print('AuthBloc - Exception occurred: $e');
      emit(AuthError(message: _getErrorMessage(e.toString())));
    }
  }

  /// Handle user registration with profile image
  Future<void> _onRegisterRequested(
      RegisterRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      print('📝 AuthBloc._onRegisterRequested - Starting registration...');
      emit(AuthLoading());

      final user = await _authRepository.register(
        name: event.name,
        email: event.email,
        password: event.password,
        phone: event.phone,
        university: event.university,
        major: event.major,
        yearOfStudy: event.yearOfStudy,
        profileImage: event.profileImage,
      );

      if (user != null) {
        print('✅ AuthBloc - Registration successful, emitting authenticated state');
        emit(AuthAuthenticated(user: user));
      } else {
        print('❌ AuthBloc - Registration returned null user');
        emit(AuthError(message: 'Registration failed. Please try again.'));
      }
    } catch (e) {
      print('💥 AuthBloc - Registration exception: $e');
      emit(AuthError(message: _getErrorMessage(e.toString())));
    }
  }

  /// Handle profile update
  Future<void> _onUpdateProfileRequested(
      UpdateProfileRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      print('📝 AuthBloc._onUpdateProfileRequested - Starting profile update...');

      // Keep current state while loading
      final currentUserBeforeUpdate = this.currentUser;
      emit(const AuthLoading());

      final updatedUser = await _authRepository.updateProfile(
        name: event.name,
        phone: event.phone,
        university: event.university,
        major: event.major,
        yearOfStudy: event.yearOfStudy,
        profileImage: event.profileImage,
      );

      if (updatedUser != null) {
        print('✅ AuthBloc - Profile updated successfully');
        emit(AuthAuthenticated(user: updatedUser));
      } else {
        print('❌ AuthBloc - Profile update returned null');
        // Restore previous state if update failed
        if (currentUserBeforeUpdate != null) {
          emit(AuthAuthenticated(user: currentUserBeforeUpdate));
        }
        emit(const AuthError(message: 'Failed to update profile. Please try again.'));
      }
    } catch (e) {
      print('💥 AuthBloc - Profile update exception: $e');
      emit(AuthError(message: _getErrorMessage(e.toString())));
    }
  }

  /// Handle Google Sign-In
  Future<void> _onGoogleSignInRequested(
      GoogleSignInRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      emit(const AuthLoading());

      final user = await _authRepository.signInWithGoogle();

      if (user != null) {
        emit(AuthAuthenticated(user: user));
      } else {
        emit(const AuthError(message: 'Google sign-in failed. Please try again.'));
      }
    } catch (e) {
      emit(AuthError(message: _getErrorMessage(e.toString())));
    }
  }

  /// Handle password change
  Future<void> _onChangePasswordRequested(
      ChangePasswordRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      // Store current user before loading state
      final currentUserBeforeChange = this.currentUser;

      emit(const AuthLoading());

      final success = await _authRepository.changePassword(
        currentPassword: event.currentPassword,
        newPassword: event.newPassword,
      );

      if (success) {
        emit(const PasswordChanged());
        // Restore authenticated state with current user
        if (currentUserBeforeChange != null) {
          emit(AuthAuthenticated(user: currentUserBeforeChange));
        }
      } else {
        emit(const AuthError(message: 'Failed to change password'));
        // Restore authenticated state even on failure
        if (currentUserBeforeChange != null) {
          emit(AuthAuthenticated(user: currentUserBeforeChange));
        }
      }
    } catch (e) {
      // Store user before emitting error
      final currentUserOnError = this.currentUser;

      emit(AuthError(message: _getErrorMessage(e.toString())));

      // Restore authenticated state with current user even on error
      if (currentUserOnError != null) {
        emit(AuthAuthenticated(user: currentUserOnError));
      }
    }
  }

  /// Handle Apple Sign-In
  Future<void> _onAppleSignInRequested(
      AppleSignInRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      emit(const AuthLoading());

      final user = await _authRepository.signInWithApple();

      if (user != null) {
        emit(AuthAuthenticated(user: user));
      } else {
        emit(const AuthError(message: 'Apple sign-in failed. Please try again.'));
      }
    } catch (e) {
      emit(AuthError(message: _getErrorMessage(e.toString())));
    }
  }

  /// Handle user logout
  Future<void> _onLogoutRequested(
      LogoutRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      emit(AuthLoading());

      await _authRepository.logout();
      emit(AuthUnauthenticated());
    } catch (e) {
      emit(AuthError(message: 'Logout failed: ${e.toString()}'));
    }
  }

  /// Handle forgot password
  Future<void> _onForgotPasswordRequested(
      ForgotPasswordRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      emit(AuthLoading());

      final success = await _authRepository.forgotPassword(email: event.email);

      if (success) {
        emit(ForgotPasswordSuccess(
          message: 'Password reset email sent successfully. Please check your inbox.',
        ));
      } else {
        emit(AuthError(message: 'Failed to send password reset email.'));
      }
    } catch (e) {
      emit(AuthError(message: _getErrorMessage(e.toString())));
    }
  }

  /// Handle token refresh
  Future<void> _onRefreshTokenRequested(
      RefreshTokenRequested event,
      Emitter<AuthState> emit,
      ) async {
    try {
      final success = await _authRepository.refreshToken();

      if (!success) {
        emit(AuthUnauthenticated());
      }
    } catch (e) {
      emit(AuthUnauthenticated());
    }
  }

  /// Convert error messages to user-friendly messages
  String _getErrorMessage(String error) {
    if (error.contains('network')) {
      return 'Please check your internet connection and try again.';
    } else if (error.contains('timeout')) {
      return 'Request timeout. Please try again.';
    } else if (error.contains('401') || error.contains('unauthorized')) {
      return 'Invalid credentials. Please check your email and password.';
    } else if (error.contains('403') || error.contains('forbidden')) {
      return 'Access denied. Please contact support.';
    } else if (error.contains('404')) {
      return 'Service not found. Please try again later.';
    } else if (error.contains('500')) {
      return 'Server error. Please try again later.';
    } else if (error.contains('email-already-in-use')) {
      return 'An account with this email already exists.';
    } else if (error.contains('weak-password')) {
      return 'Password is too weak. Please choose a stronger password.';
    } else if (error.contains('invalid-email')) {
      return 'Please enter a valid email address.';
    } else if (error.contains('user-not-found')) {
      return 'No account found with this email address.';
    } else if (error.contains('wrong-password')) {
      return 'Incorrect password. Please try again.';
    } else if (error.contains('user-disabled')) {
      return 'This account has been disabled. Please contact support.';
    } else if (error.contains('too-many-requests')) {
      return 'Too many failed attempts. Please try again later.';
    } else if (error.contains('cancelled')) {
      return 'Sign-in cancelled by user.';
    } else {
      return 'Something went wrong. Please try again.';
    }
  }

  /// Get current authenticated user
  UserModel? get currentUser {
    if (state is AuthAuthenticated) {
      return (state as AuthAuthenticated).user;
    }
    return null;
  }

  /// Check if user is currently authenticated
  bool get isAuthenticated => state is AuthAuthenticated;

  /// Check if authentication is in loading state
  bool get isLoading => state is AuthLoading;
}