import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'language_event.dart';
import 'language_state.dart';

class LanguageBloc extends Bloc<LanguageEvent, LanguageState> {
  static const String _languageKey = 'selected_language';

  LanguageBloc() : super(const LanguageState(locale: Locale('en'))) {
    on<ChangeLanguage>(_onChangeLanguage);
    on<LoadSavedLanguage>(_onLoadSavedLanguage);
  }

  Future<void> _onChangeLanguage(
      ChangeLanguage event,
      Emitter<LanguageState> emit,
      ) async {
    try {
      final newLocale = Locale(event.languageCode);

      // Save to shared preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_languageKey, event.languageCode);

      emit(LanguageState(locale: newLocale));

      print('✅ Language changed to: ${event.languageCode}');
    } catch (e) {
      print('❌ Error changing language: $e');
    }
  }

  Future<void> _onLoadSavedLanguage(
      LoadSavedLanguage event,
      Emitter<LanguageState> emit,
      ) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedLanguage = prefs.getString(_languageKey);

      if (savedLanguage != null) {
        emit(LanguageState(locale: Locale(savedLanguage)));
        print('✅ Loaded saved language: $savedLanguage');
      } else {
        print('ℹ️ No saved language found, using default: en');
      }
    } catch (e) {
      print('❌ Error loading saved language: $e');
    }
  }
}