import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:taehb/services/activity_helper.dart';
import 'package:uuid/uuid.dart';
import '../data/models/knowledge_unit.dart';
import '../data/models/question.dart';
import '../data/models/quiz_session.dart';
import '../data/models/attempt.dart';

class QuizService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final Uuid _uuid = const Uuid();

  static const int DEFAULT_QUESTIONS_PER_SESSION = 15;
  static const int MAX_UNITS_PER_SESSION = 1;

  Future<List<KnowledgeUnit>> getKnowledgeUnits({bool includeAdvanced = false}) async {
    Query query = _firestore.collection('knowledge_units');

    if (!includeAdvanced) {
      query = query.where('isAdvanced', isEqualTo: false);
    }

    final snapshot = await query.get();
    return snapshot.docs.map((doc) =>
        KnowledgeUnit.fromMap(doc.data() as Map<String, dynamic>, doc.id)
    ).toList();
  }

  /// Create a new quiz session for a SINGLE knowledge unit
  Future<QuizSession> createQuizSession({
    required String userId,
    required String unitId,
    int totalQuestions = DEFAULT_QUESTIONS_PER_SESSION,
  }) async {
    if (unitId.isEmpty) {
      throw Exception('Must select a knowledge unit');
    }

    // Fetch questions for the unit
    final questions = await _getQuestionsForUnit(unitId, totalQuestions);

    if (questions.isEmpty) {
      throw Exception('No questions found for this unit');
    }

    // Shuffle questions
    questions.shuffle();

    final sessionId = _uuid.v4();
    final session = QuizSession(
      id: sessionId,
      userId: userId,
      selectedUnitIds: [unitId], // قائمة بعنصر واحد للتوافق مع الـ model الحالي
      questionIds: questions.map((q) => q.id).toList(),
      unitQuestionDistribution: {unitId: questions.length},
      startedAt: DateTime.now(),
      completedAt: null,
      totalQuestions: questions.length,
      answeredQuestions: 0,
      correctAnswers: 0,
      totalPoints: 0,
      status: 'in_progress',
    );

    // Save session to Firestore
    await _firestore.collection('quiz_sessions').doc(sessionId).set(session.toFirestore());

    return session;
  }

  /// Get questions for a specific unit
  Future<List<Question>> _getQuestionsForUnit(String unitId, int count) async {
    try {
      final snapshot = await _firestore
          .collection('questions')
          .where('unitId', isEqualTo: unitId)
          .limit(count * 2) // Get extra for shuffling
          .get();

      if (snapshot.docs.isEmpty) {
        print('⚠️ No questions found for unit: $unitId');
        return [];
      }

      final questions = snapshot.docs.map((doc) {
        try {
          return Question.fromFirestore(doc.data(), doc.id);
        } catch (e) {
          print('❌ Error parsing question ${doc.id}: $e');
          return null;
        }
      }).whereType<Question>().toList();

      questions.shuffle();
      return questions.take(count).toList();
    } catch (e) {
      print('❌ Error fetching questions for unit $unitId: $e');
      return [];
    }
  }

  /// Get questions for current session
  Future<List<Question>> getSessionQuestions(String sessionId) async {
    try {
      final sessionDoc = await _firestore
          .collection('quiz_sessions')
          .doc(sessionId)
          .get();

      if (!sessionDoc.exists) {
        throw Exception('Session not found');
      }

      final session = QuizSession.fromFirestore(sessionDoc.data()!, sessionDoc.id);
      final List<Question> questions = [];

      for (final questionId in session.questionIds) {
        try {
          final questionDoc = await _firestore
              .collection('questions')
              .doc(questionId)
              .get();

          if (questionDoc.exists) {
            final question = Question.fromFirestore(questionDoc.data()!, questionDoc.id);
            questions.add(question);
          }
        } catch (e) {
          print('❌ Error loading question $questionId: $e');
        }
      }

      return questions;
    } catch (e) {
      print('❌ Error getting session questions: $e');
      rethrow;
    }
  }

  /// Submit an answer
  Future<Attempt> submitAnswer({
    required String sessionId,
    required String userId,
    required String questionId,
    required String unitId,
    required int selectedAnswerIndex,
    required bool isCorrect,
    required int pointsEarned,
    required int timeSpentSeconds,
  }) async {
    final attemptId = _uuid.v4();
    final attempt = Attempt(
      id: attemptId,
      sessionId: sessionId,
      userId: userId,
      questionId: questionId,
      unitId: unitId,
      selectedAnswerIndex: selectedAnswerIndex,
      isCorrect: isCorrect,
      pointsEarned: isCorrect ? pointsEarned : 0,
      answeredAt: DateTime.now(),
      timeSpentSeconds: timeSpentSeconds,
    );

    // Save attempt
    await _firestore.collection('attempts').doc(attemptId).set(attempt.toMap());

    // Update session progress
    await _updateSessionProgress(sessionId, isCorrect, pointsEarned);

    return attempt;
  }

  /// Update session progress
  Future<void> _updateSessionProgress(
      String sessionId,
      bool isCorrect,
      int pointsEarned
      ) async {
    final sessionRef = _firestore.collection('quiz_sessions').doc(sessionId);

    await _firestore.runTransaction((transaction) async {
      final sessionDoc = await transaction.get(sessionRef);

      if (!sessionDoc.exists) {
        throw Exception('Session not found');
      }

      final currentData = sessionDoc.data()!;
      final answeredQuestions = (currentData['answeredQuestions'] ?? 0) + 1;
      final correctAnswers = (currentData['correctAnswers'] ?? 0) + (isCorrect ? 1 : 0);
      final totalPoints = (currentData['totalPoints'] ?? 0) + pointsEarned;
      final totalQuestions = currentData['totalQuestions'] ?? 0;

      Map<String, dynamic> updates = {
        'answeredQuestions': answeredQuestions,
        'correctAnswers': correctAnswers,
        'totalPoints': totalPoints,
      };

      // Mark as completed if all questions answered
      if (answeredQuestions >= totalQuestions) {
        updates['status'] = 'completed';
        updates['completedAt'] = Timestamp.now();
      }

      transaction.update(sessionRef, updates);
    });
  }

  /// Complete a session
  Future<void> completeSession(String sessionId) async {
    await _firestore.collection('quiz_sessions').doc(sessionId).update({
      'status': 'completed',
      'completedAt': Timestamp.now(),
    });
    final session = await _firestore
        .collection('quiz_sessions')
        .doc(sessionId)
        .get();

    final sessionData = session.data();
    if (sessionData != null) {
      await ActivityHelper.addExamCompletedActivity(
        userId: sessionData['userId'],
        scorePercentage: (sessionData['correctAnswers'] / sessionData['totalQuestions']) * 100,
        correctAnswers: sessionData['correctAnswers'],
        totalQuestions: sessionData['totalQuestions'],
        selectedKUs: sessionData['selectedUnitIds'],
        examId: sessionId,
      );
    }
  }

  /// Get session results
  Future<Map<String, dynamic>> getSessionResults(String sessionId) async {
    final sessionDoc = await _firestore
        .collection('quiz_sessions')
        .doc(sessionId)
        .get();

    if (!sessionDoc.exists) {
      throw Exception('Session not found');
    }

    final session = QuizSession.fromFirestore(sessionDoc.data()!, sessionDoc.id);

    // Get attempts for this session
    final attemptsSnapshot = await _firestore
        .collection('attempts')
        .where('sessionId', isEqualTo: sessionId)
        .get();

    final attempts = attemptsSnapshot.docs.map((doc) =>
        Attempt.fromMap(doc.data(), doc.id)
    ).toList();

    // Calculate per-unit breakdown (for single unit)
    final Map<String, Map<String, int>> unitBreakdown = {};

    for (final unitId in session.selectedUnitIds) {
      final unitAttempts = attempts.where((a) => a.unitId == unitId).toList();
      unitBreakdown[unitId] = {
        'total': unitAttempts.length,
        'correct': unitAttempts.where((a) => a.isCorrect).length,
        'points': unitAttempts.fold(0, (sum, a) => sum + a.pointsEarned),
      };
    }

    return {
      'session': session,
      'attempts': attempts,
      'unitBreakdown': unitBreakdown,
      'totalPoints': session.totalPoints,
      'accuracy': session.answeredQuestions > 0
          ? (session.correctAnswers / session.answeredQuestions * 100).toStringAsFixed(1)
          : '0.0',
    };
  }

  /// Get user's quiz history
  Future<List<QuizSession>> getUserQuizHistory(String userId, {int limit = 10}) async {
    try {
      final snapshot = await _firestore
          .collection('quiz_sessions')
          .where('userId', isEqualTo: userId)
          .orderBy('startedAt', descending: true)
          .limit(limit)
          .get();

      return snapshot.docs.map((doc) =>
          QuizSession.fromFirestore(doc.data(), doc.id)
      ).toList();
    } catch (e) {
      print('❌ Error getting user quiz history: $e');
      return [];
    }
  }

  /// Get questions by unit ID (for testing/preview)
  Future<List<Question>> getQuestionsByUnit(String unitId, {int? limit}) async {
    try {
      Query query = _firestore
          .collection('questions')
          .where('unitId', isEqualTo: unitId);

      if (limit != null) {
        query = query.limit(limit);
      }

      final snapshot = await query.get();

      return snapshot.docs.map((doc) {
        try {
          return Question.fromFirestore(doc.data() as Map<String, dynamic>, doc.id);
        } catch (e) {
          print('❌ Error parsing question ${doc.id}: $e');
          return null;
        }
      }).whereType<Question>().toList();
    } catch (e) {
      print('❌ Error getting questions by unit: $e');
      return [];
    }
  }

  /// Check if unit has enough questions
  Future<bool> unitHasEnoughQuestions(String unitId, int requiredCount) async {
    try {
      final snapshot = await _firestore
          .collection('questions')
          .where('unitId', isEqualTo: unitId)
          .limit(requiredCount)
          .get();

      return snapshot.docs.length >= requiredCount;
    } catch (e) {
      print('❌ Error checking unit questions: $e');
      return false;
    }
  }

  /// Get question count for a unit
  Future<int> getQuestionCountForUnit(String unitId) async {
    try {
      final snapshot = await _firestore
          .collection('questions')
          .where('unitId', isEqualTo: unitId)
          .count()
          .get();

      return snapshot.count ?? 0;
    } catch (e) {
      print('❌ Error getting question count: $e');
      return 0;
    }
  }
}