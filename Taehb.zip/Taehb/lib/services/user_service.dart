import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../data/models/user_model.dart';

class UserService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  
  // Create a new user profile
  Future<UserModel> createUserProfile({
    required String uid,
    required String email,
    required String displayName,
  }) async {
    final user = UserModel(
      id: uid,
      email: email,
      name: displayName,
      totalPoints: 0,
      currentLevel: 0,
      unlockedUnits: [],
      completedSessions: [],
      createdAt: DateTime.now(),
      lastActive: DateTime.now(),
      unitProgress: {},
    );
    
    await _firestore.collection('users').doc(uid).set(user.toMap());
    return user;
  }
  
  // Get user profile
  Future<UserModel?> getUserProfile(String uid) async {
    final doc = await _firestore.collection('users').doc(uid).get();
    
    if (!doc.exists) {
      return null;
    }
    
    return UserModel.fromMap(doc.data()!, doc.id);
  }
  
  // Get current user profile
  Future<UserModel?> getCurrentUserProfile() async {
    final currentUser = _auth.currentUser;
    if (currentUser == null) return null;
    
    return getUserProfile(currentUser.uid);
  }
  
  // Update user points and level after quiz completion
  Future<void> updateUserProgress({
    required String userId,
    required int pointsEarned,
    required List<String> unitsAttempted,
    required String sessionId,
  }) async {
    final userRef = _firestore.collection('users').doc(userId);
    
    await _firestore.runTransaction((transaction) async {
      final userDoc = await transaction.get(userRef);
      
      if (!userDoc.exists) {
        throw Exception('User not found');
      }
      
      final currentData = userDoc.data()!;
      final currentPoints = currentData['totalPoints'] ?? 0;
      final newTotalPoints = currentPoints + pointsEarned;
      
      // Calculate new level
      final newLevel = _calculateLevel(newTotalPoints);
      
      // Update unit progress
      Map<String, int> unitProgress = Map<String, int>.from(
        currentData['unitProgress'] ?? {}
      );
      
      for (final unitId in unitsAttempted) {
        unitProgress[unitId] = (unitProgress[unitId] ?? 0) + 1;
      }
      
      // Add completed session
      List<String> completedSessions = List<String>.from(
        currentData['completedSessions'] ?? []
      );
      completedSessions.add(sessionId);
      
      // Update unlocked units (all attempted units are now unlocked)
      Set<String> unlockedUnits = Set<String>.from(
        currentData['unlockedUnits'] ?? []
      );
      unlockedUnits.addAll(unitsAttempted);
      
      transaction.update(userRef, {
        'totalPoints': newTotalPoints,
        'currentLevel': newLevel,
        'unitProgress': unitProgress,
        'completedSessions': completedSessions,
        'unlockedUnits': unlockedUnits.toList(),
        'lastActive': Timestamp.now(),
      });
    });
  }
  
  // Calculate user level based on points
  int _calculateLevel(int points) {
    if (points >= 250) return 2;
    if (points >= 100) return 1;
    return 0;
  }
  
  // Check if user can access advanced tests
  Future<bool> canAccessAdvancedTests(String userId) async {
    final user = await getUserProfile(userId);
    if (user == null) return false;
    
    return user.distinctUnitsCount >= 5;
  }
  
  // Get user statistics
  Future<Map<String, dynamic>> getUserStatistics(String userId) async {
    final user = await getUserProfile(userId);
    if (user == null) {
      throw Exception('User not found');
    }
    
    // Get all completed sessions
    final sessionsSnapshot = await _firestore
      .collection('quiz_sessions')
      .where('userId', isEqualTo: userId)
      .where('status', isEqualTo: 'completed')
      .orderBy('completedAt', descending: true)
      .get();
    
    final sessions = sessionsSnapshot.docs.map((doc) => doc.data()).toList();
    
    // Calculate statistics
    int totalQuizzes = sessions.length;
    int totalCorrectAnswers = 0;
    int totalQuestions = 0;
    
    for (final session in sessions) {
      totalCorrectAnswers += (session['correctAnswers'] ?? 0) as int;
      totalQuestions += (session['totalQuestions'] ?? 0) as int;
    }
    
    double averageAccuracy = totalQuestions > 0 
      ? (totalCorrectAnswers / totalQuestions * 100) 
      : 0.0;
    
    return {
      'user': user,
      'totalQuizzes': totalQuizzes,
      'totalPoints': user.totalPoints,
      'currentLevel': user.currentLevel,
      'distinctUnitsStudied': user.distinctUnitsCount,
      'averageAccuracy': averageAccuracy.toStringAsFixed(1),
      'canAccessAdvanced': user.canAccessAdvancedTests,
      'recentSessions': sessions.take(5).toList(),
    };
  }
  
  // Stream user profile changes
  Stream<UserModel?> streamUserProfile(String uid) {
    return _firestore
      .collection('users')
      .doc(uid)
      .snapshots()
      .map((snapshot) {
        if (!snapshot.exists) return null;
        return UserModel.fromMap(snapshot.data()!, snapshot.id);
      });
  }
}
