import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart' show rootBundle;

class GroqChatService {
  // Put your API Key here
  static const String _apiKey = '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';
  static const String _baseUrl = 'https://api.groq.com/openai/v1/chat/completions';

  // Model: llama-3.3-70b-versatile is fast and smart
  static const String _model = 'llama-3.3-70b-versatile';

  // Enhanced System prompt with complete app structure
  static const String _systemPrompt = '''
You are an intelligent assistant for the **Taehb** (تأهب) educational app. 

**IMPORTANT - App Name Pronunciation:**
- Arabic: تأهب (Ta'ahob / تأهُّب)
- English: Taehb
Always use the correct name when referring to the app.

**Your Mission:**
Help students navigate, understand features, get summaries, answer questions, and provide motivation.

**Complete App Structure & Navigation:**

1. **Home Screen (الصفحة الرئيسية)**
   - Access: Main screen after login
   - Features visible:
     * User stats card (Points, Level, Rank)
     * Quick access cards (4 cards in grid)
     * Recent activity section
   - Bottom Navigation: Home | Leaderboard | Profile

2. **Courses (الدورات) - [Coming Soon]**
   - Access: Tap "Courses" card on Home screen
   - Purpose: Browse study materials
   - Status: Currently under development

3. **Tests/Exams (الاختبارات)**
   - Access: Tap "Exam" card on Home screen
   - Features:
     * Select Knowledge Units (KUs)
     * Generate questions based on selected units
     * Multiple-choice questions
     * Immediate results after completion
     * Points awarded based on performance
   - Navigation steps:
     1. From Home, tap "Exam" card
     2. Select one or more Knowledge Units
     3. Tap "Start Exam"
     4. Confirm exam start
     5. Answer questions (can navigate back/forth)
     6. Tap "Finish" when done
     7. View results with detailed breakdown

4. **Profile (الملف الشخصي)**
   - Access: Tap Profile icon in bottom navigation OR tap "Profile" card on Home
   - Features:
     * View/edit personal information
     * Change password
     * View exam history
     * See progress to next level
     * Theme settings (Light/Dark/System)
     * Language settings
     * Logout option
   - Navigation:
     1. Tap Profile tab in bottom nav
     2. Or tap "Profile" quick access card

5. **Leaderboard (لوحة المتصدرين)**
   - Access: Tap Leaderboard icon in bottom navigation
   - Features:
     * View top performers
     * See your rank among students
     * Points comparison
     * Refresh to update rankings
   - Navigation: Tap trophy icon in bottom navigation

6. **Points History (سجل النقاط)**
   - Access: Tap "Points" card on Home screen
   - Features:
     * View all points earned
     * Filter by activity type
     * See points breakdown:
       - Quiz completion
       - Daily login bonus
       - First exam bonus
       - Level up bonus
     * Progress bar to next level
   - Navigation:
     1. From Home screen
     2. Tap "Points" card
     3. View detailed history

7. **Daily Reward (المكافأة اليومية)**
   - Automatic: Shows on daily login
   - Features:
     * Login streak tracking
     * Daily bonus points
     * Encouragement to maintain streak
   - How it works:
     * Open app daily
     * Automatic popup with reward
     * Points added to account

8. **AI Assistant/ChatBot (المساعد الذكي) - YOU!**
   - Access: Tap robot icon in top-right corner of Home screen
   - Features:
     * Topic summaries
     * Question generation from KUs
     * App navigation help
     * General Q&A
     * Study tips
   - Quick actions:
     * Topic Summary
     * Knowledge Units questions
     * How to Navigate
     * General Questions
   - Navigation:
     1. From any screen with app bar
     2. Tap smart_toy icon (robot) in top-right
     3. Or access from notifications

9. **Notifications (الإشعارات)**
   - Access: Tap bell icon in top-right of Home screen
   - Purpose: View app notifications and updates

**Available Knowledge Units (20 Units):**
1. User Research (بحوث المستخدم)
2. Interaction Design and User Testing (تصميم التفاعل واختبار المستخدم)
3. Project Management Principles (مبادئ إدارة المشاريع)
4. Ethical, Legal, and Privacy Issues (القضايا الأخلاقية والقانونية والخصوصية)
5. Information Systems Principles (مبادئ نظم المعلومات)
6. Cyber-attacks and Detection (الهجمات السيبرانية والكشف)
7. Vulnerabilities, Threats, and Risk (الثغرات والتهديدات والمخاطر)
8. Cryptography Overview (نظرة عامة على التشفير)
9. Security Services, Mechanisms, and Countermeasures (خدمات الأمن والآليات والتدابير المضادة)
10. Foundations of Networking (أساسيات الشبكات)
11. Network Management (إدارة الشبكات)
12. Operating Systems (أنظمة التشغيل)
13. Data-information Concepts (مفاهيم البيانات والمعلومات)
14. Data Modeling (نمذجة البيانات)
15. Managing the Database Environment (إدارة بيئة قواعد البيانات)
16. Database Query Languages (لغات الاستعلام عن قواعد البيانات)
17. Requirements Engineering and Testing (هندسة المتطلبات والاختبار)
18. Problem Solving and Program Development (حل المشكلات وتطوير البرامج)
19. Fundamentals of Data Structures and Algorithms (أساسيات هياكل البيانات والخوارزميات)
20. Web and Mobile Systems Concepts and Technologies (مفاهيم وتقنيات أنظمة الويب والهاتف المحمول)

**How to Guide Users (Navigation Examples):**

Example 1 - "How do I take an exam?"
"لإجراء الاختبار في تطبيق تأهب:
1. من الشاشة الرئيسية، اضغط على بطاقة 'الاختبار'
2. اختر وحدة معرفية واحدة أو أكثر
3. اضغط على 'ابدأ الاختبار'
4. أكد بدء الاختبار
5. أجب على الأسئلة (يمكنك التنقل بين الأسئلة)
6. عند الانتهاء، اضغط 'إنهاء'
7. شاهد نتائجك مع التفاصيل الكاملة 📊"

Example 2 - "How do I check my points?"
"To view your points in Taehb:
1. From Home screen, tap the 'Points' card
2. You'll see detailed points history
3. View points earned from:
   - Exam completion
   - Daily login
   - Level ups
   - First exam bonus
4. Track your progress to next level 🌟"

Example 3 - "Where is the leaderboard?"
"لعرض لوحة المتصدرين في تأهب:
1. من أي شاشة
2. اضغط على أيقونة الكأس 🏆 في شريط التنقل السفلي
3. ستظهر لك قائمة أفضل الطلاب
4. يمكنك رؤية ترتيبك بين الطلاب
5. اضغط على 'تحديث' لتحديث الترتيب"

**Communication Style:**
- Be friendly, motivating, and supportive 😊
- Use simple, clear language
- Respond in the SAME language as user (Arabic ↔ Arabic, English ↔ English)
- Use appropriate emojis: 📚 ✨ 🎯 💪 🌟 🏆 ⭐
- Provide step-by-step guidance with numbered lists
- Always mention "تطبيق تأهب" or "Taehb app" when referring to the app
- Be concise but comprehensive

**When Creating Summaries:**
- Provide organized, comprehensive summaries
- Include:
  * Key concepts (المفاهيم الأساسية)
  * Main points (النقاط الرئيسية)
  * Examples when applicable (أمثلة)
  * Study tips (نصائح للدراسة)
- Use bullet points and clear structure
- Make it easy to understand

**Important Notes:**
- Always detect user's language and respond accordingly
- Be encouraging and motivating
- If asked about unavailable features, mention "Coming Soon" politely
- Reference correct screen names and navigation paths
- Use official feature names from the app

Remember: You're here to make learning easier and help students succeed in Taehb! 🎓✨
''';

  /// Send message and get response from Groq
  Future<String> sendMessage({
    required String message,
    List<Map<String, String>>? chatHistory,
  }) async {
    try {
      // Build messages list
      final messages = <Map<String, String>>[
        {'role': 'system', 'content': _systemPrompt},
      ];

      // Add previous chat history
      if (chatHistory != null && chatHistory.isNotEmpty) {
        messages.addAll(chatHistory);
      }

      // Add current message
      messages.add({'role': 'user', 'content': message});

      // Send request
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Authorization': 'Bearer $_apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': _model,
          'messages': messages,
          'temperature': 0.7,
          'max_tokens': 1024,
          'top_p': 1,
          'stream': false,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        final content = data['choices'][0]['message']['content'] as String;
        return content.trim();
      } else {
        print('Groq API Error: ${response.statusCode} - ${response.body}');
        return 'عذراً، حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.\nSorry, there was a connection error. Please try again.';
      }
    } catch (e) {
      print('Error in sendMessage: $e');
      return 'عذراً، لم أتمكن من معالجة طلبك. يرجى التحقق من اتصال الإنترنت.\nSorry, I couldn\'t process your request. Please check your internet connection.';
    }
  }

  Future<Map<String, dynamic>> loadKnowledgeUnits() async {
    final String jsonString = await rootBundle.loadString('assets/ku_topics.json');
    final Map<String, dynamic> data = jsonDecode(jsonString);
    return data;
  }

  /// Create summary for a specific topic
  Future<String> createSummary(String topic, String language) async {
    final message = language == 'ar'
        ? '''
أرجو منك إنشاء ملخص شامل ومفيد عن موضوع: "$topic"

يجب أن يتضمن الملخص:
- المفاهيم الأساسية والتعريفات
- النقاط الرئيسية والأفكار المهمة
- أمثلة توضيحية وتطبيقات عملية (إن أمكن)
- نصائح للدراسة والفهم الأفضل

قدم الملخص بطريقة منظمة وسهلة الفهم باللغة العربية.
استخدم النقاط والعناوين لتسهيل القراءة.
'''
        : '''
Please create a comprehensive and useful summary about the topic: "$topic"

The summary should include:
- Basic concepts and definitions
- Key points and important ideas
- Illustrative examples and practical applications (if possible)
- Study tips for better understanding

Present the summary in an organized and easy-to-understand manner in English.
Use bullet points and headings for easy reading.
''';

    return await sendMessage(message: message);
  }

  /// Help student with navigation
  Future<String> getNavigationHelp(String feature, String language) async {
    final message = language == 'ar'
        ? '''
كيف يمكنني الوصول إلى "$feature" في تطبيق تأهب؟
أرجو تقديم خطوات واضحة ومفصلة باللغة العربية مع استخدام الأرقام.
اذكر اسم الأزرار والشاشات بشكل دقيق.
'''
        : '''
How can I access "$feature" in the Taehb app?
Please provide clear and detailed steps in English with numbered instructions.
Mention button names and screen names accurately.
''';

    return await sendMessage(message: message);
  }

  Future<String> generateQuestionFromTopic(String topicName, String language) async {
    final kuData = await loadKnowledgeUnits();

    // البحث عن الوحدة التي تحتوي على هذا الموضوع
    String? matchedUnit;
    for (var unit in kuData.entries) {
      if ((unit.value['Topics'] as List).contains(topicName)) {
        matchedUnit = unit.key;
        break;
      }
    }

    if (matchedUnit == null) {
      return language == 'ar'
          ? 'لم يتم العثور على موضوع بهذا الاسم في الوحدات المعرفية.'
          : 'Topic not found in knowledge units.';
    }

    final learningOutcomes = kuData[matchedUnit]['Learning Outcomes'].join('\n- ');

    final prompt = language == 'ar'
        ? '''
قم بإنشاء 5 أسئلة اختيار من متعدد (MCQs) حول الموضوع "$topicName"
من الوحدة المعرفية "$matchedUnit".

يجب أن تغطي الأسئلة نتائج التعلم التالية:
$learningOutcomes

قدم الأسئلة بصيغة واضحة:
السؤال X:
[نص السؤال]
A) [خيار 1]
B) [خيار 2]
C) [خيار 3]
D) [خيار 4]
✅ الإجابة الصحيحة: [الحرف]

'''
        : '''
Create 5 multiple-choice questions (MCQs) about the topic "$topicName"
from the knowledge unit "$matchedUnit".

The questions should cover these learning outcomes:
$learningOutcomes

Format each question clearly as:
Question X:
[Question text]
A) [Option 1]
B) [Option 2]
C) [Option 3]
D) [Option 4]
✅ Correct Answer: [Letter]

''';

    return await sendMessage(message: prompt);
  }

  Future<String> answerQuestion(String question) async {
    return await sendMessage(message: question);
  }
}