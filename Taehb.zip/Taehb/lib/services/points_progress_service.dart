import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:taehb/data/models/user_model.dart';
import 'package:taehb/data/models/quiz_session.dart';
import 'package:taehb/services/daily_login_manager.dart';
import 'package:taehb/data/models/attempt.dart';
import 'package:taehb/services/activity_helper.dart';


class PointsProgressService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ثوابت حساب النقاط
  static const int POINTS_PER_CORRECT_ANSWER = 5;
  static const int BONUS_POINTS_HARD_QUESTION = 2;
  static const int POINTS_DAILY_LOGIN = 5;
  static const int POINTS_FIRST_EXAM = 10;
  static const int POINTS_COMPLETE_SESSION = 7;

  // مستويات النقاط
  static const Map<int, int> LEVEL_THRESHOLDS = {
    0: 0,      // المستوى 0
    1: 100,    // المستوى 1
    2: 250,    // المستوى 2
    3: 500,    // المستوى 3
    4: 1000,   // المستوى 4
    5: 2000,   // المستوى 5
  };

  /// حساب النقاط المكتسبة من الإجابة
  int calculateAnswerPoints({
    required bool isCorrect,
    required int difficulty,
    required int timeSpentSeconds,
  }) {
    if (!isCorrect) return 0;

    int points = POINTS_PER_CORRECT_ANSWER;

    // نقاط إضافية للأسئلة الصعبة
    if (difficulty >= 4) {
      points += BONUS_POINTS_HARD_QUESTION;
    }

    // نقاط إضافية للإجابة السريعة (أقل من 30 ثانية)
    if (timeSpentSeconds < 30) {
      points += 1;
    }

    return points;
  }

  /// حساب المستوى من إجمالي النقاط
  int calculateLevel(int totalPoints) {
    int level = 0;

    for (var entry in LEVEL_THRESHOLDS.entries) {
      if (totalPoints >= entry.value) {
        level = entry.key;
      } else {
        break;
      }
    }

    return level;
  }

  /// حساب النقاط المتبقية للمستوى التالي
  int pointsToNextLevel(int totalPoints) {
    int currentLevel = calculateLevel(totalPoints);
    int nextLevel = currentLevel + 1;

    if (nextLevel > LEVEL_THRESHOLDS.keys.last) {
      return 0; // وصل للمستوى الأقصى
    }

    int nextLevelThreshold = LEVEL_THRESHOLDS[nextLevel]!;
    return nextLevelThreshold - totalPoints;
  }

  /// تسجيل محاولة إجابة جديدة
  Future<Attempt> recordAttempt({
    required String sessionId,
    required String userId,
    required String questionId,
    required String unitId,
    required int selectedAnswerIndex,
    required bool isCorrect,
    required int difficulty,
    required int timeSpentSeconds,
  }) async {
    final points = calculateAnswerPoints(
      isCorrect: isCorrect,
      difficulty: difficulty,
      timeSpentSeconds: timeSpentSeconds,
    );

    final attempt = Attempt(
      id: '', // سيتم إنشاؤه من Firestore
      sessionId: sessionId,
      userId: userId,
      questionId: questionId,
      unitId: unitId,
      selectedAnswerIndex: selectedAnswerIndex,
      isCorrect: isCorrect,
      pointsEarned: points,
      answeredAt: DateTime.now(),
      timeSpentSeconds: timeSpentSeconds,
    );

    final docRef = await _firestore.collection('attempts').add(attempt.toMap());

    return attempt.copyWith(id: docRef.id);
  }

  /// تحديث جلسة الاختبار
  Future<void> updateQuizSession({
    required String sessionId,
    required bool isCorrect,
    required int pointsEarned,
  }) async {
    final sessionRef = _firestore.collection('quiz_sessions').doc(sessionId);

    await sessionRef.update({
      'answeredQuestions': FieldValue.increment(1),
      'correctAnswers': isCorrect ? FieldValue.increment(1) : FieldValue.increment(0),
      'totalPoints': FieldValue.increment(pointsEarned),
    });
  }

  /// إكمال جلسة الاختبار
  Future<void> completeQuizSession({
    required String sessionId,
    required String userId,
    required List<String> unitIds,
  }) async {
    final batch = _firestore.batch();

    // تحديث حالة الجلسة
    final sessionRef = _firestore.collection('quiz_sessions').doc(sessionId);
    batch.update(sessionRef, {
      'status': 'completed',
      'completedAt': FieldValue.serverTimestamp(),
    });

    // الحصول على بيانات الجلسة
    final sessionDoc = await sessionRef.get();
    final sessionData = sessionDoc.data();
    final totalPoints = sessionData?['totalPoints'] ?? 0;

    // نقاط إضافية لإكمال الجلسة
    final completionBonus = POINTS_COMPLETE_SESSION;

    // تحديث نقاط المستخدم
    final userRef = _firestore.collection('users').doc(userId);
    final userDoc = await userRef.get();
    final userData = userDoc.data();

    final currentPoints = userData?['totalPoints'] ?? 0;
    final newTotalPoints = currentPoints + totalPoints + completionBonus;
    final newLevel = calculateLevel(newTotalPoints);

    // تحديث تقدم الوحدات
    Map<String, dynamic> unitProgressUpdate = {};
    for (String unitId in unitIds) {
      unitProgressUpdate['unitProgress.$unitId'] = FieldValue.increment(1);
    }

    batch.update(userRef, {
      'totalPoints': newTotalPoints,
      'currentLevel': newLevel,
      'completedSessions': FieldValue.arrayUnion([sessionId]),
      ...unitProgressUpdate,
    });
    await ActivityHelper.addPointsEarnedActivity(
      userId: userId,
      points: totalPoints + completionBonus,
      reason: 'Completed quiz session in ${unitIds.join(", ")}',
    );
    final oldLevel = userData?['currentLevel'] ?? 0;
    if (newLevel > oldLevel) {
      await ActivityHelper.addLevelUpActivity(
        userId: userId,
        newLevel: newLevel,
        totalPoints: newTotalPoints,
      );
    }
    // إضافة سجل للنقاط المكتسبة
    final pointsHistoryRef = _firestore.collection('points_history').doc();
    batch.set(pointsHistoryRef, {
      'userId': userId,
      'sessionId': sessionId,
      'pointsEarned': totalPoints + completionBonus,
      'source': 'quiz_completion',
      'timestamp': FieldValue.serverTimestamp(),
      'details': {
        'sessionPoints': totalPoints,
        'completionBonus': completionBonus,
        'unitIds': unitIds,
      }
    });

    await batch.commit();
  }

  /// تسجيل نقاط تسجيل الدخول اليومي
  Future<void> recordDailyLogin(String userId) async {
    final userRef = _firestore.collection('users').doc(userId);
    final today = DateTime.now();
    final todayKey = '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';

    print('📅 Recording daily login for date: $todayKey');

    // التحقق من آخر تسجيل دخول
    final dailyLoginsRef = _firestore
        .collection('daily_logins')
        .doc(userId)
        .collection('logins')
        .doc(todayKey);

    final loginDoc = await dailyLoginsRef.get();

    if (loginDoc.exists) {
      print('⚠️ Daily login already recorded for $todayKey');
      throw Exception('Daily login already recorded');
    }

    print('✅ Recording new daily login');

    // تسجيل دخول جديد لليوم
    final batch = _firestore.batch();

    // حفظ سجل تسجيل الدخول
    batch.set(dailyLoginsRef, {
      'date': todayKey,
      'timestamp': FieldValue.serverTimestamp(),
      'pointsEarned': POINTS_DAILY_LOGIN,
    });

    // تحديث نقاط المستخدم
    final userDoc = await userRef.get();
    final userData = userDoc.data();
    final currentPoints = userData?['totalPoints'] ?? 0;
    final newTotalPoints = currentPoints + POINTS_DAILY_LOGIN;
    final newLevel = calculateLevel(newTotalPoints);

    batch.update(userRef, {
      'totalPoints': newTotalPoints,
      'currentLevel': newLevel,
      'lastLoginDate': todayKey,
    });

    // سجل في تاريخ النقاط
    final pointsHistoryRef = _firestore.collection('points_history').doc();
    batch.set(pointsHistoryRef, {
      'userId': userId,
      'pointsEarned': POINTS_DAILY_LOGIN,
      'source': 'daily_login',
      'timestamp': FieldValue.serverTimestamp(),
    });

    await batch.commit();
    print('💾 Daily login recorded successfully');

// استخدم DailyLoginManager
    final streakData = await DailyLoginManager().getStreakData(userId);

    await ActivityHelper.addDailyLoginActivity(
      userId: userId,
      points: POINTS_DAILY_LOGIN,
      streak: streakData['currentStreak'] ?? 1,
    );
  }

  /// الحصول على إحصائيات المستخدم
  Future<Map<String, dynamic>> getUserStats(String userId) async {
    final userDoc = await _firestore.collection('users').doc(userId).get();
    final userData = userDoc.data();

    if (userData == null) {
      throw Exception('User not found');
    }

    final totalPoints = userData['totalPoints'] ?? 0;
    final currentLevel = userData['currentLevel'] ?? 0;
    final completedSessions = (userData['completedSessions'] as List?)?.length ?? 0;
    final unitProgress = Map<String, int>.from(userData['unitProgress'] ?? {});
    final distinctUnitsCount = unitProgress.keys.length;

    // حساب الترتيب
    final usersSnapshot = await _firestore
        .collection('users')
        .orderBy('totalPoints', descending: true)
        .get();

    int rank = 1;
    for (var doc in usersSnapshot.docs) {
      if (doc.id == userId) break;
      rank++;
    }

    return {
      'totalPoints': totalPoints,
      'currentLevel': currentLevel,
      'rank': rank,
      'completedSessions': completedSessions,
      'distinctUnitsCount': distinctUnitsCount,
      'pointsToNextLevel': pointsToNextLevel(totalPoints),
      'nextLevelThreshold': LEVEL_THRESHOLDS[currentLevel + 1] ?? totalPoints,
      'progressPercentage': _calculateLevelProgress(totalPoints, currentLevel),
    };
  }

  /// حساب نسبة التقدم في المستوى الحالي
  double _calculateLevelProgress(int totalPoints, int currentLevel) {
    if (currentLevel >= LEVEL_THRESHOLDS.keys.last) {
      return 100.0; // المستوى الأقصى
    }

    final currentLevelThreshold = LEVEL_THRESHOLDS[currentLevel]!;
    final nextLevelThreshold = LEVEL_THRESHOLDS[currentLevel + 1]!;

    final pointsInCurrentLevel = totalPoints - currentLevelThreshold;
    final pointsNeededForNextLevel = nextLevelThreshold - currentLevelThreshold;

    return (pointsInCurrentLevel / pointsNeededForNextLevel * 100).clamp(0, 100);
  }

  /// الحصول على تاريخ النقاط
  Future<List<Map<String, dynamic>>> getPointsHistory(
      String userId, {
        int limit = 20,
      }) async {
    final snapshot = await _firestore
        .collection('points_history')
        .where('userId', isEqualTo: userId)
        .orderBy('timestamp', descending: true)
        .limit(limit)
        .get();

    return snapshot.docs.map((doc) {
      final data = doc.data();
      return {
        'id': doc.id,
        ...data,
      };
    }).toList();
  }
}

/// Extension للـ Attempt model
extension AttemptExtension on Attempt {
  Attempt copyWith({
    String? id,
    String? sessionId,
    String? userId,
    String? questionId,
    String? unitId,
    int? selectedAnswerIndex,
    bool? isCorrect,
    int? pointsEarned,
    DateTime? answeredAt,
    int? timeSpentSeconds,
  }) {
    return Attempt(
      id: id ?? this.id,
      sessionId: sessionId ?? this.sessionId,
      userId: userId ?? this.userId,
      questionId: questionId ?? this.questionId,
      unitId: unitId ?? this.unitId,
      selectedAnswerIndex: selectedAnswerIndex ?? this.selectedAnswerIndex,
      isCorrect: isCorrect ?? this.isCorrect,
      pointsEarned: pointsEarned ?? this.pointsEarned,
      answeredAt: answeredAt ?? this.answeredAt,
      timeSpentSeconds: timeSpentSeconds ?? this.timeSpentSeconds,
    );
  }
}