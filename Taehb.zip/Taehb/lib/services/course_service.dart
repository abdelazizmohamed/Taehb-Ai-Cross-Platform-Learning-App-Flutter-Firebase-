import 'dart:convert';
import 'package:http/http.dart' as http;

class CourseService {
  static const String BASE_URL = 'http://10.0.2.2:5000';

  Future<String> generateCourseSummary(String selectedKUs) async {
    if (selectedKUs.isEmpty) {
      throw Exception('Please select at least one Knowledge Unit');
    }

    try {
      final response = await http.post(
        Uri.parse('$BASE_URL/generate_summary'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'selected_ku': selectedKUs,
        }),
      ).timeout(
        const Duration(seconds: 120),
        onTimeout: () {
          throw Exception('Request timeout. Please try again.');
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final summary = data['summary'] as String?;

        if (summary == null || summary.isEmpty) {
          throw Exception('Received empty summary from server');
        }

        // Check for error in summary
        if (summary.startsWith('Error:')) {
          throw Exception(summary.substring(6).trim());
        }

        return summary;
      } else {
        final errorData = json.decode(response.body);
        final errorMessage = errorData['summary'] ?? 'Failed to generate summary';
        throw Exception(errorMessage);
      }
    } on http.ClientException catch (e) {
      throw Exception('Network error: Please check your connection');
    } catch (e) {
      if (e is Exception) {
        rethrow;
      }
      throw Exception('Failed to generate summary: ${e.toString()}');
    }
  }

  /// Generate questions for a specific Knowledge Unit
  Future<Map<String, dynamic>> generateQuestions({
    required String knowledgeUnit,
    int numberOfQuestions = 10,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$BASE_URL/generate_questions'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'selected_ku': knowledgeUnit,
          'n_questions': numberOfQuestions,
        }),
      ).timeout(
        const Duration(seconds: 120),
        onTimeout: () {
          throw Exception('Request timeout. Please try again.');
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return {
          'questions': data['questions'] as String,
          'knowledge_unit': data['knowledge_unit'] as String,
          'learning_outcomes': data['learning_outcomes'] as Map<String, dynamic>,
        };
      } else {
        final errorData = json.decode(response.body);
        throw Exception(errorData['questions'] ?? 'Failed to generate questions');
      }
    } catch (e) {
      if (e is Exception) {
        rethrow;
      }
      throw Exception('Failed to generate questions: ${e.toString()}');
    }
  }

  /// Analyze exam results and get recommendations
  Future<Map<String, dynamic>> analyzeResults({
    required String knowledgeUnit,
    required List<Map<String, dynamic>> questionResults,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$BASE_URL/analyze_results'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'knowledge_unit': knowledgeUnit,
          'question_results': questionResults,
        }),
      ).timeout(
        const Duration(seconds: 90),
        onTimeout: () {
          throw Exception('Request timeout. Please try again.');
        },
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        final errorData = json.decode(response.body);
        throw Exception(errorData['error'] ?? 'Failed to analyze results');
      }
    } catch (e) {
      if (e is Exception) {
        rethrow;
      }
      throw Exception('Failed to analyze results: ${e.toString()}');
    }
  }
}