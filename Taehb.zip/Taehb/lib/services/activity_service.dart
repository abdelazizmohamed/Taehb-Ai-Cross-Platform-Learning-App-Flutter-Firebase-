import 'package:cloud_firestore/cloud_firestore.dart';

/// Activity types
enum ActivityType {
  examCompleted,
  pointsEarned,
  levelUp,
  unitUnlocked,
  achievementUnlocked,
  dailyLogin,
}

/// Activity model
class ActivityItem {
  final String id;
  final String userId;
  final ActivityType type;
  final String title;
  final String description;
  final int? points;
  final DateTime timestamp;
  final Map<String, dynamic>? metadata;

  ActivityItem({
    required this.id,
    required this.userId,
    required this.type,
    required this.title,
    required this.description,
    this.points,
    required this.timestamp,
    this.metadata,
  });

  factory ActivityItem.fromMap(Map<String, dynamic> map, String id) {
    return ActivityItem(
      id: id,
      userId: map['userId'] ?? '',
      type: _parseActivityType(map['type']),
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      points: map['points'],
      timestamp: (map['timestamp'] as Timestamp).toDate(),
      metadata: map['metadata'] as Map<String, dynamic>?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'type': type.name,
      'title': title,
      'description': description,
      'points': points,
      'timestamp': Timestamp.fromDate(timestamp),
      'metadata': metadata,
    };
  }

  static ActivityType _parseActivityType(String? type) {
    switch (type) {
      case 'examCompleted':
        return ActivityType.examCompleted;
      case 'pointsEarned':
        return ActivityType.pointsEarned;
      case 'levelUp':
        return ActivityType.levelUp;
      case 'unitUnlocked':
        return ActivityType.unitUnlocked;
      case 'achievementUnlocked':
        return ActivityType.achievementUnlocked;
      case 'dailyLogin':
        return ActivityType.dailyLogin;
      default:
        return ActivityType.pointsEarned;
    }
  }
}

/// Activity Service
class ActivityService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static const String _activitiesCollection = 'user_activities';

  /// Get recent activities for a user
  Future<List<ActivityItem>> getUserActivities(String userId, {int limit = 10}) async {
    try {
      final querySnapshot = await _firestore
          .collection(_activitiesCollection)
          .where('userId', isEqualTo: userId)
          .orderBy('timestamp', descending: true)
          .limit(limit)
          .get();

      return querySnapshot.docs
          .map((doc) => ActivityItem.fromMap(doc.data(), doc.id))
          .toList();
    } catch (e) {
      print('❌ ActivityService - Error fetching activities: $e');
      return [];
    }
  }

  /// Add a new activity
  Future<void> addActivity({
    required String userId,
    required ActivityType type,
    required String title,
    required String description,
    int? points,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final activity = ActivityItem(
        id: '',
        userId: userId,
        type: type,
        title: title,
        description: description,
        points: points,
        timestamp: DateTime.now(),
        metadata: metadata,
      );

      await _firestore.collection(_activitiesCollection).add(activity.toMap());
      print('✅ ActivityService - Activity added successfully');
    } catch (e) {
      print('❌ ActivityService - Error adding activity: $e');
    }
  }

  /// Delete old activities (keep only last 30 days)
  Future<void> cleanupOldActivities(String userId) async {
    try {
      final thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30));

      final querySnapshot = await _firestore
          .collection(_activitiesCollection)
          .where('userId', isEqualTo: userId)
          .where('timestamp', isLessThan: Timestamp.fromDate(thirtyDaysAgo))
          .get();

      final batch = _firestore.batch();
      for (var doc in querySnapshot.docs) {
        batch.delete(doc.reference);
      }

      await batch.commit();
      print('✅ ActivityService - Old activities cleaned up');
    } catch (e) {
      print('❌ ActivityService - Error cleaning up activities: $e');
    }
  }

  /// Get activity count by type
  Future<Map<ActivityType, int>> getActivityCountsByType(String userId) async {
    try {
      final querySnapshot = await _firestore
          .collection(_activitiesCollection)
          .where('userId', isEqualTo: userId)
          .get();

      final counts = <ActivityType, int>{};
      for (var doc in querySnapshot.docs) {
        final activity = ActivityItem.fromMap(doc.data(), doc.id);
        counts[activity.type] = (counts[activity.type] ?? 0) + 1;
      }

      return counts;
    } catch (e) {
      print('❌ ActivityService - Error getting activity counts: $e');
      return {};
    }
  }

  /// Get total points earned from activities
  Future<int> getTotalPointsEarned(String userId) async {
    try {
      final querySnapshot = await _firestore
          .collection(_activitiesCollection)
          .where('userId', isEqualTo: userId)
          .where('points', isNotEqualTo: null)
          .get();

      int total = 0;
      for (var doc in querySnapshot.docs) {
        final activity = ActivityItem.fromMap(doc.data(), doc.id);
        total += activity.points ?? 0;
      }

      return total;
    } catch (e) {
      print('❌ ActivityService - Error getting total points: $e');
      return 0;
    }
  }
}