
import 'package:cloud_firestore/cloud_firestore.dart';
import '../data/models/leaderboard_entry.dart';

class LeaderboardService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<LeaderboardEntry>> streamLeaderboard({int limit = 50}) {
    return _firestore
        .collection('users')
        .orderBy('totalPoints', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) {
      final entries = <LeaderboardEntry>[];
      int rank = 1;

      for (var doc in snapshot.docs) {
        try {
          final data = doc.data();

          // تخطي المستخدمين بدون نقاط
          final totalPoints = data['totalPoints'] ?? 0;
          if (totalPoints == 0) continue;

          final entry = LeaderboardEntry(
            userId: doc.id,
            displayName: data['name'] ??
                data['displayName'] ??
                data['email']?.split('@')[0] ??
                'User',
            totalPoints: totalPoints,
            currentLevel: data['currentLevel'] ?? 0,
            rank: rank,
            totalSessions: (data['completedSessions'] as List?)?.length ?? 0,
            distinctUnitsCount: (data['unitProgress'] as Map?)?.keys.length ?? 0,
            lastUpdated: data['lastActive'] != null
                ? (data['lastActive'] as Timestamp).toDate()
                : data['updatedAt'] != null
                ? (data['updatedAt'] as Timestamp).toDate()
                : DateTime.now(),
          );

          entries.add(entry);
          rank++;
        } catch (e) {
          print('❌ Error parsing leaderboard entry: $e');
          continue;
        }
      }

      return entries;
    });
  }

  /// Get leaderboard entries as Future (one-time fetch)
  Future<List<LeaderboardEntry>> getLeaderboard({int limit = 50}) async {
    try {
      final snapshot = await _firestore
          .collection('users')
          .orderBy('totalPoints', descending: true)
          .limit(limit)
          .get();

      final entries = <LeaderboardEntry>[];
      int rank = 1;

      for (var doc in snapshot.docs) {
        try {
          final data = doc.data();

          final totalPoints = data['totalPoints'] ?? 0;
          if (totalPoints == 0) continue;

          final entry = LeaderboardEntry(
            userId: doc.id,
            displayName: data['name'] ??
                data['displayName'] ??
                data['email']?.split('@')[0] ??
                'User',
            totalPoints: totalPoints,
            currentLevel: data['currentLevel'] ?? 0,
            rank: rank,
            totalSessions: (data['completedSessions'] as List?)?.length ?? 0,
            distinctUnitsCount: (data['unitProgress'] as Map?)?.keys.length ?? 0,
            lastUpdated: data['lastActive'] != null
                ? (data['lastActive'] as Timestamp).toDate()
                : data['updatedAt'] != null
                ? (data['updatedAt'] as Timestamp).toDate()
                : DateTime.now(),
          );

          entries.add(entry);
          rank++;
        } catch (e) {
          print('❌ Error parsing leaderboard entry: $e');
          continue;
        }
      }

      return entries;
    } catch (e) {
      print('❌ Error fetching leaderboard: $e');
      return [];
    }
  }

  /// Get user's rank in leaderboard
  Future<int> getUserRank(String userId) async {
    try {
      final userDoc = await _firestore.collection('users').doc(userId).get();

      if (!userDoc.exists) return 0;

      final userData = userDoc.data()!;
      final userPoints = userData['totalPoints'] ?? 0;

      // Count users with more points
      final snapshot = await _firestore
          .collection('users')
          .where('totalPoints', isGreaterThan: userPoints)
          .get();

      return snapshot.docs.length + 1;
    } catch (e) {
      print('❌ Error getting user rank: $e');
      return 0;
    }
  }

  /// Get top N users
  Future<List<LeaderboardEntry>> getTopUsers(int n) async {
    return getLeaderboard(limit: n);
  }

  /// Get users around specific rank
  Future<List<LeaderboardEntry>> getUsersAroundRank(
      int rank, {
        int before = 2,
        int after = 2,
      }) async {
    try {
      final startRank = (rank - before).clamp(1, double.infinity).toInt();
      final endRank = rank + after;

      final allEntries = await getLeaderboard(limit: endRank);

      return allEntries
          .where((entry) => entry.rank >= startRank && entry.rank <= endRank)
          .toList();
    } catch (e) {
      print('❌ Error getting users around rank: $e');
      return [];
    }
  }

  /// Get leaderboard for specific time period
  Stream<List<LeaderboardEntry>> streamWeeklyLeaderboard({int limit = 50}) {
    final oneWeekAgo = DateTime.now().subtract(const Duration(days: 7));

    return _firestore
        .collection('users')
        .where('lastActive', isGreaterThanOrEqualTo: Timestamp.fromDate(oneWeekAgo))
        .orderBy('lastActive', descending: true)
        .orderBy('totalPoints', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) {
      final entries = <LeaderboardEntry>[];
      int rank = 1;

      for (var doc in snapshot.docs) {
        try {
          final data = doc.data();

          final totalPoints = data['totalPoints'] ?? 0;
          if (totalPoints == 0) continue;

          final entry = LeaderboardEntry(
            userId: doc.id,
            displayName: data['name'] ??
                data['displayName'] ??
                data['email']?.split('@')[0] ??
                'User',
            totalPoints: totalPoints,
            currentLevel: data['currentLevel'] ?? 0,
            rank: rank,
            totalSessions: (data['completedSessions'] as List?)?.length ?? 0,
            distinctUnitsCount: (data['unitProgress'] as Map?)?.keys.length ?? 0,
            lastUpdated: (data['lastActive'] as Timestamp).toDate(),
          );

          entries.add(entry);
          rank++;
        } catch (e) {
          print('❌ Error parsing weekly leaderboard entry: $e');
          continue;
        }
      }

      return entries;
    });
  }

  /// Get statistics about leaderboard
  Future<Map<String, dynamic>> getLeaderboardStats() async {
    try {
      final snapshot = await _firestore
          .collection('users')
          .where('totalPoints', isGreaterThan: 0)
          .get();

      int totalUsers = snapshot.docs.length;
      int totalPoints = 0;
      int maxPoints = 0;
      int maxLevel = 0;

      for (var doc in snapshot.docs) {
        final data = doc.data();
        final points = data['totalPoints'] ?? 0;
        final level = data['currentLevel'] ?? 0;

        totalPoints += points as int;
        if (points > maxPoints) maxPoints = points;
        if (level > maxLevel) maxLevel = level;
      }

      double averagePoints = totalUsers > 0 ? totalPoints / totalUsers : 0;

      return {
        'totalUsers': totalUsers,
        'totalPoints': totalPoints,
        'averagePoints': averagePoints.round(),
        'maxPoints': maxPoints,
        'maxLevel': maxLevel,
      };
    } catch (e) {
      print('❌ Error getting leaderboard stats: $e');
      return {
        'totalUsers': 0,
        'totalPoints': 0,
        'averagePoints': 0,
        'maxPoints': 0,
        'maxLevel': 0,
      };
    }
  }

  /// Search users in leaderboard
  Future<List<LeaderboardEntry>> searchUsers(String query) async {
    try {
      if (query.isEmpty) return [];

      final snapshot = await _firestore
          .collection('users')
          .orderBy('totalPoints', descending: true)
          .get();

      final entries = <LeaderboardEntry>[];
      int rank = 1;

      for (var doc in snapshot.docs) {
        try {
          final data = doc.data();
          final displayName = data['name'] ??
              data['displayName'] ??
              data['email']?.split('@')[0] ??
              'User';

          // Filter by name
          if (!displayName.toLowerCase().contains(query.toLowerCase())) {
            rank++;
            continue;
          }

          final totalPoints = data['totalPoints'] ?? 0;

          final entry = LeaderboardEntry(
            userId: doc.id,
            displayName: displayName,
            totalPoints: totalPoints,
            currentLevel: data['currentLevel'] ?? 0,
            rank: rank,
            totalSessions: (data['completedSessions'] as List?)?.length ?? 0,
            distinctUnitsCount: (data['unitProgress'] as Map?)?.keys.length ?? 0,
            lastUpdated: data['lastActive'] != null
                ? (data['lastActive'] as Timestamp).toDate()
                : DateTime.now(),
          );

          entries.add(entry);
          rank++;
        } catch (e) {
          print('❌ Error parsing search result: $e');
          continue;
        }
      }

      return entries;
    } catch (e) {
      print('❌ Error searching users: $e');
      return [];
    }
  }
}