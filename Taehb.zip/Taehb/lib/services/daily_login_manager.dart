import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:taehb/services/activity_helper.dart';
import 'package:taehb/services/points_progress_service.dart';

/// مدير تسجيل الدخول اليومي
class DailyLoginManager {
  static final DailyLoginManager _instance = DailyLoginManager._internal();
  factory DailyLoginManager() => _instance;
  DailyLoginManager._internal();

  final PointsProgressService _pointsService = PointsProgressService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// التحقق من تسجيل الدخول اليومي عند فتح التطبيق
  Future<void> checkDailyLogin(BuildContext context) async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (userId == null) {
        print('❌ No user logged in');
        return;
      }

      // التحقق من آخر تسجيل دخول من Firebase
      final hasLoggedInToday = await _hasLoggedInToday(userId);

      if (hasLoggedInToday) {
        print('ℹ️ User already logged in today');
        return;
      }

      print('✅ First login today - recording daily login');

      await _pointsService.recordDailyLogin(userId);
      final streakData = await getStreakData(userId);

      await ActivityHelper.addDailyLoginActivity(
        userId: userId,
        points: PointsProgressService.POINTS_DAILY_LOGIN,
        streak: streakData['currentStreak'] ?? 1,
      );
      if (context.mounted) {
        _showDailyLoginReward(context);
      }
    } catch (e) {
      print('❌ Error in checkDailyLogin: $e');
    }
  }

  Future<bool> _hasLoggedInToday(String userId) async {
    try {
      final today = DateTime.now();
      final todayKey = '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';

      print('🔍 Checking login for date: $todayKey');

      // التحقق من سجل تسجيل الدخول
      final loginDoc = await _firestore
          .collection('daily_logins')
          .doc(userId)
          .collection('logins')
          .doc(todayKey)
          .get();

      final exists = loginDoc.exists;
      print('📊 Login exists for today: $exists');

      return exists;
    } catch (e) {
      print('❌ Error checking daily login: $e');
      return false;
    }
  }

  void _showDailyLoginReward(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => DailyLoginRewardDialog(
        points: PointsProgressService.POINTS_DAILY_LOGIN,
      ),
    );
  }

  /// الحصول على بيانات السلسلة
  Future<Map<String, int>> getStreakData(String userId) async {
    try {
      final logins = await _firestore
          .collection('daily_logins')
          .doc(userId)
          .collection('logins')
          .orderBy('timestamp', descending: true)
          .limit(365) // آخر سنة
          .get();

      if (logins.docs.isEmpty) {
        return {'currentStreak': 0, 'longestStreak': 0};
      }

      // حساب السلسلة الحالية
      int currentStreak = 0;
      DateTime? lastDate;
      final today = DateTime.now();

      for (var doc in logins.docs) {
        final dateStr = doc.id; // format: yyyy-MM-dd
        final parts = dateStr.split('-');
        final docDate = DateTime(
          int.parse(parts[0]),
          int.parse(parts[1]),
          int.parse(parts[2]),
        );

        if (lastDate == null) {
          // أول تاريخ (الأحدث)
          final daysDiff = today.difference(docDate).inDays;
          if (daysDiff <= 1) {
            currentStreak = 1;
            lastDate = docDate;
          } else {
            break; // السلسلة انقطعت
          }
        } else {
          // التحقق من التتابع
          final daysDiff = lastDate.difference(docDate).inDays;
          if (daysDiff == 1) {
            currentStreak++;
            lastDate = docDate;
          } else {
            break; // السلسلة انقطعت
          }
        }
      }

      // حساب أطول سلسلة
      int longestStreak = 0;
      int tempStreak = 0;
      DateTime? tempLastDate;

      for (var doc in logins.docs.reversed) {
        final dateStr = doc.id;
        final parts = dateStr.split('-');
        final docDate = DateTime(
          int.parse(parts[0]),
          int.parse(parts[1]),
          int.parse(parts[2]),
        );

        if (tempLastDate == null) {
          tempStreak = 1;
          tempLastDate = docDate;
        } else {
          final daysDiff = docDate.difference(tempLastDate).inDays;
          if (daysDiff == 1) {
            tempStreak++;
            tempLastDate = docDate;
            if (tempStreak > longestStreak) {
              longestStreak = tempStreak;
            }
          } else {
            if (tempStreak > longestStreak) {
              longestStreak = tempStreak;
            }
            tempStreak = 1;
            tempLastDate = docDate;
          }
        }
      }

      if (tempStreak > longestStreak) {
        longestStreak = tempStreak;
      }

      return {
        'currentStreak': currentStreak,
        'longestStreak': longestStreak,
      };
    } catch (e) {
      print('❌ Error getting streak data: $e');
      return {'currentStreak': 0, 'longestStreak': 0};
    }
  }
}

/// حوار مكافأة تسجيل الدخول اليومي
class DailyLoginRewardDialog extends StatefulWidget {
  final int points;

  const DailyLoginRewardDialog({
    Key? key,
    required this.points,
  }) : super(key: key);

  @override
  State<DailyLoginRewardDialog> createState() => _DailyLoginRewardDialogState();
}

class _DailyLoginRewardDialogState extends State<DailyLoginRewardDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rotationAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.elasticOut),
    );

    _rotationAnimation = Tween<double>(begin: 0.0, end: 2.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    return Dialog(
      backgroundColor: Colors.transparent,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // أيقونة متحركة
                  Transform.rotate(
                    angle: _rotationAnimation.value * 3.14159,
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Colors.amber, Colors.orange],
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.amber.withOpacity(0.5),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.card_giftcard,
                        size: 48,
                        color: Colors.white,
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  Text(
                    isRTL ? 'مكافأة تسجيل الدخول اليومي' : 'Daily Login Reward',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),

                  const SizedBox(height: 12),

                  Text(
                    isRTL ? 'لقد حصلت على' : 'You earned',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey[600],
                    ),
                  ),

                  const SizedBox(height: 8),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.stars, color: Colors.amber, size: 32),
                      const SizedBox(width: 8),
                      Text(
                        '+${widget.points}',
                        style: const TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: Colors.amber,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        isRTL ? 'نقطة' : 'points',
                        style: const TextStyle(
                          fontSize: 20,
                          color: Colors.amber,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.info_outline, color: Colors.blue),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            isRTL
                                ? 'سجل دخولك يومياً لكسب المزيد من النقاط!'
                                : 'Log in daily to earn more points!',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.blue[900],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepPurple,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        isRTL ? 'رائع!' : 'Awesome!',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Widget لعرض سلسلة تسجيل الدخول
class LoginStreakWidget extends StatefulWidget {
  const LoginStreakWidget({Key? key}) : super(key: key);

  @override
  State<LoginStreakWidget> createState() => _LoginStreakWidgetState();
}

class _LoginStreakWidgetState extends State<LoginStreakWidget> {
  int _currentStreak = 0;
  int _longestStreak = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStreakData();
  }

  Future<void> _loadStreakData() async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (userId == null) {
        setState(() => _isLoading = false);
        return;
      }

      final streakData = await DailyLoginManager().getStreakData(userId);

      if (mounted) {
        setState(() {
          _currentStreak = streakData['currentStreak'] ?? 0;
          _longestStreak = streakData['longestStreak'] ?? 0;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('❌ Error loading streak: $e');
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isRTL = Directionality.of(context) == TextDirection.rtl;

    if (_isLoading) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(40),
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.local_fire_department,
                    color: Colors.orange,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  isRTL ? 'سلسلة تسجيل الدخول' : 'Login Streak',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStreakInfo(
                  label: isRTL ? 'السلسلة الحالية' : 'Current Streak',
                  value: isRTL ? '$_currentStreak يوم' : '$_currentStreak days',
                  icon: Icons.calendar_today,
                  color: Colors.orange,
                ),
                Container(
                  width: 1,
                  height: 40,
                  color: Colors.grey[300],
                ),
                _buildStreakInfo(
                  label: isRTL ? 'أطول سلسلة' : 'Longest Streak',
                  value: isRTL ? '$_longestStreak يوم' : '$_longestStreak days',
                  icon: Icons.emoji_events,
                  color: Colors.amber,
                ),
              ],
            ),

            if (_currentStreak > 0) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.check_circle, color: Colors.green, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        isRTL
                            ? 'لقد سجلت دخولك اليوم! عد غداً لمواصلة السلسلة'
                            : 'You logged in today! Come back tomorrow to continue your streak',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.green[900],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStreakInfo({
    required String label,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}