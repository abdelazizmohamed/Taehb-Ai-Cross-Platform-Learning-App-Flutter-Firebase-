import 'package:taehb/services/activity_service.dart';

/// Helper class to manage activity creation across the app
class ActivityHelper {
  static final ActivityService _activityService = ActivityService();

  /// Add exam completed activity
  static Future<void> addExamCompletedActivity({
    required String userId,
    required double scorePercentage,
    required int correctAnswers,
    required int totalQuestions,
    required String selectedKUs,
    String? examId,
  }) async {
    final isRTL = true; // يمكن تمريرها كمعامل

    await _activityService.addActivity(
      userId: userId,
      type: ActivityType.examCompleted,
      title: isRTL
          ? 'أكملت اختبار في ${selectedKUs.length} ${selectedKUs.length == 1 ? 'وحدة' : 'وحدات'}'
          : 'Completed exam in ${selectedKUs.length} unit${selectedKUs.length == 1 ? '' : 's'}',
      description: isRTL
          ? 'حصلت على ${scorePercentage.toStringAsFixed(1)}% ($correctAnswers/$totalQuestions)'
          : 'Scored ${scorePercentage.toStringAsFixed(1)}% ($correctAnswers/$totalQuestions)',
      metadata: {
        'exam_id': examId,
        'score': scorePercentage,
        'correct_answers': correctAnswers,
        'total_questions': totalQuestions,
        'selected_kus': selectedKUs,
      },
    );
  }

  /// Add points earned activity
  static Future<void> addPointsEarnedActivity({
    required String userId,
    required int points,
    required String reason,
  }) async {
    final isRTL = true;

    await _activityService.addActivity(
      userId: userId,
      type: ActivityType.pointsEarned,
      title: isRTL ? 'حصلت على $points نقطة' : 'Earned $points points',
      description: reason,
      points: points,
      metadata: {
        'reason': reason,
      },
    );
  }

  /// Add level up activity
  static Future<void> addLevelUpActivity({
    required String userId,
    required int newLevel,
    required int totalPoints,
  }) async {
    final isRTL = true;

    await _activityService.addActivity(
      userId: userId,
      type: ActivityType.levelUp,
      title: isRTL ? 'ارتفعت إلى المستوى $newLevel!' : 'Leveled up to $newLevel!',
      description: isRTL
          ? 'لديك الآن $totalPoints نقطة'
          : 'You now have $totalPoints points',
      metadata: {
        'new_level': newLevel,
        'total_points': totalPoints,
      },
    );
  }

  /// Add unit unlocked activity
  static Future<void> addUnitUnlockedActivity({
    required String userId,
    required String unitName,
    required String unitId,
  }) async {
    final isRTL = true;

    await _activityService.addActivity(
      userId: userId,
      type: ActivityType.unitUnlocked,
      title: isRTL ? 'فتحت وحدة جديدة' : 'Unlocked new unit',
      description: unitName,
      metadata: {
        'unit_id': unitId,
        'unit_name': unitName,
      },
    );
  }

  /// Add achievement unlocked activity
  static Future<void> addAchievementUnlockedActivity({
    required String userId,
    required String achievementName,
    required String achievementDescription,
  }) async {
    final isRTL = true;

    await _activityService.addActivity(
      userId: userId,
      type: ActivityType.achievementUnlocked,
      title: isRTL ? 'حصلت على إنجاز جديد!' : 'Unlocked achievement!',
      description: achievementName,
      metadata: {
        'achievement_name': achievementName,
        'achievement_description': achievementDescription,
      },
    );
  }

  /// Add daily login activity
  static Future<void> addDailyLoginActivity({
    required String userId,
    required int points,
    required int streak,
  }) async {
    final isRTL = true;

    await _activityService.addActivity(
      userId: userId,
      type: ActivityType.dailyLogin,
      title: isRTL ? 'تسجيل دخول يومي' : 'Daily login',
      description: isRTL
          ? 'سلسلة $streak ${streak == 1 ? 'يوم' : 'أيام'}'
          : 'Streak: $streak day${streak == 1 ? '' : 's'}',
      points: points,
      metadata: {
        'streak': streak,
        'login_bonus': points,
      },
    );
  }

  /// Add multiple activities at once (batch)
  static Future<void> addMultipleActivities({
    required String userId,
    required List<Map<String, dynamic>> activities,
  }) async {
    for (final activityData in activities) {
      await _activityService.addActivity(
        userId: userId,
        type: activityData['type'] as ActivityType,
        title: activityData['title'] as String,
        description: activityData['description'] as String,
        points: activityData['points'] as int?,
        metadata: activityData['metadata'] as Map<String, dynamic>?,
      );
    }
  }

  /// Clean up old activities for a user
  static Future<void> cleanupUserActivities(String userId) async {
    await _activityService.cleanupOldActivities(userId);
  }
}