# taehb

### Flutter Quiz App with Firebase - Complete Documentation

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Project Structure](#project-structure)
3. [Firestore Data Models](#firestore-data-models)
4. [Core Features](#core-features)
5. [Implementation Details](#implementation-details)
6. [Firebase Setup](#firebase-setup)
7. [Testing Guide](#testing-guide)
8. [Deployment](#deployment)

## Architecture Overview

### Tech Stack
- **Frontend**: Flutter 3.x with Riverpod state management
- **Backend**: Firebase (Firestore, Auth, Cloud Functions)
- **Language**: Dart (Flutter), TypeScript (Cloud Functions)

### Key Design Decisions
1. **Question Distribution**: Round-robin algorithm ensures even distribution across selected units
2. **Scoring System**: Fixed points per question (10 pts default), cumulative scoring
3. **Level System**: Level 1 at 100 pts, Level 2 at 250 pts
4. **Progress Tracking**: Distinct units tracked via Map in user document
5. **Security**: Per-user write restrictions, validated attempts via Cloud Functions

## Project Structure

```
lib/
├── data/
│   └── models/
│       ├── user_model_clean.dart      # User data model
│       ├── knowledge_unit.dart        # Knowledge unit model
│       ├── question.dart               # Question model
│       ├── quiz_session.dart          # Quiz session model
│       ├── attempt.dart                # Answer attempt model
│       └── leaderboard_entry.dart     # Leaderboard entry model
├── services/
│   ├── quiz_service.dart              # Quiz logic and Firestore operations
│   ├── user_service.dart              # User profile management
│   └── leaderboard_service.dart       # Leaderboard operations
├── providers/
│   └── app_providers.dart             # Riverpod providers and state management
├── screens/
│   ├── quiz/
│   │   ├── unit_selection_screen.dart # Unit picker (max 3 units)
│   │   ├── quiz_screen.dart           # Quiz runner with distribution
│   │   └── results_screen.dart        # Results with per-unit breakdown
│   ├── profile/
│   │   └── profile_screen.dart        # User profile with stats
│   └── leaderboard/
│       └── leaderboard_screen.dart    # Global leaderboard
└── main.dart                           # App entry point

firebase/
├── firestore.rules                    # Security rules
├── functions/
│   ├── src/
│   │   └── index.ts                   # Cloud Functions
│   └── package.json                   # Functions dependencies
└── seed_data/
    ├── knowledge_units.json           # Sample units
    └── questions.json                  # Sample questions
```

## Firestore Data Models