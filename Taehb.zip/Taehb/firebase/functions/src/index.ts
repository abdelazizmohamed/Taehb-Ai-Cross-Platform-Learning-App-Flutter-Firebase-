import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();
const db = admin.firestore();

interface UserProgress {
  userId: string;
  totalPoints: number;
  currentLevel: number;
  unitProgress: Record<string, number>;
  distinctUnitsCount: number;
  completedSessions: string[];
  lastUpdated: admin.firestore.Timestamp;
}

interface LeaderboardEntry {
  userId: string;
  displayName: string;
  totalPoints: number;
  currentLevel: number;
  rank: number;
  totalSessions: number;
  distinctUnitsCount: number;
  lastUpdated: admin.firestore.Timestamp;
}

// Calculate user level based on points
function calculateLevel(points: number): number {
  if (points >= 250) return 2;
  if (points >= 100) return 1;
  return 0;
}

/**
 * Cloud Function: Update user progress after quiz completion
 * Triggered when a quiz session status changes to 'completed'
 */
export const updateUserProgressOnQuizCompletion = functions.firestore
  .document('quiz_sessions/{sessionId}')
  .onUpdate(async (change, context) => {
    const before = change.before.data();
    const after = change.after.data();
    
    // Check if session just completed
    if (before.status !== 'completed' && after.status === 'completed') {
      const userId = after.userId;
      const sessionId = context.params.sessionId;
      const pointsEarned = after.totalPoints || 0;
      const selectedUnits = after.selectedUnitIds || [];
      
      try {
        // Get user document
        const userRef = db.collection('users').doc(userId);
        
        await db.runTransaction(async (transaction) => {
          const userDoc = await transaction.get(userRef);
          
          if (!userDoc.exists) {
            throw new Error(`User ${userId} not found`);
          }
          
          const userData = userDoc.data()!;
          const currentPoints = userData.totalPoints || 0;
          const newTotalPoints = currentPoints + pointsEarned;
          const newLevel = calculateLevel(newTotalPoints);
          
          // Update unit progress
          const unitProgress = userData.unitProgress || {};
          for (const unitId of selectedUnits) {
            unitProgress[unitId] = (unitProgress[unitId] || 0) + 1;
          }
          
          // Add completed session
          const completedSessions = userData.completedSessions || [];
          if (!completedSessions.includes(sessionId)) {
            completedSessions.push(sessionId);
          }
          
          // Update unlocked units
          const unlockedUnits = new Set(userData.unlockedUnits || []);
          selectedUnits.forEach((unitId: string) => unlockedUnits.add(unitId));
          
          // Update user document
          transaction.update(userRef, {
            totalPoints: newTotalPoints,
            currentLevel: newLevel,
            unitProgress,
            completedSessions,
            unlockedUnits: Array.from(unlockedUnits),
            lastActive: admin.firestore.FieldValue.serverTimestamp(),
          });
          
          // Log level up event
          if (newLevel > userData.currentLevel) {
            console.log(`User ${userId} leveled up from ${userData.currentLevel} to ${newLevel}!`);
          }
        });
        
        console.log(`Successfully updated progress for user ${userId} after completing session ${sessionId}`);
      } catch (error) {
        console.error(`Error updating user progress: ${error}`);
        throw error;
      }
    }
  });

/**
 * Cloud Function: Update leaderboard
 * Scheduled to run every hour
 */
export const updateLeaderboard = functions.pubsub
  .schedule('every 1 hours')
  .onRun(async (context) => {
    console.log('Starting leaderboard update...');
    
    try {
      // Get all users ordered by points
      const usersSnapshot = await db.collection('users')
        .orderBy('totalPoints', 'desc')
        .limit(100) // Top 100 users
        .get();
      
      const leaderboardEntries: LeaderboardEntry[] = [];
      let rank = 1;
      
      for (const userDoc of usersSnapshot.docs) {
        const userData = userDoc.data();
        const userId = userDoc.id;
        
        // Count completed sessions
        const sessionsSnapshot = await db.collection('quiz_sessions')
          .where('userId', '==', userId)
          .where('status', '==', 'completed')
          .get();
        
        const entry: LeaderboardEntry = {
          userId,
          displayName: userData.displayName || 'Anonymous',
          totalPoints: userData.totalPoints || 0,
          currentLevel: userData.currentLevel || 0,
          rank,
          totalSessions: sessionsSnapshot.size,
          distinctUnitsCount: Object.keys(userData.unitProgress || {}).length,
          lastUpdated: admin.firestore.Timestamp.now(),
        };
        
        leaderboardEntries.push(entry);
        rank++;
      }
      
      // Batch write leaderboard entries
      const batch = db.batch();
      
      // Clear existing entries
      const currentEntriesSnapshot = await db
        .collection('leaderboard_snapshots')
        .doc('current')
        .collection('entries')
        .get();
      
      currentEntriesSnapshot.docs.forEach(doc => {
        batch.delete(doc.ref);
      });
      
      // Write new entries
      for (const entry of leaderboardEntries) {
        const entryRef = db
          .collection('leaderboard_snapshots')
          .doc('current')
          .collection('entries')
          .doc(entry.userId);
        
        batch.set(entryRef, entry);
      }
      
      // Update metadata
      const metadataRef = db.collection('leaderboard_snapshots').doc('current');
      batch.set(metadataRef, {
        lastUpdated: admin.firestore.Timestamp.now(),
        totalEntries: leaderboardEntries.length,
      }, { merge: true });
      
      await batch.commit();
      
      console.log(`Successfully updated leaderboard with ${leaderboardEntries.length} entries`);
    } catch (error) {
      console.error('Error updating leaderboard:', error);
      throw error;
    }
  });

/**
 * Cloud Function: Calculate weekly leaderboard
 * Runs every Sunday at midnight
 */
export const calculateWeeklyLeaderboard = functions.pubsub
  .schedule('every sunday 00:00')
  .onRun(async (context) => {
    console.log('Calculating weekly leaderboard...');
    
    const oneWeekAgo = admin.firestore.Timestamp.fromDate(
      new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    );
    
    try {
      // Get sessions completed in the last week
      const sessionsSnapshot = await db.collection('quiz_sessions')
        .where('status', '==', 'completed')
        .where('completedAt', '>=', oneWeekAgo)
        .get();
      
      // Aggregate points by user
      const weeklyPoints: Record<string, number> = {};
      const userSessions: Record<string, number> = {};
      
      for (const sessionDoc of sessionsSnapshot.docs) {
        const sessionData = sessionDoc.data();
        const userId = sessionData.userId;
        const points = sessionData.totalPoints || 0;
        
        weeklyPoints[userId] = (weeklyPoints[userId] || 0) + points;
        userSessions[userId] = (userSessions[userId] || 0) + 1;
      }
      
      // Get user details and create leaderboard entries
      const weeklyEntries: LeaderboardEntry[] = [];
      
      for (const [userId, points] of Object.entries(weeklyPoints)) {
        const userDoc = await db.collection('users').doc(userId).get();
        
        if (userDoc.exists) {
          const userData = userDoc.data()!;
          weeklyEntries.push({
            userId,
            displayName: userData.displayName || 'Anonymous',
            totalPoints: points,
            currentLevel: userData.currentLevel || 0,
            rank: 0, // Will be set after sorting
            totalSessions: userSessions[userId],
            distinctUnitsCount: Object.keys(userData.unitProgress || {}).length,
            lastUpdated: admin.firestore.Timestamp.now(),
          });
        }
      }
      
      // Sort by weekly points and assign ranks
      weeklyEntries.sort((a, b) => b.totalPoints - a.totalPoints);
      weeklyEntries.forEach((entry, index) => {
        entry.rank = index + 1;
      });
      
      // Save weekly leaderboard
      const batch = db.batch();
      
      // Clear existing weekly entries
      const currentWeeklySnapshot = await db
        .collection('leaderboard_snapshots')
        .doc('weekly')
        .collection('entries')
        .get();
      
      currentWeeklySnapshot.docs.forEach(doc => {
        batch.delete(doc.ref);
      });
      
      // Write new weekly entries
      for (const entry of weeklyEntries.slice(0, 50)) { // Top 50 for weekly
        const entryRef = db
          .collection('leaderboard_snapshots')
          .doc('weekly')
          .collection('entries')
          .doc(entry.userId);
        
        batch.set(entryRef, entry);
      }
      
      // Update metadata
      const metadataRef = db.collection('leaderboard_snapshots').doc('weekly');
      batch.set(metadataRef, {
        lastUpdated: admin.firestore.Timestamp.now(),
        weekStartDate: oneWeekAgo,
        totalEntries: weeklyEntries.length,
      }, { merge: true });
      
      await batch.commit();
      
      console.log(`Weekly leaderboard updated with ${weeklyEntries.length} entries`);
    } catch (error) {
      console.error('Error calculating weekly leaderboard:', error);
      throw error;
    }
  });

/**
 * Cloud Function: Validate quiz attempt
 * Ensures attempts are valid and awards correct points
 */
export const validateQuizAttempt = functions.firestore
  .document('attempts/{attemptId}')
  .onCreate(async (snapshot, context) => {
    const attemptData = snapshot.data();
    const attemptId = context.params.attemptId;
    
    try {
      // Get the question to verify the answer
      const questionDoc = await db.collection('questions')
        .doc(attemptData.questionId)
        .get();
      
      if (!questionDoc.exists) {
        console.error(`Question ${attemptData.questionId} not found`);
        return;
      }
      
      const questionData = questionDoc.data()!;
      const isCorrect = attemptData.selectedAnswerIndex === questionData.correctAnswerIndex;
      const pointsEarned = isCorrect ? questionData.pointValue : 0;
      
      // Update the attempt with validated data
      await snapshot.ref.update({
        isCorrect,
        pointsEarned,
        validated: true,
        validatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      
      console.log(`Validated attempt ${attemptId}: correct=${isCorrect}, points=${pointsEarned}`);
    } catch (error) {
      console.error(`Error validating attempt ${attemptId}:`, error);
    }
  });
