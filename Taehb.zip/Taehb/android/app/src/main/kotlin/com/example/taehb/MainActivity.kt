package com.example.taehb

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
